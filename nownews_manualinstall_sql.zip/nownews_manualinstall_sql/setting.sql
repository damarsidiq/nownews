-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2018 at 05:03 PM
-- Server version: 10.2.9-MariaDB-10.2.9+maria~xenial-log
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pxpedia`
--

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` ( `type`, `app`, `name`, `value`) VALUES
('globalpage', 99, 'dbsetting', '{"dbhost":"localhost","dbuser":"root","dbpasswd":"catormouse","dbname":"oldnews3"}'),
('globalpage', 99, 'headsrc', '{"nownews_style":"nownews\\/default\\/styles\\/stylenew.css","nownews_favicon":"nownews\\/default\\/styles\\/images\\/favicon.ico","jquery-ui-themes-1.11.4_jquery-uimincss":"jquery-ui-themes-1.11.4\\/themes\\/blitzer\\/jquery-ui.min.css"}'),
('globalpage', 99, 'footsrc', '{"jquery_jquery-1":"jquery\\/jquery-1.9.1.min.js","jqueryui":"jquery\\/jquery-ui-1.10.3.custom.min.js","nownews_nownews":"nownews\\/nownews.min.js","flotjs":"flot\\/jquery.flot.min.js","flotcategories":"flot\\/jquery.flot.categories.min.js"}'),
('globalpage', 99, 'keywords', 'keywords');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
