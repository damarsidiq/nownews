-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2018 at 05:14 PM
-- Server version: 10.2.9-MariaDB-10.2.9+maria~xenial-log
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nownews`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `source` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `downloadedrss`
--

CREATE TABLE IF NOT EXISTS `downloadedrss` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` int(11) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `pubDate` datetime NOT NULL,
  `creator` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `guid` varchar(255) NOT NULL,
  `newssource` int(11) NOT NULL,
  `downloadcount` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `keytonews`
--

CREATE TABLE IF NOT EXISTS `keytonews` (
  `keyid` int(11) NOT NULL,
  `newsid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `keywords`
--

CREATE TABLE IF NOT EXISTS `keywords` (
  `id` int(11) NOT NULL,
  `keyword` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL,
  `news` text NOT NULL,
  `rssid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `newsimages`
--

CREATE TABLE IF NOT EXISTS `newsimages` (
  `id` int(11) NOT NULL,
  `rssid` int(11) NOT NULL,
  `filename` bigint(20) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `newsletters`
--

CREATE TABLE IF NOT EXISTS `newsletters` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `newslettersettings`
--

CREATE TABLE IF NOT EXISTS `newslettersettings` (
  `id` int(11) NOT NULL,
  `newsletterid` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `nextfetch` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `newssource`
--

CREATE TABLE IF NOT EXISTS `newssource` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `description` text NOT NULL,
  `cycle` varchar(255) NOT NULL DEFAULT 'daily',
  `cycledescription` varchar(255) NOT NULL,
  `lastfetched` datetime NOT NULL,
  `logo` varchar(255) NOT NULL,
  `downloadsetting` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newssource`
--

INSERT INTO `newssource` (`id`, `name`, `url`, `description`, `cycle`, `cycledescription`, `lastfetched`, `logo`, `downloadsetting`, `status`) VALUES
(1, 'The New Yorker', 'http://www.newyorker.com/feed/everything', 'Online version of the weekly magazine, with current articles, cartoons, blogs, audio, video, slide shows, an archive of articles and abstracts back to 1925.', 'daily', '', '2018-06-17 23:10:10', 'uploads/nownews/sourcelogo/new-yorker.jpeg', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"mjmpmpmgmp"}],"exclude":[{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"article-contributors"},{"contenttag":"section","contenttagattr":"id","contenttagattrvalue":"newsletter-signup"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"social-hover"}],"keywords":[]}', 1),
(2, 'National Geographic', 'http://news.nationalgeographic.com/rss/index.rss', '<p>National Geographic News</p>\r\nReporting our world daily: original nature and science news from National Geographic.', 'daily', '', '2018-06-06 00:36:10', 'uploads/nownews/sourcelogo/national_geographic.jpg', '{"thecontent":[{"contenttag":"article","contenttagattr":"class","contenttagattrvalue":"news__article"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"byline"},{"contenttag":"span","contenttagattr":"itemprop","contenttagattrvalue":"headline"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"rightRailSlot"},{"contenttag":"span","contenttagattr":"class","contenttagattrvalue":"bumper--top bumper--top_addthis"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"StickyBoxAd"},{"contenttag":"div","contenttagattr":"data-platform-component","contenttagattrvalue":"CommentsCallToActionButton"},{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"inline-gallery__container"},{"contenttag":"span","contenttagattr":"class","contenttagattrvalue":"bumper--bottom bumper--bottom_addthis"}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"keywords"}]}', 1),
(3, 'Columbia Journalism Review', 'http://www.cjr.org/index.xml', '<p>Columbia Journalism Review</p>\n<p>Encouraging excellence in journalism</p>', 'daily', '', '2018-06-15 21:01:19', 'uploads/nownews/sourcelogo/cjr-logo.jpg', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"article-content"}],"exclude":[{"contenttag":"aside","contenttagattr":"id","contenttagattrvalue":"sharing"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"mc_embed_signup"},{"contenttag":"span","contenttagattr":"class","contenttagattrvalue":"form-title-embed"},{"contenttag":"form","contenttagattr":"","contenttagattrvalue":""}],"keywords":[]}', 1),
(4, 'Columbia Journalism Review Magazine', 'http://www.cjr.org/magazine-rss.xml', '<p>Columbia Journalism Review</p>\nColumbia Journalism Review: The future of media is here', 'monthly', '', '2015-02-23 18:40:00', './uploads/nownews/sourcelogo//Columbia Journalism Review Magazine_nownewssource_4.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"article-content"}],"exclude":[],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"keywords"}]}', 0),
(5, 'Msnbc.com', 'http://www.msnbc.com/feeds/latest', '<p>msnbc.com Latest Headlines</p>\nThe shows you love, issues that matter: Rachel Maddow, Lawrence O&#039;Donnell, Chris Hayes, Chris Matthews, Al Sharpton, Ed Schultz, Joe Scarborough.', 'daily', '', '2018-06-19 18:22:12', 'uploads/nownews/sourcelogo/msnbc_logo.jpg', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"gpspjspgjspsahs"}],"exclude":[],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"news_keywords"}]}', 1),
(6, 'Phys.org', 'http://phys.org/rss-feed/', 'Phys.org - latest science and technology news stories\r\n\r\nPhys.org internet news portal provides the latest news on science including: Physics, Nanotechnology, Life Sciences, Space Science, Earth Science, Environment, Health and Medicine.', 'daily', '', '2018-06-06 21:00:07', 'uploads/nownews/sourcelogo/physorg-logo.jpg', '{"thecontent":[{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"news-content"}],"exclude":[{"contenttag":"p","contenttagattr":"class","contenttagattrvalue":"news-relevant"},{"contenttag":"section","contenttagattr":"id","contenttagattrvalue":"slick-social"},{"contenttag":"footer","contenttagattr":"","contenttagattrvalue":""}],"keywords":[]}', 1),
(7, 'IEEE Spectrum ', 'http://feeds.feedburner.com/IeeeSpectrum', 'IEEE Spectrum Recent Content', 'daily', '', '2018-09-04 22:00:00', 'uploads/nownews/sourcelogo/ieee-logo.jpg', '{"thecontent":[{"contenttag":"article","contenttagattr":"class","contenttagattrvalue":"article-detail"}],"exclude":[{"contenttag":"ul","contenttagattr":"id","contenttagattrvalue":"breadcrumbs"},{"contenttag":"h1","contenttagattr":"class","contenttagattrvalue":"article-title"},{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"learn-more"},{"contenttag":"section","contenttagattr":"id","contenttagattrvalue":"comments-section"},{"contenttag":"section","contenttagattr":"id","contenttagattrvalue":"side-module"},{"contenttag":"section","contenttagattr":"id","contenttagattrvalue":"recommended"}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"bt:keywords"}]}', 1),
(8, 'Readers Digest', 'http://feeds.rd.com/ReadersDigest', 'Readers Digest.com', 'daily', '', '2018-03-23 23:44:19', 'uploads/nownews/sourcelogo/rdlogo.jpg', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"rd-article--content"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"rd-article--source"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"rd-article--meta"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"rd-article--sharing"},{"contenttag":"p","contenttagattr":"class","contenttagattrvalue":"p1"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"rd-article--sharing rd-article--sharing__under"},{"contenttag":"p","contenttagattr":"class","contenttagattrvalue":"continues-below"}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"keywords"}]}', 1),
(11, 'CNN', 'http://rss.cnn.com/rss/cnn_latest.rss', '', 'daily', '', '2018-06-06 23:37:06', 'uploads/nownews/sourcelogo/CNN_nownewssource_11.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"itemprop","contenttagattrvalue":"articleBody"},{"contenttag":"span","contenttagattr":"itemprop","contenttagattrvalue":"articleBody"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"m-share"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"metadata"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"pg-comments"},{"contenttag":"section","contenttagattr":"id","contenttagattrvalue":"story-bottom"},{"contenttag":"section","contenttagattr":"id","contenttagattrvalue":"story-bottom-second"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"zn-body__read-more-outbrain"},{"contenttag":"ul","contenttagattr":"class","contenttagattrvalue":"cn-list-hierarchical-small-horizontal"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"el__leafmedia--storyhighlights"}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"keywords"}]}', 1),
(12, 'The American Prospect', 'http://prospect.org/rss.xml', '', 'daily', '', '2018-06-06 19:33:05', 'uploads/nownews/sourcelogo/The American Prospect_nownewssource_12.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"mtmtmtmjmjm6mtm"}],"exclude":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"block-tap-custom-you-may-also-like"},{"contenttag":"h1","contenttagattr":"class","contenttagattrvalue":"instapaper_title"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"block-block-67"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"block-user-login"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"item-list"},{"contenttag":"p","contenttagattr":"class","contenttagattrvalue":"post-author"},{"contenttag":"p","contenttagattr":"class","contenttagattrvalue":"post-date"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"addthis_toolbox"}],"keywords":[]}', 1),
(14, 'The Walrus Mag', 'http://thewalrus.ca/feed/', 'Fearless. Witty. Thoughtful. Canadian.', 'daily', '', '2018-06-01 19:53:11', 'uploads/nownews/sourcelogo/The Walrus Mag_nownewssource_14.png', '{"thecontent":[{"contenttag":"article","contenttagattr":"id","contenttagattrvalue":"jsgoajgosjgosjg"}],"exclude":[{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"appeal"},{"contenttag":"h1","contenttagattr":"","contenttagattrvalue":""},{"contenttag":"span","contenttagattr":"class","contenttagattrvalue":"dynamic-container"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"dynamic-container"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"disqus_thread"},{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"related-links"},{"contenttag":"script","contenttagattr":"type","contenttagattrvalue":"text\\/javascript"},{"contenttag":"span","contenttagattr":"class","contenttagattrvalue":"entry-summary"}],"keywords":[]}', 1),
(15, 'Jakarta Globe', 'http://jakartaglobe.beritasatu.com/rss/news/', '', 'daily', '', '2018-06-18 12:50:39', 'uploads/nownews/sourcelogo/Jakarta Globe_nownewssource_15.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"dosgjosajgosjaog"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"more-singel"},{"contenttag":"a","contenttagattr":"href","contenttagattrvalue":"show-hide"},{"contenttag":"ul","contenttagattr":"class","contenttagattrvalue":"social"},{"contenttag":"ul","contenttagattr":"class","contenttagattrvalue":"tags"},{"contenttag":"ul","contenttagattr":"class","contenttagattrvalue":"related"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"information"}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"keywords"}]}', 1),
(16, 'PC Magazine', 'http://feeds.pcmag.com/Rss.aspx/SectionArticles?sectionId=1489', '', 'monthly', '', '2018-03-26 22:53:15', 'uploads/nownews/sourcelogo/PC Magazine_nownewssource_16.png', '{"thecontent":[{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"article-body"}],"exclude":[{"contenttag":"img","contenttagattr":"style","contenttagattrvalue":"absolute"}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"keywords"}]}', 1),
(17, 'CNET', 'http://www.cnet.com/rss/all/', 'The latest tech news, product reviews, videos, and how tos from CNET', 'daily', '', '2018-03-26 22:37:19', 'uploads/nownews/sourcelogo/CNET_nownewssource_17.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"dummyidfordumdum"}],"exclude":[{"contenttag":"div","contenttagattr":"section","contenttagattrvalue":"topSharebar"},{"contenttag":"footer","contenttagattr":"","contenttagattrvalue":""},{"contenttag":"a","contenttagattr":"class","contenttagattrvalue":"twitterHandle"},{"contenttag":"div","contenttagattr":"section","contenttagattrvalue":"author"}],"keywords":[{"contenttag":"meta","contenttagattr":"itemprop","contenttagattrvalue":"keywords"}]}', 1),
(19, 'A List Apart', 'http://alistapart.com/main/feed', 'Articles for people who make web sites.', 'daily', '', '2018-02-27 08:30:00', 'uploads/nownews/sourcelogo/A List Apart_nownewssource_19.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"itemprop","contenttagattrvalue":"articleBody"}],"exclude":[{"contenttag":"a","contenttagattr":"data-trackevent","contenttagattrvalue":"Post-article"},{"contenttag":"aside","contenttagattr":"class","contenttagattrvalue":"more-content"},{"contenttag":"span","contenttagattr":"class","contenttagattrvalue":"post-article"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"post-article"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"aside-breaker"},{"contenttag":"a","contenttagattr":"href","contenttagattrvalue":"#comments"},{"contenttag":"span","contenttagattr":"class","contenttagattrvalue":"share-block"},{"contenttag":"span","contenttagattr":"class","contenttagattrvalue":"minutiae-block"},{"contenttag":"span","contenttagattr":"class","contenttagattrvalue":"utility-side-bar"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"utility-side-bar"},{"contenttag":"aside","contenttagattr":"class","contenttagattrvalue":"content-minutiae"},{"contenttag":"aside","contenttagattr":"id","contenttagattrvalue":"related"},{"contenttag":"footer","contenttagattr":"class","contenttagattrvalue":"entry-footer"},{"contenttag":"aside","contenttagattr":"class","contenttagattrvalue":"promo-box"},{"contenttag":"section","contenttagattr":"id","contenttagattrvalue":"comments"}],"keywords":[]}', 1),
(20, 'Entrepreneur Magazine', 'http://feeds.feedburner.com/entrepreneur/latest', '', 'daily', '', '2018-03-26 17:32:27', 'uploads/nownews/sourcelogo/Entrepreneur Magazine_nownewssource_20.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"itemprop","contenttagattrvalue":"articlebody"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"pl-heroabove"},{"contenttag":"div","contenttagattr":"data-type","contenttagattrvalue":"article-footer-promo"}],"keywords":[]}', 1),
(23, 'Creative Bloq', 'http://feeds.feedburner.com/creativebloq/', '', 'daily', '', '2017-02-07 13:00:29', 'uploads/nownews/sourcelogo/Creative Blog_nownewssource_23.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"itemprop","contenttagattrvalue":"articleBody"}],"exclude":[{"contenttag":"h3","contenttagattr":"class","contenttagattrvalue":"separator-heading"},{"contenttag":"ul","contenttagattr":"class","contenttagattrvalue":"media-list"}],"keywords":[]}', 1),
(24, 'Variety Magazine', 'http://feeds.feedburner.com/variety/headlines', '', 'daily', '', '2018-06-17 21:53:18', 'uploads/nownews/sourcelogo/Variety Magazine_nownewssource_24.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"hjghjghjghjghjghg"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"vy-prediction-list-module-container"},{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"tags"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"ad-below-tags"},{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"comments-overview"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"widget_pmc_outbrain_widget"}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"news_keywords"}]}', 1),
(25, 'Time', 'http://feeds.feedburner.com/time/newsfeed', '', 'daily', '', '2018-03-26 16:30:09', 'uploads/nownews/sourcelogo/Time_nownewssource_25.png', '{"thecontent":[{"contenttag":"article","contenttagattr":"id","contenttagattrvalue":"dspgjpsajgpasg"}],"exclude":[{"contenttag":"a","contenttagattr":"class","contenttagattrvalue":"clipper-toggle"}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"news_keywords"}]}', 1),
(26, 'Empire magazine', 'http://rss.feedsportal.com/c/592/f/7507/index.rss', 'The world''s biggest (and best) movie magazine and website', 'weekly', '', '2015-10-29 19:33:53', 'uploads/nownews/sourcelogo/Empire magazine_nownewssource_26.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"dumdumid"}],"exclude":[],"keywords":[]}', 0),
(27, 'Fast Company', 'http://feeds.feedburner.com/fastcompany/headlines', 'Fast Company inspires a new breed of innovative and creative thought leaders who are actively inventing the future of business', 'daily', '', '2018-03-04 17:25:47', 'uploads/nownews/sourcelogo/Fast Company_nownewssource_27.png', '{"thecontent":[{"contenttag":"article","contenttagattr":"id","contenttagattrvalue":"dsagjoajgos"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"ad-wrapper"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"after-body"},{"contenttag":"aside","contenttagattr":"class","contenttagattrvalue":"sidebar"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"post-share-buttons"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"byline"}],"keywords":[]}', 1),
(28, 'CIO', 'http://www.cio.com/category/it-strategy/index.rss', 'Serving Chief Information Officers (CIOs), other IT leaders, as well as the ecosystem that surrounds and interacts with them, CIO.com, CIO Executive Programs, CIO Strategic Marketing Services and CIO magazine are produced by CXO Media, an award-winning business unit of IDG Enterprise.', 'other', '', '2018-06-01 22:35:00', 'uploads/nownews/sourcelogo/CIO_nownewssource_28.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"itemprop","contenttagattrvalue":"articleBody"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"lazyload_ad"},{"contenttag":"aside","contenttagattr":"class","contenttagattrvalue":"nativo-promo"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"lazyload_ad_article"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"related-promo-wrapper"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"promo"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"byline"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"tags"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"prev-next"}],"keywords":[]}', 1),
(30, 'Forbes', 'http://www.forbes.com/feeds/popstories.xml', 'Beyond our famed, mustâ€“know lists â€“ richest people, powerful women, biggest companies â€” Forbes maintains a unique voice in its coverage of global business stories. Whether itâ€™s reporting on the â€œnext facebookâ€ or scrutinizing a new tax law, we cover stories with uncanny insight and conciseness that hurried business folks appreciate immensely. Read Forbes if you want rigorous, toâ€“theâ€“point business analysisâ€¦itâ€™s published especially for those who donâ€™t want to read a pile of business facts but need to know what to make of them.', 'daily', '', '2017-02-07 12:28:00', 'uploads/nownews/sourcelogo/Forbes_nownewssource_30.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"itemprop","contenttagattrvalue":"articleBody"}],"exclude":[],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"news_keywords"}]}', 0),
(31, 'linux magazine', 'http://www.linux-magazine.com/rss/feed/lmi_full', 'Linux Pro Magazine keeps the emphasis on real-life, practical techniques,\r\nwhich has helped make it one of the fastest growing Linux magazines worldwide.', 'daily', '', '2018-06-13 04:27:01', 'uploads/nownews/sourcelogo/linux magazine_nownewssource_31.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"attribute-body"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"article_body"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"full-content"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"attribute-advice"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"articlebox"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"attribute-relatedcontent"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"paginate"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"attribute-date"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"author"}],"keywords":[]}', 1),
(32, 'MSDN Magazine', 'https://docs.microsoft.com/en-us/msdn-files/feeds/msdn/en-us/magazine/rss.xml', '', 'monthly', '', '2016-08-01 20:45:38', 'uploads/nownews/sourcelogo/MSDN Magazine_nownewssource_32.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"sgoaoghsooss"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"FeatureTitle"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"RightContent"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"navpage"}],"keywords":[]}', 0),
(36, 'PCWorld', 'http://www.pcworld.com/index.rss', '', 'daily', '', '2018-06-09 01:37:00', 'uploads/nownews/sourcelogo/PCWorld_nownewssource_36.png', '{"thecontent":[{"contenttag":"span","contenttagattr":"itemprop","contenttagattrvalue":"articleBody"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"articleBloxAd"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"side-promo"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"side-ad"}],"keywords":[]}', 1),
(37, 'People', 'http://feeds.people.com/people/headlines', 'Celebrity News, Celebrity Photos, Exclusives and Star Style', 'daily', '', '2016-10-04 06:00:00', 'uploads/nownews/sourcelogo/People_nownewssource_37.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"articleBody"}],"exclude":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"the-latest"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"relatedCeleb"}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"keywords"}]}', 0),
(40, 'Physicsworld', 'http://feeds.feedburner.com/PhysicsWorld', '', 'daily', '', '2018-02-23 02:00:00', 'uploads/nownews/sourcelogo/Physicsworld_nownewssource_40.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"articleBody"}],"exclude":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"comments"}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"keywords"}]}', 1),
(44, 'Screen Anarchy', 'http://feeds.twitchfilm.com/TwitchEverything', 'Founded in September of 2004 with a great plan to write about the international, independent and cult film beloved by founder Todd Brown, but largely neglected by the online film community of the time, Twitch has gone on to become an industry''s leading resource for films from around the globe. Twitch is one of the most read film websites in the entire world and has become daily reading for festival programmers, film producers, film buyers, and tens of thousands of fans every day who share Mr. Brown''s belief that there''s no point in talking about the same five films that every other site in the world is talking about.', 'daily', '', '2017-02-07 15:00:09', 'uploads/nownews/sourcelogo/Screen Anarchy_nownewssource_44.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"post-content"}],"exclude":[],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"news_keywords"}]}', 1),
(46, 'Cosmopolitan', 'http://www.cosmopolitan.com/rss/all.xml', 'The Online Women''s Magazine for Fashion, Sex Advice, Dating Tips, and Celebrity News', 'daily', '', '2016-05-07 21:41:00', 'uploads/nownews/sourcelogo/Cosmopolitan_nownewssource_46.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"dumbeddownnot"}],"exclude":[{"contenttag":"nav","contenttagattr":"","contenttagattrvalue":""},{"contenttag":"form","contenttagattr":"","contenttagattrvalue":""},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"breaker-ad"},{"contenttag":"footer","contenttagattr":"","contenttagattrvalue":""}],"keywords":[{"contenttag":"meta","contenttagattr":"name","contenttagattrvalue":"keywords"}]}', 0),
(47, 'The Guardian', 'http://feeds.theguardian.com/theguardian/uk/rss', 'Latest news, sport, business, comment, analysis and reviews from the Guardian, the world''s leading liberal voice', 'daily', '', '2018-06-09 01:38:53', 'uploads/nownews/sourcelogo/The Guardian_nownewssource_47.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"dosgjosa"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"ad-slot"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"submeta"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"after-article"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"block-share"},{"contenttag":"svg","contenttagattr":"","contenttagattrvalue":""}],"keywords":[]}', 1),
(48, 'Christian Science Monitor', 'http://rss.csmonitor.com/feeds/csm?format=xml', 'The Christian Science Monitor is an international news organization that delivers thoughtful, global coverage via its website, weekly magazine, daily news briefing, and email newsletters.', 'daily', '', '2018-06-09 02:08:02', 'uploads/nownews/sourcelogo/The Christian Science Monitor_nownewssource_48.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"eza-body"}],"exclude":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"story-headers"},{"contenttag":"script","contenttagattr":"","contenttagattrvalue":""},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"promo_link_wrapper"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"story-embed-column"}],"keywords":[]}', 1),
(49, 'History Today', 'http://www.historytoday.com/feed/rss.xml', 'History Today is a magazine whose aim is simple: to bring serious history to a wide audience. It is based in London and published monthly.\r\n\r\nWe publish the world''s leading scholars, on all periods, regions and themes of history. Every contribution is carefully edited and illustrated to make the magazine a pleasurable, as well as an informative, read.', 'daily', '', '2018-06-15 12:59:00', 'uploads/nownews/sourcelogo/History Today_nownewssource_49.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"field-type-text-with-summary"}],"exclude":[],"keywords":[]}', 1),
(50, 'Harpers Magazine', 'http://harpers.org/feed/', 'description', 'daily', '', '2018-06-14 17:21:25', 'uploads/nownews/sourcelogo/Harpers Magazine_nownewssource_50.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"articlePost"}],"exclude":[],"keywords":[]}', 1),
(51, 'The Economist', 'http://www.economist.com/sections/business-finance/rss.xml', '', 'other', '', '2017-02-06 17:16:44', 'uploads/nownews/sourcelogo/The Economist_nownewssource_51.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"blog-post__text"},{"contenttag":"article","contenttagattr":"itemprop","contenttagattrvalue":"blogPost"}],"exclude":[],"keywords":[]}', 0),
(52, 'Vice', 'https://www.vice.com/en_id/rss', 'https://www.vice.com', 'daily', '', '2017-02-11 08:38:37', 'uploads/nownews/sourcelogo/Vice_nownewssource_52.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"long-form-article__content__body"}],"exclude":[],"keywords":[]}', 0),
(53, 'darknet', 'https://feeds.feedburner.com/darknethackers', 'the darkside', 'daily', '', '2018-02-26 15:53:37', './uploads/nownews/sourcelogo//darknet_nownewssource_53.png', '{"thecontent":[{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"entry"}],"exclude":[],"keywords":[]}', 1),
(54, 'La Times', 'http://www.latimes.com/rss2.0.xml', 'The LA Times is a leading source of breaking news, entertainment, sports, politics, and more for Southern California and the world.', 'daily', '', '2018-06-07 00:50:00', './uploads/nownews/sourcelogo//La Times_nownewssource_54.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"sssssssssssssss"}],"exclude":[],"keywords":[]}', 1),
(55, 'Marine Corps Times', 'http://feeds.feedburner.com/rss/category/mar-home?format=xml', '', 'weekly', '', '2017-05-26 21:23:38', './uploads/nownews/sourcelogo//Marine Corps Times_nownewssource_55.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"ddddddddddddddd"}],"exclude":[],"keywords":[]}', 0),
(56, 'Merco Press', 'http://en.mercopress.com/rss/', 'Read News, Stories and Insight Analysis from Latin America and Mercosur. Politics, Economy, Business and Investments in South America.', 'daily', '', '2018-03-26 19:36:00', './uploads/nownews/sourcelogo//Merco Press_nownewssource_56.png', '{"thecontent":[{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"content-page"}],"exclude":[{"contenttag":"h2","contenttagattr":"","contenttagattrvalue":""},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"content-data"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"social-links"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"banner"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"categories"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"comments"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"sidebar"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"tags"}],"keywords":[]}', 1),
(57, 'Millwaukee Journal Sentinel', 'http://rssfeeds.jsonline.com/milwaukee/news', 'Milwaukee and Wisconsin news, sports, business, opinion, entertainment, lifestyle and investigative reporting from the Journal Sentinel and JSOnline.com.', 'daily', '', '2017-08-21 04:34:53', './uploads/nownews/sourcelogo//Millwaukee Journal Sentinel_nownewssource_57.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"itemprop","contenttagattrvalue":"articleBody"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"article-print-url"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"story-asset"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"partner-placement"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"partner-outstream"}],"keywords":[]}', 0),
(58, 'Mother Jones', 'http://www.motherjones.com/sections/Media/feed/', 'Mother Jones is a reader-supported nonprofit news organization and the winner of the American Society of Magazine Editors'' 2017 Magazine of the Year Award. Our staff does independent and investigative reporting on everything from politics and climate change to education and food (plus cat blogging). Some 11 million people come to this site each month, and we also publish a bimonthly, 200,000-circulation magazine. Last year was our 40th anniversary, and to celebrate we published an award-winning 35,000-word undercover exposé on private prisons, redesigned the site and magazine, and launched an acclaimed food podcast called Bite. You can follow us on Facebook and Twitter.\n\nWe are headquartered in San Francisco and have bureaus in Washington, DC, and New York City. We don''t answer to stockholders, a corporate parent company, or a deep-pocketed donor. Instead we''re accountable to, and funded by, you—our readers.', 'daily', '', '2018-06-18 21:31:45', './uploads/nownews/sourcelogo//Mother Jones_nownewssource_58.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"content-area"}],"exclude":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"node-footer"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"related-articles"}],"keywords":[]}', 1),
(59, 'New York Magazine', 'http://feeds.feedburner.com/nymag/intelligencer', 'NYMag - Politics, Entertainment, Fashion, Restaurants & NY', 'weekly', 'cycledescription', '2018-06-06 22:20:25', './uploads/nownews/sourcelogo//New York Magazine_nownewssource_59.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"itemprop","contenttagattrvalue":"articleBody"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"ad"},{"contenttag":"aside","contenttagattr":"class","contenttagattrvalue":"bottom-share"}],"keywords":[]}', 1),
(60, 'News on Japan', 'http://newsonjapan.com/rss/top.xml', 'Daily News on Japan in English; Business News, Economy, Stock Market, Politics, Society, Electronics; A prime source for staying updated on Japan!', 'daily', '', '2018-06-05 21:50:56', './uploads/nownews/sourcelogo//News on Japan_nownewssource_60.png', '{"thecontent":[{"contenttag":"article","contenttagattr":"class","contenttagattrvalue":"jpmpmpmpmpm"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"detailed-date"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"news-item"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"detailed-news-source"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"front-page-category-headline"}],"keywords":[]}', 1),
(61, 'Orange County Register', 'http://www.ocregister.com/feed/', 'The Orange County Register is a three-time Pulitzer Prize-winning newspaper focused on serving Orange County and helping it thrive. The Orange County Register is part of Southern California News Group, which operates 11 daily newspapers and associated websites in Southern California, multiple weekly newspapers and Spanish-language products and social channels. ', 'daily', '', '2018-06-06 16:31:48', './uploads/nownews/sourcelogo//Orange County Register_nownewssource_61.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"article-body"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"ndn_embed"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"dfp-ad"},{"contenttag":"aside","contenttagattr":"","contenttagattrvalue":""}],"keywords":[]}', 1),
(62, 'Reuters', 'http://feeds.reuters.com/reuters/topNews', '', 'daily', '', '2018-06-19 19:01:36', './uploads/nownews/sourcelogo//Reuters_nownewssource_62.png', '{"thecontent":[{"contenttag":"span","contenttagattr":"id","contenttagattrvalue":"article-text"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"group"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"bd_article2"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"bd_article"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"article-byline"}],"keywords":[]}', 1),
(63, 'Smithsonian Magazine', 'http://www.smithsonianmag.com/rss/magazine/', 'Smithsonian magazine and Smithsonian.com place a Smithsonian lens on the world, looking at the topics and subject matters researched, studied and exhibited by the Smithsonian Institution -- science, history, art, popular culture and innovation -- and chronicling them every day for our diverse readership.', 'weekly', '', '2018-05-24 20:00:00', './uploads/nownews/sourcelogo//Smithsonian Magazine_nownewssource_63.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"fsogosjgjosgas"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"external-associated-products"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"newsletter-signup-article-wrapper"},{"contenttag":"footer","contenttagattr":"","contenttagattrvalue":""},{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"tag-list"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"hidden-phone"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"hidden-desktop"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"associated-container"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"cbv-ad"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"ad-slot"}],"keywords":[]}', 1),
(64, 'Snopes.com', 'http://www.snopes.com/feed/', 'The Snopes.com web site was founded by David Mikkelson, a project begun in 1994 as an expression of his interest in researching urban legends that has since grown into the oldest and largest fact-checking site on the Internet, one widely regarded by journalists, folklorists, and laypersons alike as one of the world’s essential resources. Snopes.com is routinely included in annual “Best of the Web” lists and has been the recipient of two Webby awards. Snopes.com personnel have made multiple appearances as guests on national news programs such as 20/20, ABC World News, CNN Sunday Morning, and NPR’s All Things Considered, and they and their work have been profiled in numerous major news publications, including The New York Times, the Los Angeles Times, The Washington Post, The Wall Street Journal, and Reader’s Digest.\n\nWith over 20 years’ experience as a professional researcher and writer, David has created in Snopes.com what has come to be regarded as an online touchstone of rumor research. The site’s work has been described as painstaking, scholarly, and reliable, and has been lauded by the world’s top folklorists, including Jan Harold Brunvand, Gary Alan Fine, and Patricia Turner. Hundreds of the site’s articles have been cited by authors in a variety of disciplines, and various of their articles have been published in textbooks currently in use in the U.S. and Canadian school systems.', 'daily', '', '2018-01-27 15:57:38', './uploads/nownews/sourcelogo//Snopes.com_nownewssource_64.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"entry-content"}],"exclude":[{"contenttag":"footer","contenttagattr":"","contenttagattrvalue":""}],"keywords":[]}', 1),
(65, 'Strange Horizons', 'http://strangehorizons.com/feed/', 'Strange Horizons is a weekly magazine of and about speculative fiction. We publish fiction, poetry, reviews, essays, interviews, roundtable discussions, and art.\n\nOur definition of speculative fiction includes science fiction, fantasy, horror, slipstream, and all other flavors of fantastika. Work published in Strange Horizons has been shortlisted for or won Hugo, Nebula, Rhysling, Theodore Sturgeon, James Tiptree Jr., and World Fantasy Awards.\n\nSpeculative fiction has a vibrant and radical tradition of stories that can make us think, can critique society, and can show us how it could be otherwise, for better or worse. We aim to be part of that tradition, and to update it: in the twenty-first century, speculative fiction must be a global, inclusive literature. We want to showcase work that challenges us and delights us, by new and established writers from diverse backgrounds and with diverse concerns', 'daily', '', '2018-06-18 18:22:50', './uploads/nownews/sourcelogo//Strange Horizons_nownewssource_65.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"content"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"sharedaddy"}],"keywords":[]}', 1),
(66, 'wired magazine', 'https://www.wired.com/feed/', 'description', 'daily', '', '0000-00-00 00:00:00', './uploads/nownews/sourcelogo//wired magazine_nownewssource_66.png', '{"thecontent":[{"contenttag":"article","contenttagattr":"id","contenttagattrvalue":"ssssssssssssssssssssssssssss"}],"exclude":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"related"},{"contenttag":"p","contenttagattr":"class","contenttagattrvalue":"fader"},{"contenttag":"figure","contenttagattr":"class","contenttagattrvalue":"fader"},{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"related-vid"},{"contenttag":"a","contenttagattr":"class","contenttagattrvalue":"visually-hidden"},{"contenttag":"ul","contenttagattr":"id","contenttagattrvalue":"article-tags"}],"keywords":[]}', 0),
(67, 'zero hedge', 'http://feeds.feedburner.com/zerohedge/feed', '<p><b>Manifesto:</b></p>\n<p><b>our mission:</b></p>\n<ul>\n<li>to widen the scope of financial, economic and political information available to the professional investing public.</li>\n<li>to skeptically examine and, where necessary, attack the flaccid institution that financial journalism has become.</li>\n<li>to liberate oppressed knowledge.</li>\n<li>to provide analysis uninhibited by political constraint.</li>\n<li>to facilitate information''s unending quest for freedom.</li>\n</ul>\n\n<p>our method: pseudonymous speech...</p>\n\n<p>\nanonymity is a shield from the tyranny of the majority. it thus exemplifies the purpose behind the bill of rights, and of the first amendment in particular: to protect unpopular individuals from retaliation-- and their ideas from suppression-- at the hand of an intolerant society.\n\n   ...responsibly used.</p>\n\n<p>\nthe right to remain anonymous may be abused when it shields fraudulent conduct. but political speech by its nature will sometimes have unpalatable consequences, and, in general, our society accords greater weight to the value of free speech than to the dangers of its misuse.\n</p>\n<p>\n- mcintyre v. ohio elections commission 514 u.s. 334 (1995) justice stevens writing for the majority\n</p>\n<p>\nthough often maligned (typically by those frustrated by an inability to engage in ad hominem attacks) anonymous speech has a long and storied history in the united states. used by the likes of mark twain (aka samuel langhorne clemens) to criticize common ignorance, and perhaps most famously by alexander hamilton, james madison and john jay (aka publius) to write the federalist papers, we think ourselves in good company in using one or another nom de plume. particularly in light of an emerging trend against vocalizing public dissent in the united states, we believe in the critical importance of anonymity and its role in dissident speech. like the economist magazine, we also believe that keeping authorship anonymous moves the focus of discussion to the content of speech and away from the speaker- as it should be. we believe not only that you should be comfortable with anonymous speech in such an environment, but that you should be suspicious of any speech that isn''t.\n</p>', 'daily', '', '2018-03-26 23:31:35', './uploads/nownews/sourcelogo//zero hedge_nownewssource_67.png', '{"thecontent":[{"contenttag":"section","contenttagattr":"class","contenttagattrvalue":"node"}],"exclude":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"sub-title-box"},{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"node-links"}],"keywords":[]}', 1),
(68, 'den of geek', 'http://www.denofgeek.com/uk/feeds/all', '', 'daily', '', '2018-03-26 13:02:42', './uploads/nownews/sourcelogo//den of geek_nownewssource_68.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"ddddddg"}],"exclude":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"digiteka_wrapper"}],"keywords":[]}', 1),
(69, 'dark reading', 'http://www.darkreading.com/rss_simple.asp', 'Dark Reading: Connecting The Information Security Community\n\nLong one of the most widely-read cyber security news sites on the Web, Dark Reading is now the most trusted online community for security professionals like you. Our community members include thought-leading security researchers, CISOs, and technology specialists, along with thousands of other security professionals. We want you to join us.\n\nThis is where enterprise security staffers and decision-makers come to learn about new cyber threats, vulnerabilities, and technology trends. It''s where they discuss potential defenses against the latest attacks, and key technologies and practices that may help protect their most sensitive data in the future. It''s where they come to engage with one another and with Dark Reading editors to embrace new (and big) ideas, find answers to their IT security questions and solve their most pressing problems.\n\nDark Reading.com encompasses ten communities, each of which drills deeper into the enterprise security challenge: Attacks & Breaches, Application Security, Cloud Security, Data Leaks & Insider Threats, Endpoint Security & Privacy, Mobile Security, Network & Perimeter Security, Risk Management & Compliance, Security Management & Analytics, and Vulnerabilities and Threats. Each community is led by editors and subject matter experts who collaborate with security researchers, technology specialists, industry analysts and other Dark Reading members to provide timely, accurate and informative articles that lead to spirited discussions.\n\nOur goal is to challenge community members to think about security by providing strong, even unconventional points of view, backed by hard-nosed reporting, hands-on experience and the professional knowledge that comes only with years of work in the information security industry.\n\nWe want you to be part of this community. Please join us on live chats, story discussions, polls, radio shows, reader-generated discussion boards, newsletters and other interactive features -- all for free. We''ll also invite you to live events where we can continue these conversations face-to-face.', 'daily', '', '2018-03-26 17:30:00', './uploads/nownews/sourcelogo//dark reading_nownewssource_69.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"dummyid"}],"exclude":[{"contenttag":"header","contenttagattr":"","contenttagattrvalue":""}],"keywords":[]}', 1),
(71, 'Edge.Org', 'https://www.edge.org/feed', 'To arrive at the edge of the world''s knowledge, seek out the most complex and sophisticated minds, put them in a room together, and have them ask each other the questions they are asking themselves.', 'daily', '', '2018-03-16 23:30:33', './uploads/nownews/sourcelogo//Edge.Org_nownewssource_71.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"dummyidfordummy"}],"exclude":[],"keywords":[]}', 1),
(72, 'Cosmos Magazine', 'https://cosmosmagazine.com/feed.rss', 'Cosmos is a quarterly science magazine. We aim to inspire curiosity in ''The Science of Everything'' and make the world of science accessible to everyone.\n\nAt Cosmos, we aim to deliver the latest in science with beautiful pictures, clear explanations of the latest discoveries and breakthroughs and great writing.\n\nWinner of 47 awards for high-quality journalism and design, Cosmos is a print magazine, online digital edition updated daily, a daily and weekly e-Newsletter and educational resource with custom, curriculum-mapped lessons for years 7 to 10.', 'daily', '', '2018-03-26 18:02:00', './uploads/nownews/sourcelogo//Cosmos Magazine_nownewssource_72.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"id","contenttagattrvalue":"ssssssssssss"}],"exclude":[],"keywords":[]}', 1),
(73, 'CakNun', 'http://feeds.caknun.com/caknundotcom', '<p>CAKNUN.COM merupakan website yang diusulkan secara langsung oleh Cak Nun kepada Progress yang sekaligus ditunjuk untuk mengelola.</p>\n<p>\nKonsep konten yang ada di website ini sebagian besar merupakan ide Cak Nun sendiri, juga masukan dari Sabrang Mowo Damar Panuluh (Noe Letto), Toto Rahardjo, Cak Zakki dan lainnya. Progress hanya berusaha mengimplementasikannya dalam bentuk website agar semudah mungkin dikelola dan dibaca, sekaligus menyediakan serta mengolah bahan yang ada termasuk dokumentasi foto dan video, juga arsip-arsip tulisan yang relevan untuk dimuat di website ini.</p>', 'weekly', '', '2018-06-02 13:17:52', './uploads/nownews/sourcelogo//CakNun_nownewssource_73.png', '{"thecontent":[{"contenttag":"div","contenttagattr":"class","contenttagattrvalue":"entry-content"}],"exclude":[{"contenttag":"aside","contenttagattr":"","contenttagattrvalue":""}],"keywords":[]}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(11) NOT NULL,
  `rssid` int(11) NOT NULL,
  `log` text NOT NULL,
  `time` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userdownload`
--

CREATE TABLE IF NOT EXISTS `userdownload` (
  `id` int(11) NOT NULL,
  `rssids` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `request_time` datetime NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `browser` text NOT NULL,
  `ipaddr` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `usersearch`
--

CREATE TABLE IF NOT EXISTS `usersearch` (
  `id` int(11) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `submitted` date DEFAULT NULL,
  `source` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sourcecategory` (`name`,`source`),
  ADD KEY `source` (`source`);

--
-- Indexes for table `downloadedrss`
--
ALTER TABLE `downloadedrss`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ulatestrss` (`pubDate`,`link`,`newssource`) USING BTREE;

--
-- Indexes for table `keytonews`
--
ALTER TABLE `keytonews`
  ADD KEY `newsid` (`newsid`),
  ADD KEY `keyid` (`keyid`);

--
-- Indexes for table `keywords`
--
ALTER TABLE `keywords`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `keyword` (`keyword`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rssid` (`rssid`);

--
-- Indexes for table `newsimages`
--
ALTER TABLE `newsimages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletters`
--
ALTER TABLE `newsletters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniqnewsletteremail` (`email`);

--
-- Indexes for table `newslettersettings`
--
ALTER TABLE `newslettersettings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniqnewslettersett` (`source`,`category`,`keywords`,`newsletterid`) USING BTREE;

--
-- Indexes for table `newssource`
--
ALTER TABLE `newssource`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userdownload`
--
ALTER TABLE `userdownload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ipaddr` (`ipaddr`);

--
-- Indexes for table `usersearch`
--
ALTER TABLE `usersearch`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniqusersearch` (`keyword`,`submitted`,`source`,`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `downloadedrss`
--
ALTER TABLE `downloadedrss`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `keywords`
--
ALTER TABLE `keywords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `newsimages`
--
ALTER TABLE `newsimages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `newsletters`
--
ALTER TABLE `newsletters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `newslettersettings`
--
ALTER TABLE `newslettersettings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `newssource`
--
ALTER TABLE `newssource`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `userdownload`
--
ALTER TABLE `userdownload`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `usersearch`
--
ALTER TABLE `usersearch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
