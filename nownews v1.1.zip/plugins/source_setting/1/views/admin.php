<?php
    $options = '';
    $counter = 1;
    foreach($pagevar['plugin']['source_setting']['source'] as $sourcek=>$sourcev){
        $selected = $pagevar['selectednewssource'] == $sourcev['id'] ? ' selected="selected"' : '';
        $status = $sourcev['status'] == 1 ? 'active' : 'inactive';
        $options .= '<option class="sourceitemopt" value="'. $sourcev['id'] .'"'. $selected .'>'.$counter.'. '. $sourcev['name'] .' - '. $status .'</option>';
        $counter++;
    }
?>
<?php include_once('header.php'); ?>
            
<div class="pagecontent pagecontent_sourcesettingmenu" id="sourcesettingreport">
    <?php include_once('reports.php'); ?>
</div>

<div class="pagecontent pagecontent_sourcesettingmenu" id="sourcesettingaddnew">
    <?php include_once('addnew.php'); ?>
</div>

<div class="pagecontent pagecontent_sourcesettingmenu active" id="sourcesettingedit">
   <?php include_once('edit.php'); ?>
</div>

<img src ="<?php echo App::$config['uploads'].'nownews/nownews.source.uploaded.png'; ?>" class="hide" id="nownewsquestionmarkimg">
<img src ="<?php echo App::$config['uploads'].'nownews/nownews.source.png'; ?>" class="hide" id="nownewslogomarkimg">