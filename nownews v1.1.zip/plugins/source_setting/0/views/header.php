<div class="pageheader">
    <h3 class="ptitle">Source Setting</h3>
    <ul id="sourcesettingmenu" class="adminmenus">
        <li class="<?php if($pagevar['currentp'] == 'reports') echo 'active'; ?>" id="adminmenu_sourcesettingreport">
            Reports
        </li>
        <li class="<?php if($pagevar['currentp'] == 'addnew') echo 'active'; ?>" id="adminmenu_sourcesettingaddnew">
            Add New
        </li>
        <li class="<?php if($pagevar['currentp'] == 'admin') echo 'active'; ?>" id="adminmenu_sourcesettingedit">
            Edit
        </li>
    </ul>
</div>
<?php
    $messageclass = 'message';
    if(isset($pagevar['message'])){
        $messageclass .= ' active';
    }
    else{
        $pagevar['message'] = '';
    }
?>