<?php

echo json_encode($pagevar['response']);

?>