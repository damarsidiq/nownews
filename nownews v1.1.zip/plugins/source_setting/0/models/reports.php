<?php

Class Reports_source_setting extends PluginModel{
    var $pagecontentlimit = 10;
    function __construct($pluginid){
        parent::__construct($pluginid,'reports');
    }
    
    public function networkrelated($data=false){
        $limit = ($this->pagecontentlimit+1);
        $extracondi = isset($data['lastinpage']) ? array('id'=>array('<',$data['lastinpage'])) : [];
        
        $condi = array('log'=>array('LIKE','fopen'));
        $condi = array_merge($condi,$extracondi);
        
        $networkrelated = $this->getrecords($condi,null,array('id','desc'),$limit);
        if($networkrelated === false){
            $this->printerrors();
        }
        $response = array();
        $limitreached = false;
        $thecount = count($networkrelated);
        if($thecount){
            foreach($networkrelated as $nk=>$nv){
                $networkrelated[$nk]['log']  = json_decode($nv['log'],true);
                
                if(count($extracondi)){
                    foreach($networkrelated[$nk]['log'] as $key=>$value){
                        if($value=='')
                        $networkrelated[$nk]['log'][$key] = '""';
                    }
                    $networkrelated[$nk]['log'] = implode(',',$networkrelated[$nk]['log']);
                    $networkrelated[$nk]['time'] = date('l, d-m-Y H:i:s',strtotime($networkrelated[$nk]['time']));
                }
            }
            $response = $networkrelated;
            if(count($networkrelated) <= ($this->pagecontentlimit))
                $limitreached = true;
            else{
                unset($response[$thecount-1]);
            }
        }
        else{
                $limitreached = true;
        }
        return array($response,$limitreached);
    }
    public function emptycontent($data=false){
        $limit = ($this->pagecontentlimit+1);
        $extracondi = isset($data['lastinpage']) ? array('id'=>array('<',$data['lastinpage'])) : [];
        
        $condi = array('log'=>array('LIKE','emptynewscontent'));
        $condi = array_merge($condi,$extracondi);
        
        $emptycontent = $this->getrecords($condi,null,array('id','desc'),$limit);
        if($emptycontent === false){
            $this->printerrors();
        }
        $response = array();
        $limitreached = false;
        $thecount = count($emptycontent);
        if($thecount){
            foreach($emptycontent as $nk=>$nv){
                $emptycontent[$nk]['log']  = json_decode($nv['log'],true);
                foreach($emptycontent[$nk]['log'] as $key=>$value){
                    if($value=='')
                    $emptycontent[$nk]['log'][$key] = '""';
                }
                $emptycontent[$nk]['log'] = implode(',',$emptycontent[$nk]['log']);
                
                $emptycontent[$nk]['time'] = date('l, d-m-Y H:i:s',strtotime($emptycontent[$nk]['time']));
            }
            $response = $emptycontent;
            if($thecount <= ($this->pagecontentlimit))
                $limitreached = true;
            else{
                unset($response[$thecount-1]);
            }
        }
        else{
                $limitreached = true;
        }
        return array($response,$limitreached);
    }
    public function others($data=false){
        $limit = ($this->pagecontentlimit+1);
        $extracondi = isset($data['lastinpage']) ? array('id'=>array('<',$data['lastinpage'])) : [];
        
        
        $condi = array('and'=>array(0=>array('log'=>array('NOT LIKE','fopen')),1=>array('log'=>array('NOT LIKE','emptynewscontent'))));
        $condi = array_merge($condi,$extracondi);
        
        $others = $this->getrecords($condi,null,array('id','desc'),$limit);
        if($others === false){
            $this->printerrors();
        }
        $response = array();
        $limitreached = false;
        $thecount = count($others);
        if($thecount){
            foreach($others as $nk=>$nv){
                $others[$nk]['log']  = json_decode($nv['log'],true);
                foreach($others[$nk]['log'] as $key=>$value){
                    if($value=='')
                    $others[$nk]['log'][$key] = '""';
                }
                $others[$nk]['log'] = implode(',',$others[$nk]['log']);
                $others[$nk]['time'] = date('l, d-m-Y H:i:s',strtotime($others[$nk]['time']));
            }
            $response = $others;
            if($thecount <= ($this->pagecontentlimit))
                $limitreached = true;
            else{
                unset($response[$thecount-1]);
            }
        }
        else{
            $limitreached = true;
        }
        return array($response,$limitreached);
    }
    public function deleteReport($errorid){
        $deleted = $this->deleterecords(array('id'=>$errorid));
        if($deleted == 1)
            return true;
        
        return false;
    }
}

?>