<?php

Class Newslettersettings extends Model{
    var $testmode;
    var $today;
    var $todaytime;
    var $tomorrow;
    var $aday;
    var $aweek;
    var $amonth;
    
    function __construct(){
        parent::__construct('newslettersettings');
        $this->today      = date('Y-m-d', time());
        $this->todaytime  = strtotime($this->today);
        $this->tomorrow   = date('Y-m-d', ($this->todaytime+(3600*24)) );
        $this->testmode  = '2016-02-27';
        
        $this->aday       = 86400;
        $this->aweek      = 604800;
        $this->amonth     = 2678400;
    }
    
    public function addSettings($newsletterid,$sourcesetting){
        foreach($sourcesetting as $akey=>$aval){
            foreach($aval as $key=>$val){
                if(is_array($val))
                    $settingsadded = $this->addrecord(array('newsletterid','source','category','keywords','nextfetch'),array($newsletterid,$aval['source'],$val['category'],$val['keywords'], $this->tomorrow ));
            }
        }
        return true;
    }
    public function updateSettings($newsletterid,$sourcesetting){
        $this->removeNewsletterSettings($newsletterid);
        return $this->addSettings($newsletterid,$sourcesetting);
    }
    public function getNewsletterSettings($newsletterid){
        $settings = $this->getrecords(array('newsletterid'=>$newsletterid),null,array('source','DESC'));
        $newsletsett = array();
        $sourceidx = array();
        foreach($settings as $sk=>$sv){
            if(!isset($sourceidx[$sv['source']])){
                $sourceidx[$sv['source']] = 1;
            }
            $settingidx = count($sourceidx)-1;
            
            $idx = isset($newsletsett[$settingidx]) ? count($newsletsett[$settingidx]) : 0;
            $newsletsett[$settingidx][$idx] = $sv;
        }
        return $newsletsett;
    }
    public function removeNewsletterSettings($newsletterid){
        $deleted = $this->deleterecords(array('newsletterid'=>$newsletterid));
        return $deleted;
    }
    public function updateNextFetch($newslettersettings){
        foreach($newslettersettings as $sk=>$sv){
            if(isset($sv['lastfetched'])){
                $lastfetched    = $sv['lastfetched'];
                $nexttime       = $sv['cycle'] == 'daily' ? $this->aday : ($sv['cycle'] == 'weekly' ? $this->aweek : ($sv['cycle'] == 'monthly' ? $this->amonth : $this->aday));
                $newnextfetch   = date('Y-m-d',(strtotime($sv['lastfetched'])+$nexttime));
                
                $this->query('update newslettersettings set nextfetch="'. $newnextfetch .'" where nextfetch="'. $this->testmode .'" and source='.$sv['source']);       
            }
        }
    }
    public function newsletterToUpdate(){
        $tofetch = $this->fetchQueryResult($this->query('select ns.source,ns.category,ns.keywords,s.cycle from newslettersettings ns,newssource s where ns.nextfetch = "'. $this->testmode .'" and ns.source=s.id group by ns.source,ns.category,ns.keywords order by ns.source,ns.category asc'));
        
        return array($tofetch,$this->userNewsletterToUpdate());
    }
    public function userNewsletterToUpdate(){        
        $usersnewsletter = $this->fetchQueryResult($this->db->query('select n.userid,n.email,n.status,ns.newsletterid,ns.source,ns.category,ns.keywords from newslettersettings ns,newsletters n where ns.nextfetch = "'. $this->testmode .'" and n.id = ns.newsletterid order by n.email asc'));
        return $usersnewsletter;
    }
}


?>