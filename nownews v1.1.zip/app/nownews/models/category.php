<?php

Class Category extends Model{
    function __construct(){
        parent::__construct('category');
    }
    public function newCategory($sourceid,$name='',$total=1){
        return $this->addrecord(array('source','name','total'),array($sourceid,$name,$total));
    }
    public function categoryName($categoryid,$tags=array()){
        if(!is_array($tags)){
            $tags = explode(',',$tags);
        }
        if(!empty($tags)){
            $categoriesname = '';
            $categories = array_merge(array($categoryid),$tags);
            
            foreach($categories as $ck=>$cv){
                if($cv != '')
                    $categoriesname .= $this->getrecord(array('id'=>$cv),array('name')).', ';
            }
            $categoriesname = substr($categoriesname,0,-2);
            return $categoriesname;
        }
        
        return $this->getrecord(array('id'=>$categoryid),array('name'));
    }
    public function getId($name,$sourceid,$addnew = true){
        $categoryid = $this->getrecord(array('name'=>$name,'source'=>$sourceid),'id');
        if($categoryid!== false){
            return $categoryid;
        }
        if($this->newCategory($sourceid,$name)){
            return $this->insertid();
        }
    }
    public function getBySource($sourceid){
        return $this->getrecords(array('source'=>$sourceid));
    }
    public function updateTotal($name,$source,$addition){
        $category   = $this->getrecord(array('source'=>$source,'name'=>$name), array('id','total'));
        if(count($category)){
            $total      = $category[0]['total'];
            $id         = $category[0]['id'];
            $newtotal   = $total + $addition;
            
            $this->updaterecord(array('total'=>($newtotal)), array('id'=>$id));
        }
        else{
            $this->newCategory($source,$name,$addition);
        }        
    }
    public function addTotal($name,$source){
        $category   = $this->getrecord(array('source'=>$source,'name'=>$name), array('id','total'));
        $total      = $category[0]['total'];
        $id         = $category[0]['id'];
        $newtotal   = $total + 1;
        
        $this->updaterecord(array('total'=>($newtotal)), array('id'=>$id));
    }
}


?>