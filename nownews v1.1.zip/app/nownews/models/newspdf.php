<?php

Class NewsPdf extends Model{
    var $pdfheader;
    var $pdfcontent;
    var $uploads;
    var $nownewslogo;
    var $undecoded;
    var $undecodedreplacement;
    function __construct(){
        parent::__construct();
        require_once(Pxpedia::getConfig('resources').'html2pdf/html2pdf.class.php');

        $this->uploads      = Pxpedia::getConfig('uploads');
        $this->nownewslogo  = $this->uploads.'subscriptioncoverlogo2.png';

        /*
        $this->pdfheader = '<page backtop="14mm" backbottom="14mm" backleft="10mm" backright="10mm">
                                <bookmark title="Cover" level="0" ></bookmark>
                                <div id="coverbg"><img id="coverlogo" src="'.$this->nownewslogo.'"></div>
                            </page>';

        $this->pdfheader    .= '<style type="text/css">
                            <!--
                                page{font-family:Arial;}
                                a{color:#949494;text-decoration: none;font-size: 34px;}
                                .articletitle{display: inline-block;width:100%;height: 30px;font-size: 34px;font-weight: bold;color: #404040;line-height: 36px;margin-bottom: 22px;}
                                .articledate{clear: both;color: #949494;display: inline-block;font-size: 22px;font-weight: 400;height: 30px;width: 100%;color: #949494;}
                                .articleattribute{font-size:22px;color: #949494;}
                                .articlecontent{display: block;width: 100%;clear: both;margin-top:12px;font-size:27px;color:#404040;}
                                img{display: block;margin:25px auto 25px 300px;max-width: 50%;height:auto;clear: both;}
                                li{padding:0px;margin:5px 0px;}
                                p{display: block;margin-bottom: 1em;margin-top: 1em;}
                                bookmark{display:none;}
                                #coverbg{position:relative;width:100%;height:100%;background:url('.$this->uploads.'/subscriptioncoverbg.png) repeat;}
                                #coverlogo{position:absolute;top:50%;margin-top:-77px;left:50%;margin-left:-353px;display:block;}
                            -->
                            </style>';
        */

        $this->pdfheader = '<div id="coverbg"><img id="coverlogo" src="'.$this->nownewslogo.'"></div>';

        $this->pdfheader    .= '<style type="text/css">
                            <!--
                                html{font-family:Arial;}
                                a{color:#949494;text-decoration: none;font-size: 34px;}
                                .articletitle{page-break-before:always;clear:both;display:block;width:100%;height:auto;font-size: 34px;font-weight: bold;color: #404040;line-height: 36px;margin-bottom: 22px;}
                                .articledate{clear: both;color: #949494;display: inline-block;font-size: 22px;font-weight: 400;height: 30px;width: 100%;color: #949494;}
                                .articleattribute{font-size:22px;color: #949494;}
                                .articlecontent{display: block;width: 100%;clear: both;margin-top:12px;font-size:27px;color:#404040;}
                                img{display: block;margin: auto;max-width: 100%;}
                                li{padding:0px;margin:5px 0px;}
                                h2{margin: 0px;}
                                p{display: block;margin-bottom: 1em;margin-top: 1em;}
                                #coverbg{position:relative;width:100%;height:100%;background:url('.$this->uploads.'/subscriptioncoverbg.png) repeat;}
                                #coverlogo{position:absolute;top:50%;margin-top:-77px;left:50%;margin-left:-250px;display:block;}
                                ul{padding:0px;margin:0px;}
                            -->
                            </style>';

        $this->undecoded = array('&apos;','&lt;','&gt;');
        $this->undecodedreplacement = array('','(',')');
        $this->pdfcontent = '';
    }
    public function pdfContent($reset=false){
        $content = $this->pdfcontent;
        if($reset)
            $this->pdfcontent = '';

        return $content;
    }
    public function cleanstr($str,$setlandscape=true){
         //return str_replace(array('<figcaption','figcaption>','<figure','figure>','<section','section>','<aside','aside>'),array('<p','p>','<p','p>','<div','div>','<div','div>'),htmlspecialchars_decode(str_replace($this->undecoded,$this->undecodedreplacement,$str),ENT_QUOTES));
         $cs = htmlspecialchars_decode(str_replace($this->undecoded,$this->undecodedreplacement,$str),ENT_QUOTES);
         $cs = str_replace(array('/p>','<p'),array('/div>','<div'),$cs);

        if(strpos($cs,'<img') === false){
          return $cs;
        }
         $cs = explode('<img',$cs);


         $a4 = $setlandscape ? array('72'=>array(595,842),'96'=>array(794,1123),'150'=>array(1240,1754),'300'=>array(2480,3508)) : array('72'=>array(842,595),'96'=>array(1123,794),'150'=>array(1754,1240),'300'=>array(3508,2480));
         foreach ($cs as $l=>$value) {
             if($value =='')
                continue;


             if($l >0){
                 $i = explode('src="',$value);
                 $i = explode('"',$i[1])[0];
                 
                 if(!file_exists($i)){
                     continue;
                 }
                 
                 list($width,$height) = @getimagesize($i);

                 $x = explode('>',$value);
                 $marginleft= $width<($a4['96'][1]-90) ? ((($a4['96'][1]-90)-$width)/2) : 0;
                 $width = $marginleft == 0 ? ($a4['96'][1]-90) : $width;
                 $height= min($height,($a4['96'][0]-90));
                 $margintop = $height < ($a4['96'][0]-90) ? round((($a4['96'][0]-90)-$height)/2) : 0;
                 
                 
                 $x[0] = ' style="height:'.$height.'px;margin:auto;margin-left:'.$marginleft.'px;margin-top:'.$margintop.'px;width:'.$width.'px;" '.$x[0];
                 $x[1] = '</div>'.$x[1];
                 $value = implode('>',$x);

                $cs[$l] = $value;

                $value = '<div style="page-break-before:always;page-break-after:always;clear:both;width:100%;text-align:center;height:100%;background:white">';
                $cs[$l-1] = $cs[$l-1].$value;
             }
         }
         $cs = implode('<img',$cs);
         return $cs;
    }
    public function newsitem($rssitem){
        /*
        $this->pdfcontent .= '<page pageset="old">
                             <bookmark title="'. $this->cleanstr($rssitem['title']) .'" level="0" ></bookmark>';
         */
            $this->pdfcontent .= '<div class="articletitle">'. $this->cleanstr($rssitem['title']).'</div>'
                             .'<div class="articledate">'. date('l, F jS Y H:i:s',strtotime($rssitem['pubDate'])).' By '. $rssitem['creator'] .'</div>'
                                 .'<table class="articleattribute">'
                                     .'<tr><td>Publisher</td><td>:</td><td>'. $rssitem['publisher'].'</td></tr>'
                                     .'<tr><td>Category</td><td>:</td><td>'. $rssitem['categories'].'</td></tr>'
                                 .'</table>'
                             .'<div class="articlecontent">'. $this->cleanstr($rssitem['newscontent']).'</div>';

        //$this->pdfcontent .= '</page>';
    }
    public function savedompdf($index,$content){
        $location       = $this->uploads;
        $locationname   = $location.'NOW.NEWS-'. date('l, F jS Y',time()) .'_'.$index.'.pdf';


        require_once Pxpedia::getConfig('resources').'dompdf/lib/html5lib/Parser.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-svg-lib/src/autoload.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Autoloader.php';


        require_once Pxpedia::getConfig('resources').'dompdf/src/CanvasFactory.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Options.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Dompdf.php';
        Dompdf\Autoloader::register();

        $dompdf = new DompdfDompdf();

        $dompdf->loadHtml($this->pdfheader.$content);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        $out = $dompdf->output();

        $handler = @fopen($locationname,'wb');
        $response = fputs($handler,$out);

        return $locationname;
    }
    public function outputdompdf(){
        require_once Pxpedia::getConfig('resources').'dompdf/lib/html5lib/Parser.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-svg-lib/src/autoload.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Autoloader.php';


        require_once Pxpedia::getConfig('resources').'dompdf/src/CanvasFactory.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Options.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Dompdf.php';
        Dompdf\Autoloader::register();

        $dompdf = new Dompdf\Dompdf();

        $dompdf->loadHtml($this->pdfheader.$this->pdfcontent);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        //echo $this->pdfheader.$this->pdfcontent;
        $this->pdfcontent = '';
        //exit();

        $dompdf->stream('NOW.NEWS-'. date('l, F jS Y',time()) .'_'.$index.'.pdf');
    }
    public function savePdf($index,$content){
        return $this->savedompdf($index,$content);

        $location       = $this->uploads;
        $locationname   = $location.'NOW.NEWS-'. date('l, F jS Y',time()) .'_'.$index.'.pdf';
        try{
            $html2pdf = new HTML2PDF('L', 'A4', 'en', true, 'UTF-8', array(17, 0, 17, 0),false);

            $html2pdf->pdf->SetDisplayMode('fullpage');

            $html2pdf->writeHTML($this->pdfheader.$content, false);
            $html2pdf->Output($locationname,'F');


            return $locationname;
        }
        catch(HTML2PDF_exception $e){
            echo $e;
            exit;
        }
    }
    public function output(){
        $this->outputdompdf();
        exit();

        try{
            $html2pdf = new HTML2PDF('L', 'A3', 'en', true, 'UTF-8', array(17, 0, 17, 0),false);
            $html2pdf->pdf->SetDisplayMode('fullpage');
            $html2pdf->writeHTML($this->pdfheader.$this->pdfcontent, false);
           //echo print_R($html2pdf->parsingHtml,true);exit();
            //echo $html2pdf->pdf->getBuffer();exit();
            //echo $this->pdfheader.$this->pdfcontent;exit();
            $this->pdfcontent = '';

            $html2pdf->Output('NOW.NEWS-'. date('l, F jS Y',time()) .'.pdf','I');
        }
        catch(HTML2PDF_exception $e){
            echo $e;
            exit;
        }
    }


}


?>