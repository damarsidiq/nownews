<?php

Class Reports extends Model{
    function __construct(){
        parent::__construct('reports');
    }
    
    public function addreport($rss,$contentfetched=false,$log=false){
        $log = array($contentfetched,$log,$rss['newssource']);
        $this->addrecord(array('rssid','log','time'),array($rss['id'],json_encode($log),date('Y-m-d H:i:s',time())));
        return;
    }
    public function addrssreport($source,$rssfetched=false,$log=false){
        $log = array($rssfetched,$log,$source['id']);
        $reported = $this->addrecord(array('rssid','log','time'),array(0,json_encode($log),date('Y-m-d H:i:s',time())));
        if($reported == false){
            echo $this->printerrors();
        }
        
        return;
    }
}


?>