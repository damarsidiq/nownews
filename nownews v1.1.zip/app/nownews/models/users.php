<?php

Class Users extends Model{
    function __construct(){
        parent::__construct('users');
    }
    
    
    public function addUser($browser,$ipaddr){
        $id = $this->getrecord(array('ipaddr'=>$ipaddr),'id');
        if($id){
            return $id;
        }
        
        $this->addrecord(array('browser','ipaddr'),array($browser,$ipaddr));
        return $this->insertid();
    }
    
}


?>