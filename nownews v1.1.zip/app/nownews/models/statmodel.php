<?php

Class statModel extends Model{
    function __construct(){
        parent::__construct();
    }
  
    public function topArticles($start,$end){
        if($start==0 && $end==0){
            $querystr = 'select id,title,downloadcount from downloadedrss order by downloadcount desc limit 20';
        }
        else{
            if($start != 0){
                if($end==0){
                    $querystr = 'select id,title,downloadcount from downloadedrss where pubDate>="'. $start .'" order by downloadcount desc limit 20';
                }
                else{
                    $querystr = 'select id,title,downloadcount from downloadedrss where pubDate>="'. $start .'" and pubDate<="'. $end .'" order by downloadcount desc limit 20';
                }
            }
            else{
                $querystr = 'select id,title,downloadcount from downloadedrss where pubDate<="'. $end .'" order by downloadcount desc limit 20';
            }
        }
        
        $query = $this->query($querystr);
        if($query){
            return $this->fetchQueryResult($query);
        }
    }
    public function topSource($start,$end){
        if($start==0 && $end==0){
            $querystr = 'select top.*,newssource.name from (select sum(downloadcount) as totalsourcedownload,newssource from downloadedrss group by newssource order by totalsourcedownload desc limit 20) as top,newssource where newssource.id=top.newssource';
        }
        else{
            if($start != 0){
                if($end==0){
                    $querystr = 'select top.*,newssource.name from (select sum(downloadcount) as totalsourcedownload,newssource from downloadedrss where pubDate>="'. $start .'" group by newssource order by totalsourcedownload desc limit 20) as top,newssource where newssource.id=top.newssource';
                }
                else{
                    $querystr = 'select top.*,newssource.name from (select sum(downloadcount) as totalsourcedownload,newssource from downloadedrss where pubDate>="'. $start .'" and pubDate<="'. $end .'" group by newssource order by totalsourcedownload desc limit 20) as top,newssource where newssource.id=top.newssource';
                }
            }
            else{
                $querystr = 'select top.*,newssource.name from (select sum(downloadcount) as totalsourcedownload,newssource from downloadedrss where pubDate<="'. $end .'" group by newssource order by totalsourcedownload desc limit 20';
            }
        }
        
        $query = $this->query($querystr);
        if($query){
            return $this->fetchQueryResult($query);
        }
    }
    public function topKeywords($start,$end){
        if($start==0 && $end==0){
            $querystr = 'select trendcount.trending,keywords.keyword from (select keyid,count(*) as trending from keytonews group by keyid order by trending desc limit 20) as trendcount,keywords where trendcount.keyid = keywords.id';
        }
        else{
            if($start != 0){
                if($end==0){
                    $querystr = 'select trendcount.trending,keywords.keyword from (select keyid,count(*) as trending from keytonews where newsid in(select id from news where rssid in(select id from downloadedrss where pubDate >= "'. $start .'" )) group by keyid order by trending desc limit 20) as trendcount,keywords where trendcount.keyid = keywords.id';
                }
                else{
                    $querystr = 'select trendcount.trending,keywords.keyword from (select keyid,count(*) as trending from keytonews where newsid in(select id from news where rssid in(select id from downloadedrss where pubDate >= "'. $start .'" and pubDate<="'. $end .'" )) group by keyid order by trending desc limit 20) as trendcount,keywords where trendcount.keyid = keywords.id';
                }
            }
            else{
                $querystr = 'select trendcount.trending,keywords.keyword from (select keyid,count(*) as trending from keytonews where newsid in(select id from news where rssid in(select id from downloadedrss where pubDate <= "'. $end .'" )) group by keyid order by trending desc limit 20) as trendcount,keywords where trendcount.keyid = keywords.id';
            }
        }
        
        $query = $this->query($querystr);
        if($query){
            return $this->fetchQueryResult($query);
        }
    }
}


?>