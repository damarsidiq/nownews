<?php 
Class Bulktest extends Controller{
	function __construct(){
		parent::__construct();
	}
	
	public function enctest(){
	    $content = '’';
	    $content = str_replace(array('‘','’','“','”','—'),array("'","'",'"','"','-'),$content);
	    $tes = $this->model('news')->fixencoding($content);
	    echo $tes;
	    return 'plain';
	}
	
	public function fixdb($data){
	    $w = $this->query('delete from downloadedrss where id not in(select rssid from news)');
	}
}
