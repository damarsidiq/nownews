<?php
Class Ajax extends Controller{
    var $fopenerror;
    function __construct(){
        parent::__construct();
        $this->setPagevar('ajax',true);
    }
    public function tesimagedownload($data){
        $imagereading = $this->model('newsimages')->imageexists($data['i']);
        echo '$$$$$$$$'.print_r($imagereading,true).'$%$$$$$$$$';
        return 'plain';
    }
    public function tesencode(){
        echo rawurlencode('https://i.guim.co.uk/img/media/f69c458ae0dc1bbdc009cf28ff478dc1426ac944/0_346_5184_3110/master/5184.jpg?w=300&q=55&auto=format&usm=12&fit=max&s=2be0ee5bdc8b9287555d774486992e4f');
        echo '<br/>~~~~~~~~~~~~~~~~~~~~<br/>';
        echo urlencode('https://i.guim.co.uk/img/media/f69c458ae0dc1bbdc009cf28ff478dc1426ac944/0_346_5184_3110/master/5184.jpg?w=300&q=55&auto=format&usm=12&fit=max&s=2be0ee5bdc8b9287555d774486992e4f');
        echo '<br/>~~~~~~~~~~~~~~~~~~~~<br/>';
        
        echo 'https%3A%2F%2Fi.guim.co.uk%2Fimg%2Fmedia%2Ff69c458ae0dc1bbdc009cf28ff478dc1426ac944%2F0_346_5184_3110%2Fmaster%2F5184.jpg%3Fw%3D300%26q%3D55%26auto%3Dformat%26usm%3D12%26fit%3Dmax%26s%3D2be0ee5bdc8b9287555d774486992e4f';
        
        return 'plain';
    }
    public function downloadPDF($data){
        $userid                         = $data['userid'] == 0 ? $this->model('users')->addUser(Pxpedia::$browser,Pxpedia::$visitorip) : $data['userid'];
        $data                           = $data['rssids'];
        list($downloaditem,$downloaded) = $this->model('news')->flagdownloadednews($data);
        $downloadstatus                 = 0;
        
        if($downloaded == count($data)){
            $downloadstatus = $downloaded;
            
            foreach($downloaditem as $key=>$val){
                $this->model('downloadedrss')->updateDownloadCount($val['rssid']);
            }
        }
        
        $downloadrecord = $this->model('userdownload')->addDownload($data,$userid,$downloaded);
        if($downloadrecord)
            $downloadid = $this->model('userdownload')->insertid();
        
        $response = array('downloaded'=>$downloaded,'downloadid'=>$downloadid,'status'=>$downloadstatus,'userid'=>$userid);
        $this->setPagevar('response',$response);
    }
    public function downloadDownloadItems($data){
        $userdownload   = $this->model('userdownload')->getItem($data['downloadid']);
        $downloadid     = $data['downloadid'];
        $rssids         = $userdownload['rssids'];
        $downloaded     = $userdownload['status'];
        
        if(strpos($rssids,',') !== false){
            $rssids = explode(',',$rssids);
        }
        else{
            $rssids = array($rssids);
        }
        
        if($userdownload['status'] < count($rssids)){
            list($downloaditem,$downloaded) = $this->model('news')->flagdownloadednews($rssids);
            foreach($downloaditem as $downloaditemkey=>$downloaditemval){
                if($downloaditem[$downloaditemkey]['downloaded'] === false){
                    $rssitem                = $this->model('downloadedrss')->getItem($downloaditemval['rssid']);
                    
                    $newscontent = $this->downloadArticle($rssitem);
                    
                    $downloaditem[$downloaditemkey]['content'] = $newscontent;
                    $downloaded+=1;
                    $this->model('userdownload')->updateStatus($downloadid,($downloaded));
                }
            }
        }
        $response = array('downloaded'=>$downloaded,'downloadid'=>$downloadid,'status'=>count($rssids));
        $this->setPagevar('response',$response);
    }
    public function extractkeywords($xmldata,$keywordsett){
        $thekeywords = array();
        foreach($keywordsett as $keywordnodek=>$keywordnodev){
           $node = $keywordnodev;
           
           $keywordnode    = Pxpedia::xmldata($node,'',$xmldata);
           if(count($keywordnode)){
               $response   = $keywordnode;
               foreach($response as $responsek=>$responsev){
                    foreach($responsev['attribute'] as $attk=>$attv){
                        if(strpos($attv,'content') !== false){
                            $response = trim(str_replace(array('"','=','content','}','/','{',"'",'(',')'),array(''),$attv));
                            $thekeywords = array_merge($thekeywords,explode(',',$response));
                        }
                    }
               }
               break;
           }
        }
        $filteredkeys = array();
        foreach($thekeywords as $thekeywordsk=>$thekeywordsv){
            $thekeywords[$thekeywordsk] = str_replace('/','',strtolower(trim($thekeywordsv)));
            if($thekeywords[$thekeywordsk] != '')
                $filteredkeys[] = $thekeywords[$thekeywordsk];
        }
        return $filteredkeys;
    }
    public function updateDownloadNow($data){
        $downloadid         = $data['downloadid'];
        $downloaditem       = $this->model('userdownload')->getItem($data['downloadid']);
        $downloadrssids     = $downloaditem['rssids'];
        
        if(strpos($downloaditem['rssids'],',') !== false){
            $downloaditem['rssids'] = explode(',',$downloaditem['rssids']);
        }
        else{
            $downloaditem['rssids'] = array($downloaditem['rssids']);
        }
                        
        if(count($downloaditem['rssids']) > $downloaditem['status']){
            $response['status']             = 'downloading';
            list($updated,$downloaded) = $this->model('news')->flagdownloadednews( $downloaditem['rssids']);
            
            foreach($updated as $downloaditemkey=>$downloaditemval){
                $newsitems = array();
                if($updated[$downloaditemkey]['downloaded'] === false){
                    $rssitem        = $this->model('downloadedrss')->getItem($downloaditemval['rssid']);
                    
                    $articlecontent = $this->downloadArticle($rssitem);
                    
                    $updated[$downloaditemkey]['content'] = $articlecontent;
                    if($this->fopenerror){
                        $o = $this->model('news')->addrecord(array('news','rssid'),array($articlecontent,$downloaditemval['rssid']));
                    }
                    $downloaded+=1;
                    $this->model('userdownload')->updateStatus($downloadid,($downloaded));
                    
                    if($downloaded == count($downloaditem['rssids']))
                        $response['status']             = 'finished';
                        
                        $newsitemidx = count($newsitems);
                        $newsitems[$newsitemidx]['content'] = $articlecontent;
                        $newsitems[$newsitemidx]['id']      = $downloaditemval['rssid'];
                        
                    break;
                }
            }
            $response['newsitems'] = $newsitems;
        }
        else{
            $response['status']             = 'finished';
            list($updated,$downloaded) = $this->model('news')->flagdownloadednews( $downloaditem['rssids']);
            
            foreach($updated as $key=>$val){
                $this->model('downloadedrss')->updateDownloadCount($val['rssid']);
            }
            
            $newsitems = array();
            foreach($updated as $updateditemk=>$updateditemv){
                if($updateditemv['rssid'] == $data['downloadremainingstart']){
                    $newsitemidx = count($newsitems);
                    $newsitems[$newsitemidx]['content'] = $updateditemv['content'];
                    $newsitems[$newsitemidx]['id']      = $updateditemv['rssid'];
                }
            }
            $response['newsitems'] = $newsitems;
        }
        $this->setPagevar('response',$response);
    }
    public function checkDownloadStatus($data){
        $downloaditem       = $this->model('userdownload')->getItem($data['downloadid']);
        $downloadrssids     = $downloaditem['rssids'];
        
        if(strpos($downloaditem['rssids'],',') !== false){
            $downloaditem['rssids'] = explode(',',$downloaditem['rssids']);
        }
        else{
            $downloaditem['rssids'] = array($downloaditem['rssids']);
        }
        
        if(count($downloaditem['rssids']) > $downloaditem['status']){
            $response['status']         = 'downloading';
            $response['downloadid']     = $data['downloadid'];
            
            list($updated,$downloaded) = $this->model('news')->flagdownloadednews( $downloaditem['rssids']);
            $newsitems = array();
            foreach($updated as $downloaditemkey=>$downloaditemval){
                if($updated[$downloaditemkey]['downloaded'] === false){
                    $rssitem        = $this->model('downloadedrss')->getItem($downloaditemval['rssid']);
                    
                    $articlecontent = $this->downloadArticle($rssitem);
                    
                    $updated[$downloaditemkey]['content'] = $articlecontent;
                    $downloaded+=1;
                    $this->model('userdownload')->updateStatus($data['downloadid'],($downloaded));
                    $newsitems[] = $downloaditemval['rssid'];
                    
                    if($downloaded == count($downloaditem['rssids']))
                        $response['status']             = 'finished';
                
                    break;
                }
            }
            $response['newsitems'] = $newsitems;
            $this->setPagevar('response',$response);
        }
        else{
            $response['status']         = 'finished';
            $response['downloadid']     = $data['downloadid'];
            $this->setPagevar('response',$response);
        }
    }
    public function localcontent($data){
        App::setSessionVar('localcontent',$data['content']);
            
        $response['result']     = true;
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function fetchLocalContent(){
        $this->model('newspdf')->pdfcontent = $this->model('newspdf')->cleanstr(App::getSessionVar('localcontent'));
        $this->model('newspdf')->output();
    }
    public function fetchDownloadItem($data){
        if($data==0){
            $this->fetchLocalContent();
            return;
        }
        $downloaditem   = $this->model('userdownload')->getItem($data); 
        $rssids         = explode(',',$downloaditem['rssids']);
        
        foreach($rssids as $rsskey=>$rssval){
            if($rssval=='')
                continue;
                
            $rsslistitem    = $this->model('downloadedrss')->getItem($rssval);
            $newsitem       = $this->model('news')->downloaded($rssval);
            
            if($newsitem == false){
                $newsitem = $this->downloadArticle($rsslistitem);
            }
            $rsslistitem['publisher']   = $this->model('newssource')->sourceName($rsslistitem['newssource']);
            $rsslistitem['categories']  = $this->model('category')->categoryName($rsslistitem['category'],$rsslistitem['tags']);
            $rsslistitem['newscontent'] = $newsitem;
            
            $this->model('newspdf')->newsitem($rsslistitem);
        }
        $this->model('newspdf')->output();
    }
    public function nowDownload($data){
        $userid                         = $data['userid'] == 0 ? $this->model('users')->addUser(Pxpedia::$browser,Pxpedia::$visitorip) : $data['userid'];
        $data                           = $data['rssids'];
        list($downloaditem,$downloaded) = $this->model('news')->flagdownloadednews($data);
        $downloadstatus                 = 0;
        
        if($downloaded == count($data)){
            $downloadstatus = $downloaded;
            
            foreach($downloaditem as $key=>$val){
                $this->model('downloadedrss')->updateDownloadCount($val['rssid']);
            }
        }
        
        $downloadrecord = $this->model('userdownload')->addDownload($data,$userid,$downloaded);
        if($downloadrecord)
            $downloadid = $this->model('userdownload')->insertid();
        else{
            $downloadid = $this->model('userdownload')->printerrors(false);
        }
        
        $response = array('downloaded'=>$downloaded,'downloadid'=>$downloadid,'status'=>$downloadstatus,'userid'=>$userid);
        
            list($updated,$newlydownloaded) = $this->model('news')->flagdownloadednews($data);
            
            $newsitems = array();
            foreach($updated as $updateditemk=>$updateditemv){
                if($updateditemv['downloaded'] == false)
                    continue;
                
                $newsitemidx                        = count($newsitems);
                $newsitems[$newsitemidx]['content'] = $updateditemv['content'];
                $newsitems[$newsitemidx]['id']      = $updateditemv['rssid'];
            }
            $response['newsitems'] = $newsitems;
        
        $this->setPagevar('response',$response);
    }
    public function downloadNow($data){
        $userid     = $data['userid'] == 0 ? $this->model('users')->addUser(Pxpedia::$browser,Pxpedia::$visitorip) : $data['userid'];
        $rssid      = $data['rssid'];
        $downloadid = $data['downloadid'];
        if($data['downloadid'] == 0){
            $addDownload = $this->model('userdownload')->addDownload($rssid,$userid,0);
            if($addDownload){
                $downloadid     = $this->model('userdownload')->insertid();
                $downloaditem   = $this->model('userdownload')->getItem($downloadid);
            }
        }
        else{
            $downloadid = $data['downloadid'];
            $downloaditem   = $this->model('userdownload')->getItem($downloadid);
            $this->model('userdownload')->updateRssid($downloadid,$rssid);
        }
        $response['downloadid'] = $downloadid;
        
        $response['userid'] = $userid;
        
        if(($news = $this->model('news')->downloaded($rssid)) !== false){
            $response['content'] = $news;
            $this->model('userdownload')->updateStatus($downloadid,($downloaditem['status']+1));
        }
        else{
            $rssitem                = $this->model('downloadedrss')->getItem($rssid);
            $response['content']    = $this->downloadArticle($rssitem);
            
            $this->model('userdownload')->updateStatus($downloadid,($downloaditem['status']+1));
        }
        
        $this->model('downloadedrss')->updateDownloadCount($rssid);
        
        $this->setPagevar('response',$response);
    }
    public function downloadpopart($data){
        $userid     = $data['userid'] == 0 ? $this->model('users')->addUser(Pxpedia::$browser,Pxpedia::$visitorip) : $data['userid'];
        $rssid      = $data['rssid'];
        $downloadid = $data['downloadid'];
        if($data['downloadid'] == 0){
            $addDownload = $this->model('userdownload')->addDownload($rssid,$userid,0);
            if($addDownload){
                $downloadid     = $this->model('userdownload')->insertid();
                $downloaditem   = $this->model('userdownload')->getItem($downloadid);
            }
        }
        else{
            $downloadid     = $data['downloadid'];
            $downloaditem   = $this->model('userdownload')->getItem($downloadid);
            $this->model('userdownload')->updateRssid($downloadid,$rssid);
        }
        
        $news       = $this->model('news')->downloaded($rssid);
        $rss        = $this->model('downloadedrss')->getItemDesc($rssid);
        
        $response                   = $rss[0];
        if($rss[0]['tags'] == '')
            $response['categoryname']   = $this->model('category')->categoryName($rss[0]['category']);
        else
            $response['categoryname']   = $this->model('category')->categoryName($rss[0]['category'], explode(',',$rss[0]['tags']));
        
        $response['content']        = $news;
        $response['downloadid']     = $downloadid;        
        $response['userid']         = $userid;

        
        $this->model('userdownload')->updateStatus($downloadid,($downloaditem['status']+1));
               
        $this->model('downloadedrss')->updateDownloadCount($rssid);
        
        $this->setPagevar('response',$response);
    }
    public function getArchive($data){
        $sourceid   = $data['source'];
        $start      = isset($data['start']) ? $data['start'] : 0;
        $source     = $this->model('source')->getSource($sourceid);
        $archive    = $this->model('downloadedrss')->getArchive($sourceid,$start);
        $rss        = $archive[0];
        $limit      = $archive[1];
        
        $source['categories']       = $this->model('category')->getBySource($sourceid);
        $source['lastfetched']      = date('l, F jS H:i:s', strtotime($source['lastfetched']));
        $response['nsource']        = $source;
        $response['rss']            = $rss;
        $response['limit']          = $limit;
        
        $this->setPagevar('response',$response);
    }
    public function rsscategories($categories,$downloaded){
        if(is_array($categories)){
            $exists = false;
            foreach($categories as $ck=>$cv){
                if($categories[$ck]['id'] === $downloaded){
                    $exists = true;
                }
            }
            if(!$exists){
                $categories[] = $this->model('category')->getrecord(array('id'=>$downloaded));
            }
        }
        else{
            $categories = array();
            $categories[] = $this->model('category')->getrecord(array('id'=>$downloaded));
        }
        return $categories;
    }
    public function getRSS($data){
        $sourceid               = $data['source'];
        $source                 = $this->model('source')->getSource($sourceid);
        $source['categories']   = $this->model('category')->getBySource($sourceid);
        $response['limit']      = false;
       
        if(isset($data['downloadupdates']) || $this->model('source')->fetchCurrent($source)){
            list($rss,$source)          = $this->downloadNewRss($source);
            if($rss === false){
                $this->model('reports')->addrssreport($source,false,'fopen error');
                $source['lastfetched']      = date('l, F jS H:i:s', strtotime($source['lastfetched']));
                $response['nsource']        = $source;
                $response['downloadnew']    = true;
                
                $archive            = $this->model('downloadedrss')->getArchive($sourceid,0);
                $response['rss']    = $archive[0];
                $response['limit']  = $archive[1];
            }
            else{
                $response['downloadnew']    = true;
                
                $source['lastfetched']      = date('l, F jS H:i:s', strtotime($this->model('source')->getLastFetched($sourceid)));
                $response['nsource']        = $source;
                
                $archive            = $this->model('downloadedrss')->getArchive($sourceid,0);
                $response['rss']    = $archive[0];
                $response['limit']  = $archive[1];   
            }
        }
        else{
            $source['lastfetched']      = date('l, F jS H:i:s', strtotime($source['lastfetched']));
            $response['nsource']        = $source;
            $response['downloadnew']    = false;
        }
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function downloadNewRss($source){
        $rss                = $this->model('source')->getRss($source);
        
        if($rss === false)
            return array(false,$source);
        
        $youngestpubdate    = 0;
        
        if(!empty($rss))
        foreach($rss as $k=>$v){
            $pubdatetime = strtotime($rss[$k]['pubDate']);
            if($youngestpubdate < $pubdatetime){
                $youngestpubdate = $pubdatetime;
            }
            
            if(count($v['category']) > 1){                    
                foreach($v['category'] as $vk=>$vv){
                    $tag                    = $v['category'][$vk];
                    $tagid                  = $this->model('category')->getId($tag,$source['id'],true);
                    $source['categories']   = $this->rsscategories($source['categories'],$tagid);
                    
                    $rss[$k]['tags'][]      = $tagid;
                    $v['tags'][]            = $tagid;
                }
                $rss[$k]['category']    = $tagid;
                $v['category']          = $tagid;
            }
            else{
                if(!isset($v['category'][0]) || $v['category'][0] == ''){
                    $v['category'][0] = 'Uncategorized';
                }

                $v['category']          = $v['category'][0];
                $categoryid             = $this->model('category')->getId($v['category'],$source['id'],true);
                $source['categories']   = $this->rsscategories($source['categories'],$categoryid);
                
                $rss[$k]['tags']        = array();
                $v['tags']              = array();
                
                $rss[$k]['category']    = $categoryid;
                $v['category']          = $categoryid;
            }
            
            $rss[$k]['newssource']  = $source['id'];
            $v['newssource']        = $source['id'];
            $rss[$k]['pubDate']     = date('l, F jS Y H:i:s',$pubdatetime);
            $rss[$k]['creator']     = $rss[$k]['dc:creator'];
            
            unset($rss[$k]['dc:creator']);
            $newsitem               = $this->model('downloadedrss')->saveNewsItem($v,$source['id']);
            if($newsitem !== false){
                $rss[$k]['id']      = $newsitem;
                $rss[$k]['datetosort']      = date('Y-m-d H:i:s',$pubdatetime);
            }
            else{
                /*echo $this->model('downloadedrss')->printerrors(false);*/
                unset($rss[$k]);
            }
        }
        if($youngestpubdate !==0)
            $this->model('source')->updateLastFetched($source['id'],date('Y-m-d H:i:s',$youngestpubdate));
            
        return array($rss,$source);
    }
    public function olderNewsCategory($data){
        $sourceid           = $data['source'];
        $start              = $data['start'];
        $category           = $data['category'];
        
        $archive            = $this->model('downloadedrss')->getCategoryArchive($sourceid,$start,$category);    
        
        $response['rss']    = $archive[0];
        $response['limit']  = $archive[1];
        
        $this->setPagevar('response',$response);
    }
    public function olderNews($data){
        $sourceid           = $data['source'];
        $start              = $data['start'];
        $exclude            = isset($data['excludecat']) && count($data['excludecat']) > 0 ? $data['excludecat'] : null;
        
        if(!is_null($exclude)){
            $excluding = array();
            foreach($exclude as $key=>$val){
                $excluding[$key]['category'] = $val;
                $excluding[$key]['count'] = $data['excludecatcount'][$key];
            }
            $archive    = $this->model('downloadedrss')->getArchiveAllBut($sourceid,$start,$excluding);
        }
        else{
            $archive    = $this->model('downloadedrss')->getArchive($sourceid,$start);    
        }
        
        $response['rss']        = $archive[0];
        $response['limit']      = $archive[1];
        $response['excluding']  = isset($archive[2]) ? $archive[2] : array();
        
        $this->setPagevar('response',$response);
    }
    public function searchNews($data){
        $keywordsx      = strpos($data['keywords'],',') !== false ? explode(',',$data['keywords']) : $data['keywords'];
        $dateend        = $data['enddate'];
        $datestart      = $data['startdate'];
        $datefilter     = array($datestart,$dateend);
        $idolderthan    = isset($data['oldestid']) ? $data['oldestid'] : false;
        $source         = isset($data['sourceid']) ? $data['sourceid'] : false;
        $exclude        = isset($data['excludecat']) && count($data['excludecat']) > 0 ? $data['excludecat'] : null;
        $start          = $data['start'];
        
        $response['searchresult'] = array();
        
        $userid             = $data['userid'] == 0 ?  $this->model('users')->addUser(Pxpedia::$browser,Pxpedia::$visitorip) : $data['userid'];
        $response['userid'] = $userid;
        
        $this->model('usersearch')->submitkeysearch($userid,$keywordsx,$source);
        
        $keyids = $this->model('keywords')->getKeyIds($keywordsx);
        if(count($keyids)){
            $keys           = array();
            $keyassoc       = array();
            foreach($keyids as $kk=>$kv){
                $keys[]                 = $kv['id'];
                $keyassoc[$kv['id']]    = $kv['keyword'];
            }
            $newsids = $this->model('keytonews')->getNewsWithKeys($keys);
            
            $newsidsarr = array();
            $newsassoc  = array();
            foreach($newsids as $newsidk=>$newsidv){
                $newsidsarr[]                       = $newsidv['newsid'];
                $newsassoc[$newsidv['newsid']][]    = $newsidv['keyid'];
            }
            $rssids = $this->model('news')->getNewsRssId($newsidsarr);
            
            $rsss       = array();
            $rsswithkey = array();
            foreach($rssids as $rssidk=>$rssidv){
                $rsss[]                         = $rssidv['rssid'];
                $rsswithkey[$rssidv['rssid']]   = $newsassoc[$rssidv['id']];
            }
            
            if(!is_null($exclude)){
                 $excluding = array();
                 foreach($exclude as $key=>$val){
                     $excluding[$key]['category']   = $val;
                     $excluding[$key]['count']      = $data['excludecatcount'][$key];
                     $excluding[$key]['oldestid']   = $data['excludeoldestid'][$key];
                 }
                 list($rsssearchresult,$limit,$exclude)  =  $this->model('downloadedrss')->searchedNews($rsss,$datefilter,$source,$idolderthan,$start,$excluding);
            }
            else{
                $exclude = array();
                list($rsssearchresult,$limit) = $this->model('downloadedrss')->searchedNews($rsss,$datefilter,$source,$idolderthan,$start);
            }
            foreach($rsssearchresult as $k=>$v){
                $rsssearchresult[$k]['keywords'] = $rsswithkey[$v['id']];
            }
            
            $response['searchresult']   = $rsssearchresult;
            $response['limit']          = $limit;
            $response['keywithid']      = $keyassoc;
            $response['excluding']      = $exclude;
        }
        $this->setPagevar('response',$response);
    }
    public function searchNewsByDate($data){
        $dateend        = $data['enddate'];
        $datestart      = $data['startdate'];
        $datefilter     = array($datestart,$dateend);
        $idolderthan    = isset($data['oldestid']) ? $data['oldestid'] : false;
        $source         = isset($data['sourceid']) ? $data['sourceid'] : false;
        $exclude        = isset($data['excludecat']) && count($data['excludecat']) > 0 ? $data['excludecat'] : null;
        $start          = $data['start'];
        
        $response['searchresult']   = array();
        $response['userid']         = $data['userid'] == 0 ? $this->model('users')->addUser(Pxpedia::$browser,Pxpedia::$visitorip) : $data['userid'];
        
        if(!is_null($exclude)){
            $excluding = array();
            foreach($exclude as $key=>$val){
                $excluding[$key]['category']    = $val;
                $excluding[$key]['oldestid']    = $data['excludeoldestid'][$key];
                $excluding[$key]['count']       = $data['excludecatcount'][$key];
            }
            list($rsssearchresult,$limit,$exclude)  =  $this->model('downloadedrss')->searchByDate($datefilter,$source,$idolderthan,$start,$excluding);
        }
        else{
            $exclude = array();
            list($rsssearchresult,$limit) = $this->model('downloadedrss')->searchByDate($datefilter,$source,$idolderthan,$start);
        }
          
        $response['searchresult']   = $rsssearchresult;
        $response['limit']          = $limit;
        $response['excluding']      = $exclude;
        $response['keywithid']      = array();
        
        $this->setPagevar('response',$response);
    }
    public function searchByKey($data){
        $keywordsx      = strpos($data['keywords'],',') !== false ? explode(',',$data['keywords']) : $data['keywords'];
        $idolderthan    = isset($data['oldestid']) ? $data['oldestid'] : false;
        $source         = isset($data['sourceid']) ? $data['sourceid'] : false;
        $exclude        = isset($data['excludecat']) && count($data['excludecat']) > 0 ? $data['excludecat'] : null;
        $start          = $data['start'];
        
        $response['searchresult']  = array();
        
        $userid             = $data['userid'] == 0 ? $this->model('users')->addUser(Pxpedia::$browser,Pxpedia::$visitorip) : $data['userid'];
        $response['userid'] = $userid;
        
        $this->model('usersearch')->submitkeysearch($userid,$keywordsx,$source);
        
        $keyids = $this->model('keywords')->getKeyIds($keywordsx);
        if(count($keyids)){
            $keys       = array();
            $keyassoc   = array();
            foreach($keyids as $kk=>$kv){
                $keys[]                 = $kv['id'];
                $keyassoc[$kv['id']]    = $kv['keyword'];
            }
            $newsids = $this->model('keytonews')->getNewsWithKeys($keys);
            
            $newsidsarr = array();
            $newsassoc  = array();
            foreach($newsids as $newsidk=>$newsidv){
                $newsidsarr[]                       = $newsidv['newsid'];
                $newsassoc[$newsidv['newsid']][]    = $newsidv['keyid'];
            }
            $rssids = $this->model('news')->getNewsRssId($newsidsarr);
            
            $rsss           = array();
            $rsswithkey     = array();
            foreach($rssids as $rssidk=>$rssidv){
                $rsss[]                         = $rssidv['rssid'];
                $rsswithkey[$rssidv['rssid']]   = $newsassoc[$rssidv['id']];
            }
            
            if(!is_null($exclude)){
                $excluding = array();
                foreach($exclude as $key=>$val){
                    $excluding[$key]['category']    = $val;
                    $excluding[$key]['oldestid']    = $data['excludeoldestid'][$key];
                    $excluding[$key]['count']       = $data['excludecatcount'][$key];
                }
                list($rsssearchresult,$limit,$exclude)  =  $this->model('downloadedrss')->searchedNews($rsss,false,$source,$idolderthan,$start,$excluding);
            }
            else{
                $exclude = array();
                list($rsssearchresult,$limit) = $this->model('downloadedrss')->searchedNews($rsss,false,$source,$idolderthan,$start);
            }
            
            foreach($rsssearchresult as $k=>$v){
                $rsssearchresult[$k]['keywords'] = $rsswithkey[$v['id']];
            }
            $response['searchresult']   = $rsssearchresult;
            $response['keywithid']      = $keyassoc;
            $response['limit']          = $limit;
            $response['excluding']      = $exclude;
        }
        $this->setPagevar('response',$response);
    }
    public function getSourceWithCat($data){
        $sourceid               = $data['sourceid'];
        $source                 = $this->model('source')->getSource($sourceid);
        $source['categories']   = $this->model('category')->getBySource($sourceid);
        
        $this->setPagevar('response',$source);
    }
    public function submitNewsletter($data){
        $email              = $data['email'];
        $sources            = $data['sources'];
        $sourcescategory    = $data['sourcescategory'];
        $sourceskey         = $data['sourceskey'];
        $userid             = $data['userid'] == 0 ? $this->model('users')->addUser(Pxpedia::$browser,Pxpedia::$visitorip) : $data['userid'];
        
        $sourcesetting  = array();
        $sourcesidx     = array();
        foreach($sources as $sourcek=>$sourcesval){
            if(isset($sourcesidx[$sourcesval])){
                $sourcesettingidx = -1;
                foreach($sourcesetting as $sk=>$sv){
                    if($sv['source'] == $sourcesval){
                        $sourcesettingidx = $sk;
                        break;
                    }
                }
                
                $idx = count($sourcesetting[$sourcesettingidx]);                
                $sourcesetting[$sourcesettingidx][$idx]['category'] =$sourcescategory[$sourcek];
                $sourcesetting[$sourcesettingidx][$idx]['keywords'] =$sourceskey[$sourcek];
            }
            else{
                $sourcesidx[$sourcesval] = 1;
                $sourcesettingidx = count($sourcesidx);
                
                $idx = 0;
                $sourcesetting[$sourcesettingidx]['source']   =$sourcesval;
                $sourcesetting[$sourcesettingidx][$idx]['category'] =$sourcescategory[$sourcek];
                $sourcesetting[$sourcesettingidx][$idx]['keywords'] =$sourceskey[$sourcek];
            }
        }
        
        $this->setPagevar('response',false);
        $newsletterid = $this->model('newsletters')->addNewsletter($userid,$email);
        if($newsletterid !== 0 && $newsletterid !== false){
            $settings = $this->model('newslettersettings')->addSettings($newsletterid,$sourcesetting);
            if($settings){
                $this->setPagevar('response',true);
            }
        }
        else{
            if($newsletterid == 0){
                $newsletterid   = $this->model('newsletters')->getNewsletterid($data['email']);
                $updatesettings = $this->model('newslettersettings')->updateSettings($newsletterid,$sourcesetting);
                
                if($updatesettings){
                    $this->setPagevar('response',true);
                }
            }
        }
    }
    public function loadNewsletter($data){
        $response['newsletter']     = true;
        $newsletterid               = $this->model('newsletters')->getNewsletterid($data['email']);
        
        if($newsletterid === false){
            $response['newsletter'] = false;
        }
        else{
            $settings             = $this->model('newslettersettings')->getNewsletterSettings($newsletterid);
            $response['settings'] = $settings;
        }
        $this->setPagevar('response',$response);
    }
    public function removeSubscription($data){
        $subscriptionremove = $this->model('newsletters')->removeNewsletter($data['email']);
        $this->setPagevar('response',$subscriptionremove);
    }
    public function cleanArticle($data,$debughtml=false,$debugarticle=false,$debugcontent=false){
        $this->model('news')->saveNews($data['content'],$data['id']);
        
        $sourcesetting  = $this->model('newssource')->getSettings($data['newssource']);
        $articlehtml    = Pxpedia::parsexml(false,$data['content'],true);
        
        $nodeexclude = count($sourcesetting['exclude']) ? $sourcesetting['exclude'] : null;
        $contentnode = $sourcesetting['thecontent'];
        
        if($debughtml){
            print_r($articlehtml);exit();
        }
        
        $newscontent = '';
        foreach($contentnode as $contentk=>$contentv){
            $node           = $contentv;
            $articlebody    = Pxpedia::xmldata($node,'',$articlehtml);
            
            if(count($articlebody)){
                if($debugarticle){
                    print_r($articlebody);exit();    
                }
                
                if(!empty($sourcesetting['keywords']))
                    $keywords       = $this->model('keywords')->extractkeywords($articlehtml,$sourcesetting['keywords']);
                    
                $articlebody    = $this->model('downloadedrss')->fiximageurl($data,$articlebody);
                
                $newscontent    = trim(Pxpedia::xmlcontent('',$articlebody,'',true,$nodeexclude));
                if($newscontent!=''){
                    if($debugcontent){
                        print_r($newscontent);exit();    
                    }
                    break;
                }
            }
        }
        if($newscontent !== ''){
            $this->model('news')->saveNews($newscontent,$data['id']);
            if(isset($keywords) && count($keywords)){
                list($keyids,$keywords) = $this->model('keywords')->addKeywords($keywords);
                $this->model('keytonews')->addNewsKeywords($this->model('news')->insertid(),$keyids);
            }            
        }
        else{
            $this->model('reports')->addreport($data,$newscontent,'emptynewscontent');
            $newscontent = false;
        }
        
        $this->setPagevar('response',$newscontent);;
    }
    public function debug($data=false){
        if($data == false || (!isset($data['rssid']) && !isset($data['rssfeed']))  ){
            $rssitem                = $this->model('downloadedrss')->getItem(11211);
            $rssitem['newssource']  = 51;
            /*$rssitem['link'] = 'uploads/nownews/articlesample/l.html';*/
        }
        else{
            if(isset($data['rssid'])){
                $rssitem                = $this->model('downloadedrss')->getItem($data['rssid']);
                if(isset($data['showdownloaded'])){
                    $news       = $this->model('news')->downloaded($data['rssid']);
                    print_R($news);exit();
                }
                else{
                    if(isset($data['link'])){
                        $rssitem['link'] = 'uploads/nownews/articlesample/'.$data['link'].'.html';
                    }   
                }
            }
            elseif(isset($data['rssfeed'])){
                $source = array();
                $source['url'] = $data['rssfeed'];
                $rss   = $this->model('source')->getRss($source,true);
                echo mb_detect_encoding(print_r($rss,true));
                /*echo '----#'.mb_convert_encoding(print_r($rss,true),"ISO-8859-1",mb_detect_encoding(print_r($rss,true))).'#----';*/
                exit();
            }
        }
        print_r($rssitem);
        $debhtml = isset($data['html']) ? $data['html'] : true;
        $debart = isset($data['art']) ? $data['art'] : false;
        $debcon = isset($data['con']) ? $data['con'] : false;
        
        $content = $this->downloadArticle($rssitem,$debhtml,$debart,$debcon);
        print_R($content);exit();
    }
    public function downloadArticle($rssitem,$debughtml=false,$debugarticle=false,$debugcontent=false){
        $this->fopenerror = false;
        $sourcesetting  = $this->model('newssource')->getSettings($rssitem['newssource']);
        $articlehtml    = Pxpedia::parsexml($rssitem['link'],false,true);
        
        if($articlehtml === false){
            $this->fopenerror = true;
            $this->model('reports')->addreport($rssitem,false,'fopen error');
            return '';
        }
        
        $nodeexclude = count($sourcesetting['exclude']) ? $sourcesetting['exclude'] : null;
        $contentnode = $sourcesetting['thecontent'];
        
        if($debughtml){
            echo '^^^^^^^^^^^^^^';
            print_r($articlehtml);exit();
        }
        
        $newscontent = '';
        foreach($contentnode as $contentk=>$contentv){
            $node           = $contentv;
            $articlebody    = Pxpedia::xmldata($node,'',$articlehtml);
            if(count($articlebody)){
                if($debugarticle){
                    print_r($articlebody);exit();    
                }
                
                if(!empty($sourcesetting['keywords']))
                    $keywords       = $this->model('keywords')->extractkeywords($articlehtml,$sourcesetting['keywords']);
                    
                $articlebody    = $this->model('downloadedrss')->fiximageurl($rssitem,$articlebody);
                
                $newscontent    = trim(Pxpedia::xmlcontent('',$articlebody,'',true,$nodeexclude));
                
                if($newscontent!=''){
                    if($debugcontent){
                        echo $newscontent;
                        //$handler = @fopen(App::getConfig('uploads').'/debug/debuglog839_'. $rssitem['id'] .'.txt','a');
        			    //$response = fputs($handler,print_r($articlebody,true).'^^^'.$newscontent);
        			    //@fclose($handler);
                    }
                    
                    break;
                }
            }
            else{
                //$handler = @fopen(App::getConfig('uploads').'/debug/debuglog849_'. $rssitem['id'] .'.txt','a');
			    //$response = fputs($handler,print_r($articlehtml,true).'^^^');
			    //@fclose($handler);
            }
        }
        if($newscontent !== ''){
            $this->model('news')->saveNews($newscontent,$rssitem['id']);
            if(isset($keywords) && count($keywords)){
                list($keyids,$keywords) = $this->model('keywords')->addKeywords($keywords);
                $this->model('keytonews')->addNewsKeywords($this->model('news')->insertid(),$keyids);
            }            
        }
        else{
            $newscontent = $this->controller('paragraphcounter')->getContent($articlehtml,$sourcesetting,$rssitem);
            $this->model('news')->saveNews($newscontent,$rssitem['id']);
            if($newscontent == ''){
                $this->model('reports')->addreport($rssitem,$newscontent,'emptynewscontent');
            
                //$handler = @fopen(App::getConfig('uploads').'/debug/debuglog868_'. $rssitem['id'] .'.txt','a');
    		    //$response = fputs($handler,print_r($articlehtml,true).'^^^');
    		    //@fclose($handler);
            }
        }
        return $newscontent;
    }
    public function loadSource($data){
        $source             = $this->model('source')->getSources(null,10,$data['offset']);
        $sourcelistitems 	= array();
		
		$count = 0;
		foreach($source as $sk=>$sv){
			$sourcelistitems[$count]['id'] 		= 'newssource_'.$sv['id'];
			$sourcelistitems[$count]['content'] = '<div class="table"><div class="tablecell"><img src="'.$sv['logo'].'" title="'. $sv['name'] .'"></div></div>';
						
			$count++;
		}
        $response['sources'] = $sourcelistitems;
        
        $this->setPagevar('response',$response);
    }
}
?>