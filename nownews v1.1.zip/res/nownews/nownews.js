/**************************************
 *  v1.0 - 3182 line - Feb 25th 2017
 *  v1.1 - 3609 line - Jul 25th 2018
 *  v1.2 - 3682      - Dec 8th 2018
**************************************/
$(document).ready(
    function () {
        pagetabs();
        sourceopt();
        rss();
        rssnav();
        panelmenu();
        readerkeys();
        sourcelistnav();
        miscpage();
        nownewspw();
        if(typeof itsacontentpage !== 'undefined'){
            contentpage();
        }
        else{
            getLocalStorage();
            currentpaper.save(false);            
        }

        $('#logo').on('click',function(event){
            event.stopPropagation();
            if(isanelectronapp)
                ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
        });
        $('#branding').on('click',function(event){
            event.stopPropagation();
            
            var message     = '<div class="table" style="width:100%;height:100%;;"><div class="tablecell">Launch Bulk Downloader?<br/>This Will Download All Articles from All Publisher</div></div>';
            var submitopt   = '<span class="fiftycent"><a href="javascript:void(0);" id="confirmbulkdownload" class="button left">Yes</a></span><span class="fiftycent"><a href="javascript:void(0);" onclick="closemessage();" id="cancelbulkdownload" class="button right">Cancel</a></span>';
            var title       = 'Bulk Download';
            displaymessage(title,message,submitopt);
            
            $('#confirmbulkdownload').on('click',function(event){
                event.stopPropagation();
                
                bulkdownloader.init();
            });
        });
    }
);

function contentpage(){
    $('#reviewmode').addClass('active');
    $('#articlelistcontainer').addClass('readingmode');
    $('body').find('.opaquebg').eq(0).addClass('readingmodeactive');
    if(mobile){
        setTimeout(function(){
            $('#reviewmode').addClass('blur');
            $('#princewoordphone').addClass('blur');
            changepage('downloaded',false);
        },1000);   
    }
    else
        changepage('downloaded',false);
}
var bulkdownloader = {
    articdownload:function(){
        if(downloadlist.items.length == 0)
            return;
        
        if($('#downloaddownloadlist').attr('class').indexOf('active') != -1)
            return;
        
        $('#downloadlistbox').find('.rssactionbutton').removeClass('active');
        $('#downloadopt').removeClass('active');
        $('#downloaddownloadlist').addClass('active');
        
        $('#downloadingnow').addClass('active');
        $('#downloadingnow').children('.actionsubcontent').html('processing...');
        $('#menurss').addClass('processing');
    
        var todownloadnow       = [];
        var articleplaceholder  = '';
        
        $.each(downloadlist.items,function(idx,ele){
            todownloadnow[todownloadnow.length] = ele.id;
            if(typeof($('#articlepage_'+ele.id).attr('id')) === 'undefined'){
                articleplaceholder += '<div class="hide" id="articlepage_'+ele.id+'"></div>';
            }
            else{
                downloadlist.deleteitem(ele.id);
                downloadlist.refreshlist();
            }
        });
        downloadnowcount = downloadlist.items.length;
        if(!bulkdownloader.started){
            $('#articlelistcontainer').append(articleplaceholder);
        }
        
        $.ajax({
            url:'./',
            data:{app:appname,p:'ajax',a:'nowDownload',d:{rssids:todownloadnow,userid:userdata.userid}},
            type:'POST'
        }).done(function(msg){
            var response = $.parseJSON(msg);
            userdata.setuserid(msg.userid);
            
            if(typeof(response.newsitems) !== 'undefined' && response.newsitems.length > 0){
                $('.addtodownload').removeClass('disabled');
                
                    $('#downloadedcontainer').find('.descriptioncontainer').addClass('hide');
                    var nightmode = '';
                    var newlydownloaded = [];
                    if($('#nightmode').attr('class').indexOf('active') !== -1){
                        nightmode = ' nightmode';
                    }
                    $.each(response.newsitems, function(newsitemidx,newsitemelem){
                        newlydownloaded[newlydownloaded.length] = newsitemelem.id;
                        var downloaditem = downloadlist.getById(parseInt(newsitemelem.id));
                        rsslistitem.reset();
                        rsslist.getrssbysourceandid(downloaditem.source,downloaditem.id);
                        sourcelist.getSource(downloaditem.source);
                        
                        if(!bulkdownloader.started){
                            var newdownload = '<div class="articlepage'+nightmode+'" id="articlepage_'+ rsslistitem.id +'">'
                            +'<div class="articletitle">'+rsslistitem.title+'</div>'
                            +'<div class="articledate">'+rsslistitem.pubDate+' By '+ rsslistitem.creator +'</div>'
                            +'<div class="articlecategory"><span class="articlelabel">Category</span><span class="colon">:</span><span class="articleattr">'+source.getCategoryById(rsslistitem.category)+'</span></div>'
                            +'<div class="articlepublisher"><span class="articlelabel">Publisher</span><span class="colon">:</span><span class="articleattr">'+sourcelist.sourcename(rsslistitem.source)+'</span></div>'
                            +'<div class="articlecontent">'+newsitemelem.content+'</div>'
                            +'</div>';   
                            
                            downloaded.articles[downloaded.articles.length] = newdownload;
                        }
                        else{
                            downloaded.articles[downloaded.articles.length] = rsslistitem.id;
                        }
                            
                        
                        downloaded.rssids[downloaded.rssids.length]     = rsslistitem.id;
                        downloaded.downloadid                           = response.downloadid;
                        
                        if(!bulkdownloader.started){
                            $('#articlepage_'+rsslistitem.id).replaceWith(newdownload);
                            $('#articlepage_'+rsslistitem.id).find('a').addClass('leavingpage').prop('target','_blank');
                            $('#articlepage_'+rsslistitem.id).find('img').addClass('newsart').prop('srcset',''); 
                        }
                        
                            $('#downloadnow_'+rsslistitem.id).addClass('downloaded');
                            $('#downloadnow_'+rsslistitem.id).removeClass('downloading');
                        
                    });   
                
                downloadlist.markDownloaded(newlydownloaded,true);
                if(!bulkdownloader.started){
                    $('#downloadcount').html('('+ downloaded.articles.length +')');
                    $('#princewoordphone').removeClass('unoccupied');
                }
            }
            
            if(response.status){
                if(!bulkdownloader.started){
                    currentpaper.save($('#articlelistcontainer').html());
                }
                else{
                    bulkdownloader.nextstep();
                    bulkdownloader.bulkdownload();
                }
                downloadlist.items = [];
                downloadlist.refreshlist();
                $('#downloadingnow').children('.actionsubcontent').html('Finished, '+downloadnowcount+' items successfully downloaded');
                $('#menurss').removeClass('processing');
            }
            else{
                downloadingNowNews(response);
            }
        });
    },
    stage:0,
    init:function(){
        if(this.started){
            return;
        }
        closemessage();
        this.started = true;
        this.stage = 0;
        this.bulkdownload();
    },
    nextstep:function(){
        this.stage++;
    },
    bulkdownload:function(){
        switch(bulkdownloader.stage){
            case 0:
                $('#menurss').addClass('processing');
                bulkdownloader.completesources();
            break;
            case 1:
                bulkdownloader.downloadrsses();
            break;
            case 2:
                bulkdownloader.preplist();
            break;
            case 3:
                var panelmenu = $('#pbmenurss');
                $('.toolbox').hide();
                $('.toolbox'+$(panelmenu).attr('id').substr(6)).show();
                $('.sidebarpanel').addClass('active');   
                
                downloadlist.sort('pubDate');
                downloadlist.refreshlist();
                
                bulkdownloader.articdownload();
            break;
            case 4:
                $('#menurss').removeClass('processing');
                downloaded.articles = [];
                $('#downloadlistbox').find('.rssactionbutton').addClass('disabled');
                $('#downloadlistbox').find('#downloaddownloadlist').removeClass('disabled');
                bulkdownloader.started = false;
                bulkdownloader.disablebuttons = true;
                $('.downloadnow').removeClass('downloaded').addClass('readnow');
                
                source.setSource(parseInt($('#rsslistcontainer').children('.rsslist').eq($('#rsslistcontainer').children('.rsslist').length-1).attr('id').split('_')[1]));
            break;
        }
    },
    disablebuttons:false,
    checkbuttons:function(){
        if(!this.disablebuttons){
            return;
        }
        
        this.disablebuttons = false;
        $('#downloadlistbox').find('.rssactionbutton').removeClass('disabled');
    },
    preparticledownload:function(){
        if(bulkdownloader.drsslistqueue.length){
            setTimeout(function(){
                bulkdownloader.preparticledownload();
            },3000);
            return;
        }
        bulkdownloader.nextstep();
        bulkdownloader.bulkdownload();
    },
    listitems:function(sid){
        $.each($('#rss_'+sid).find('.addtodownload'),function(eci,ecv){
            addtodownloadlist(ecv);
        });
    },
    preplist:function(){
        for(var i=0;i<bulkdownloader.anotherrsslistqueue.length;i++){
            bulkdownloader.listitems(bulkdownloader.anotherrsslistqueue[i]);
        }
        
        $('#downloadlistbox').find('.actionsub').removeClass('active');
        $('#downloadlistbox').find('.rssactionbutton').removeClass('active');
        $('#downloadingpdf').children('.actionsubcontent').html('');
        
        $('#downloadlistbox').find('.actionsub').removeClass('active');
        $('#downloadlistbox').find('.rssactionbutton').removeClass('active');
        $('#downloadingpdf').children('.actionsubcontent').html('');
        
        $('#paneltext').html(downloadlist.items.length);
        $('.panelbutton').children('.table').eq(0).addClass('active');
                
        bulkdownloader.nextstep();
        bulkdownloader.bulkdownload();
    },
    drsslistqueue:[],
    anotherrsslistqueue:[],
    downloadrsses:function(){
        $.each($('.sourceitem'),function(si,se){
            var thesid = $(se).attr('id').split('_')[1];
            bulkdownloader.drsslistqueue[bulkdownloader.drsslistqueue.length] = parseInt(thesid);
            bulkdownloader.anotherrsslistqueue[bulkdownloader.anotherrsslistqueue.length] = parseInt(thesid);
            if(typeof $('#rss_'+thesid).attr('class') === 'undefined'){
                bulkdownloader.sourcerss(thesid);   
            }
            else{
                var idxofsid = bulkdownloader.drsslistqueue.indexOf(thesid);
                bulkdownloader.drsslistqueue.splice(idxofsid,1);
            }
        });
        bulkdownloader.preparticledownload();
    },
    slidingsource:false,
    progressing:function(){
        rsswidth = $('#rsslistcontainer').width();
            
            if(bulkdownloader.slidingsource===false){
                bulkdownloader.slidingsource = parseInt($('#rsslistcontainer').children().eq(0).attr('id').split('_')[1]);
            }
            if(typeof $('#rss_'+bulkdownloader.slidingsource).next().attr('id') === 'undefined'){
                return;
            }
                $('#rss_'+bulkdownloader.slidingsource).children('.rsshead').addClass('slidingmode');
                $('#rss_'+bulkdownloader.slidingsource).animate({'margin-left':(0-rsswidth)+'px'},'fast',function(){
                    $('.prevrss').show();
                    $('#rss_'+bulkdownloader.slidingsource).children('.rsshead').removeClass('slidingmode');
                    if(typeof $('#rss_'+bulkdownloader.slidingsource).next().attr('id') === 'undefined'){
                        $('.nextrss').hide();
                    }
                    else{
                        bulkdownloader.slidingsource = parseInt($('#rss_'+bulkdownloader.slidingsource).next().attr('id').substr(4));
                        bulkdownloader.progressing();
                    }
                });
    },
    sourcerss:function(sid){
        var dummyvar = ['getArchive','getRss'];
        $.ajax({
            url:'./',
            data:{app:appname,p:'ajax',a:dummyvar[0],d:{source:sid,downloadupdates:true}},
            type:'POST'
        }).done(function(msg){
            msg = $.parseJSON(msg);
            if(msg.rss.length){
                populatersslist(msg.rss,msg.nsource,false);
                source.oldestid = msg.rss[msg.rss.length -1].id;
            }
            else{
                var idxofsid = bulkdownloader.drsslistqueue.indexOf(parseInt(sid));
                bulkdownloader.drsslistqueue.splice(idxofsid,1);   
            }
        });
    },
    completesources:function(){
        if($('#sourcenavnext').attr('class').indexOf('active') !== -1){
            $('#sourceopt').addClass('loading');
            var slv = $('#sourcelist').children().eq($('#sourcelist').children().length-1);
            var sli = $('#sourcelist').children().length;
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'ajax',a:'loadSource',d:{offset:$('.sourceitem').length}}
            }).done(function(msg){
                msg = $.parseJSON(msg);
                var listgroup = '<div class="sourcelistgroup">';
                $.each(msg.sources,function(slidx,slival){
                    if(slidx % 10 == 0 && slidx > 0){
                        slidx += '</div><div class="sourcelistgroup">';
                    }
                    listgroup += '<li class="sourceitem" id="'+slival.id+'">'+slival.content+'</li>';
                });
                listgroup += '</div>';
                
                $(slv).after(listgroup);
                if(((sli+2) * sourcelist.sourcepergroup) >= sourcelist.numofsource){
                    $('#sourcenavnext').removeClass('active');
                     $('#sourceopt').removeClass('loading');
                     bulkdownloader.nextstep();
                }
                bulkdownloader.bulkdownload();
            });   
        }
    },
    started:false
};
function visitordata(){
    userid='0';
}
visitordata.prototype.init=function(){
    this.userid = localstorage.getItem('nownewsuid');
    if(this.userid == null || this.userid == 'undefined')
        this.userid = '0';
};
visitordata.prototype.setuserid=function(userid){
    if(this.userid == '0'){
        this.userid = userid;
        localstorage.setItem('nownewsuid',this.userid);
    }
};
var userdata = new visitordata();
var currentpaper ={
    debug:0,
    initscrolled:false,
    scrolled:0,
    save:function(papercontent){
        if(papercontent === false){
            var cpaper = localstorage.getItem('nownewspaper');
            if(cpaper === null || cpaper == 'null' || cpaper == 'undefined' || cpaper === ''){
                return;
            }
            
            currentpaper.scrolled = parseInt(localstorage.getItem('nownewspaperscrolled'));
            currentpaper.initscrolled = true;
            
            $('#downloadedcontainer').find('.descriptioncontainer').addClass('hide');
            $('#articlelistcontainer').html(cpaper);
            var downloadedpaperart = $('#articlelistcontainer').find('.articlepage');
            $('#downloadcount').html('('+downloadedpaperart.length+')');
            $('#princewoordphone').removeClass('unoccupied');
    
            for(var dl=0;dl<downloadedpaperart.length;dl++){
                downloaded.articles[dl] = $(downloadedpaperart[dl]).html();
                downloaded.rssids[dl] = $(downloadedpaperart[dl]).attr('id').substr(12);
            }
            
            
            $('#reviewmode').addClass('active');
            $('#articlelistcontainer').addClass('readingmode');
            $('body').find('.opaquebg').eq(0).addClass('readingmodeactive');
            if(mobile){
                setTimeout(function(){
                    $('#reviewmode').addClass('blur');
                    $('#princewoordphone').addClass('blur');
                    changepage('downloaded',false);
                },1000);   
            }
            else
                changepage('downloaded',false);
            
            return;
        }
        else if(papercontent === -1){
            if(this.initscrolled){
                if(currentpaper.scrolled == document.getElementById('articlelistcontainer').scrollTop){
                    this.initscrolled = false;
                }
            }
            else{
                currentpaper.scrolled = document.getElementById('articlelistcontainer').scrollTop;
                localstorage.setItem('nownewspaperscrolled',currentpaper.scrolled);
            }
            return;   
        }
        else if(papercontent == null){
            localstorage.setItem('nownewspaperscrolled',0);
        }
        localstorage.setItem('nownewspaper',papercontent);
    },
    scrollpaper:function(upordown){
          if(currentpaper.scrolled === false){
              return;
          }  
          if(upordown === false){
              $('#articlelistcontainer').scrollTop(currentpaper.scrolled);
              return;
          }
          if(currentpaper.scrolled != document.getElementById('articlelistcontainer').scrollTop){
              currentpaper.scrolled = document.getElementById('articlelistcontainer').scrollTop;
          }
          else{
              if(currentpaper.scrolled == document.getElementById('articlelistcontainer').scrollTop){
                  if(upordown === 0){
                    currentpaper.scrolled += 30;
                  }
                  else{
                      currentpaper.scrolled -= 30;
                  }
              }
              $('#articlelistcontainer').scrollTop(currentpaper.scrolled);
              this.save(-1);
          }
    }
};


var localstorage = false;
function getLocalStorage(){
    if (typeof localStorage == "object"){
        localstorage =  localStorage;
    } else if (typeof globalStorage == "object"){
        localstorage = globalStorage[location.host];
    } else {
        localstorage = false;
    }
    userdata.init();
}

var chartdataset=[];
var chartsettings=[];
var downloadnowcount = 0;
var searchresult ={
    items:[],
    currentsearch:[],
    keywords:[],
    keywithid:[],
    searchresultlimit:function(searchidx){
        return searchresult.currentsearch[searchidx]['resultlen'];
    },
    activekeywords:function(searchidx){
        return searchresult.currentsearch[searchidx]['keywords'];
    },
    setcurrent:function(keywords,datestart,dateend,resultlen){
        var currentsearchidx = searchresult.currentsearch.length;
        searchresult.currentsearch[currentsearchidx] = [];
        searchresult.currentsearch[currentsearchidx]['source']      = source.id;
        searchresult.currentsearch[currentsearchidx]['keywords']    = keywords;
        searchresult.currentsearch[currentsearchidx]['datestart']   = datestart;
        searchresult.currentsearch[currentsearchidx]['dateend']     = dateend;
        searchresult.currentsearch[currentsearchidx]['resultlen']   = resultlen;
        
        source.searchmode = currentsearchidx;
    },
    addkey:function(keyid,keyword){
        var loaded = false;
        $.each(searchresult.keywithid,function(theidx,thekey){
            if(thekey['id'] == keyid){
                loaded = true;
                return false;
            }
        });
        
        if(loaded == false){
            var keyidx = searchresult.keywithid.length;
            searchresult.keywithid[keyidx] = [];
            searchresult.keywithid[keyidx]['id'] = [keyid];
            searchresult.keywithid[keyidx]['keyword'] = keyword;
        }
    },
    addresult:function(rssitem){
        var newrss = {
            id:rssitem.id,
            description:rssitem.description,
            source:rssitem.source,
            category:rssitem.category,
            tags:rssitem.tags,
            title:rssitem.title,
            pubDate:rssitem.pubDate,
            creator:rssitem.creator,
            link:rssitem.link,
            downloadcount:rssitem.downloadcount,
            keywords:rssitem.keywords
        };
        
        var newidx = searchresult.items.length;
        searchresult.items[newidx] = newrss;
        
        if(typeof(rssitem.keywords) !== 'undefined'){
            $.each(rssitem.keywords,function(ki,kv){
                var loadedkey = false;
                $.each(searchresult.keywords,function(idx,elem){
                    if(elem['keywordid'] == kv){
                        loadedkey = idx;
                        return false;
                    }
                });
                
                if(loadedkey === false){
                    var keyidx = searchresult.keywords.length;
                    searchresult.keywords[keyidx] = [];
                    searchresult.keywords[keyidx]['keywordid'] = kv;
                    searchresult.keywords[keyidx]['map'] = [];
                    searchresult.keywords[keyidx]['map'][searchresult.keywords[keyidx]['map'].length] = newidx;
                }
                else{
                    searchresult.keywords[loadedkey]['map'][searchresult.keywords[loadedkey]['map'].length] = newidx;
                }
            });   
        }
    }
};
var rsslist={
    list:[],
    getrssbysourceandid:function(source,id){
        var aMap = rsslist.rsssourcemap.getmap(source);
        if(aMap === false)
            return false;
            
        $.each(aMap, function(idx,el){
            if(rsslist.list[el].id == id){
                rsslistitem.setItem(rsslist.list[el]);
                return false;
            }
        });
        return true;
    },
    getrss:function(indexes){
        var resultrss = [];
        $.each(indexes,function(idx,elem){
            resultrss[resultrss.length] = rsslist.list[elem];
        });
        return resultrss;
    },
    rsscategorymap:{
        map:[],
        getcategoriesbysource:function(sourceid){
            if(this.map.length){
                var categoriesresult = [];
                $.each(this.map,function(ix,el){
                    if(el['source'] === sourceid){
                        categoriesresult[categoriesresult.length] = el;
                    }
                });
                return categoriesresult;
            }
            return false;
        },
        addmap:function(rssidx,category,source){
            var mapidx = this.getmapidx(category);
            if(mapidx !== false){
                this.map[mapidx]['indexes'][this.map[mapidx]['indexes'].length] = rssidx;
            }
            else{
                mapidx = this.map.length;
                this.map[mapidx] = [];
                this.map[mapidx]['category']    = category;
                this.map[mapidx]['source']      = source;
                this.map[mapidx]['indexes']     = [];
                this.map[mapidx]['indexes'][this.map[mapidx]['indexes'].length] = rssidx;
            }
        },
        getmapidx:function(category){
            if(this.map.length){
                var idx = false;
                $.each(this.map,function(ix,el){
                    if(el['category'] == category){
                        idx = ix;
                        return false;
                    }
                });
                return idx;
            }
            return false;
        },
        getmap:function(category){
            var mapidx = this.getmapidx(category);
            if(mapidx !== false){
                return this.map[mapidx]['indexes'];
            }
            return mapidx;
        }
    },
    rsssourcemap:{
        map:[],
        addmap:function(rssidx,source){
            var mapidx = this.getmapidx(source);
            if(mapidx !== false){
                this.map[mapidx]['indexes'][this.map[mapidx]['indexes'].length] = rssidx;
            }
            else{
                mapidx = this.map.length;
                this.map[mapidx] = [];
                this.map[mapidx]['source']  = source;
                this.map[mapidx]['indexes'] = [];
                this.map[mapidx]['indexes'][this.map[mapidx]['indexes'].length] = rssidx;
            }
        },
        getmapidx:function(source){
            if(this.map.length){
                var idx = false;
                $.each(this.map,function(ix,el){
                    if(el['source'] == source){
                        idx = ix;
                        return false;
                    }
                });
                return idx;
            }
            return false;
        },
        getmap:function(source){
            var mapidx = this.getmapidx(source);
            if(mapidx !== false){
                return this.map[mapidx]['indexes'];
            }
            return mapidx;
        }
    },
    addrssitem:function(rssitem){
        var newrss = {
            id:rssitem.id,
            description:rssitem.description,
            source:rssitem.source,
            category:rssitem.category,
            tags:rssitem.tags,
            title:rssitem.title,
            pubDate:rssitem.pubDate,
            creator:rssitem.creator,
            link:rssitem.link,
            downloadcount:rssitem.downloadcount,
            datetosort:rssitem.datetosort
        };
        var newidx = rsslist.list.length;
        rsslist.list[newidx] = newrss;
        rsslist.rsssourcemap.addmap(newidx,rssitem.source);
        if(rssitem.tags.length){
            $.each(rssitem.tags,function(tagidx,tagelem){
                rsslist.rsscategorymap.addmap(newidx,tagelem,rssitem.source);
            });
        }
        else{
            rsslist.rsscategorymap.addmap(newidx,rssitem.category,rssitem.source);
        }
    }
};
var rsslistitem={
    id:0,
    description:'',
    source:0,
    category:0,
    tags:[],
    title:'',
    pubDate:'',
    creator:'',
    link:'',
    datetosort:'',
    reset:function(){
        this.id             = 0;
        this.description    = '';
        this.source         = 0;
        this.category       = 0;
        this.tags           = [];
        this.title          = '';
        this.pubDate        = '';
        this.creator        = '';
        this.link           = '';
        this.downloadcount  = 0;
        this.datetosort     = '';
    },
    setData:function(id,category,tags,description,source,title,pubDate,creator,link,downloadcount,datetosort){
        this.id             = id;
        this.category       = category;
        this.tags           = tags;
        this.description    = description;
        this.source         = source;
        this.title          = title;
        this.pubDate        = pubDate;
        this.creator        = creator;
        this.link           = link;
        this.downloadcount  = downloadcount;
        this.datetosort     = datetosort;
    },
    setItem:function(item){
        this.id             = item.id;
        this.category       = item.category;
        this.tags           = item.tags;
        this.description    = item.description;
        this.source         = item.source;
        this.title          = item.title;
        this.pubDate        = item.pubDate;
        this.creator        = item.creator;
        this.link           = item.link;
        this.downloadcount  = item.downloadcount;
        this.datetosort     = item.datetosort;
    }
};

var sourcelist={
    sourcepergroup:10,
    numofsource:numofsources,
    items:[],
    count:function(){
      return this.items.length;  
    },
    getSource:function(sourceid){
        var idx = this.getSourceidx(sourceid);
        if(idx !== false){
            source.reset();
            source.setitem(this.items[idx]);
        }
        else{
            source.reset();
        }
    },
    getSourceidx:function(sourceid){
        var sourceidx = false;
        $.each(this.items, function(index,elem){
            if(elem.id == sourceid){
                sourceidx = index;
                return false;
            }
        });
        return sourceidx;
    },
    sourcename:function(sourceid){
        return sourcelist.items[sourcelist.getSourceidx(sourceid)].name;
    },
    addSource:function(newsource){
        var sourceidx = sourcelist.getSourceidx(newsource.id);
        
        var newssource={
            id:newsource.id,
            name:newsource.name,
            url:newsource.url,
            description:newsource.description,
            cycle:newsource.cycle,
            lastfetched:newsource.lastfetched,
            logo:newsource.logo,
            categories:newsource.categories,
            currentcategory:typeof(newsource.currentcategory) == 'undefined' ? 0 : newsource.currentcategory,
            excludeinolder:typeof(newsource.excludeinolder) == 'undefined' ? [] : newsource.excludeinolder,
            oldestid:typeof(newsource.oldestid) == 'undefined' ? 0 : newsource.oldestid,
            searchmode:typeof(newsource.searchmode) == 'undefined' ? false : newsource.searchmode,
            categorylimit:typeof(newsource.categorylimit) == 'undefined' ? []: newsource.categorylimit
        };
        
        if(sourceidx === false){
            sourceidx = this.items.length;
            this.items[sourceidx] = newssource;
            return sourceidx;
        }
        else{
            this.items[sourceidx] = newssource;
        }
        return sourceidx;
    }
};
var source = {
     id:0,
     name:'',
     url:'',
     description:'',
     cycle:'',
     lastfetched:'',
     categories:[],
     currentcategory:0,
     excludeinolder:[],
     oldestid:0,
     searchmode:false,
     categorylimit:[],
    
    save:function(){
        if(this.id == 0)
          return;
        
        sourcelist.addSource(this);
    },
     reset:function(){
        this.id             =0;
        this.name           ='';
        this.url            ='';
        this.description    ='';
        this.cycle          ='';
        this.lastfetched    ='';
        this.categories     =[];
        this.currentcategory=0;
        this.excludeinolder =[];
        this.oldestid       =0;
        this.searchmode     =false;
        this.categorylimit  =[];
     },
     setSource:function(sourceid){
        this.save();
        this.reset();
        currentsource = sourceid;
        sourcelist.getSource(sourceid);
     },
     setitem:function(item){
        this.save();
        this.id             =item.id;
        this.name           =item.name;
        this.url            =item.url;
        this.description    =item.description;
        this.cycle          =item.cycle;
        this.lastfetched    =item.lastfetched;
        this.logo           =item.logo;
        this.categories     =item.categories;
        this.currentcategory=typeof(item.currentcategory) == 'undefined' ? 0 : item.currentcategory;
        this.excludeinolder =typeof(item.excludeinolder) == 'undefined' ? [] : item.excludeinolder;
        this.oldestid       =typeof(item.oldestid) == 'undefined' ? 0 : item.oldestid;
        this.searchmode     =typeof(item.searchmode) == 'undefined' ? false : item.searchmode;
        this.categorylimit  =typeof(item.categorylimit) == 'undefined' ? [] : item.categorylimit;
     },
     setCategory:function(category){
        this.currentcategory = category;
        this.save();
     },
     getCategories:function(){
        return this.categories;
     },
     getCategoryById:function(id){
        if(id == 0){
            return 'All Category';
        }
        var catname = false;
        $.each(this.categories,function(idx,el){
            if(el.id == id)
                catname = el.name;
        });
        return catname;
     }
};

var downloadlist={
    items:[],
    markDownloaded:function(rssids,removeandrefresh){
        if(removeandrefresh){
            $.each(rssids,function(itemidx,itemelem){
                downloadlist.deleteitem(itemelem);
            });
            downloadlist.refreshlist();
        }
        else{
             $.each(downloadlist.items,function(itemidx,itemelem){
                 if($.inArray(itemelem.id,rssids) !== -1){
                     downloadlist.items[itemidx].downloaded = true;
                 }
             });
        }
    },
    getById:function(rssid){
        var itembyid = false;
        $.each(this.items,function(itemidx,itemelem){
            if(itemelem.id == rssid){
                itembyid = itemelem;
                return false;
            }
        });
        return itembyid;
    },
    toDownload:function(limit){
        if(limit === 0)
            limit = this.items.length;
            
        var todownload = [];
        $.each(this.items,function(itemidx,itemelem){
            if(itemelem.downloaded === false){
                todownload[todownload.length] = itemelem.id;
                limit-=1;
                if(limit == 0)
                    return false;
            }
        });
        return todownload;
    },
    addtobulk:function(elem){
        newitem = {
            id:$(elem).attr('id').split('_')[1],
            source:$(elem).parent().parent().parent().attr('id').split('_')[1],
            pubDate:$(elem).parent().prev().prev().prev().children('.pubDate').html(),
            datetosort:$(elem).parent().prev().prev().html(),
            downloaded:false
        };
        newitem.title = $(elem).parent().prev().prev().prev().html().split('<span class="pubDate">')[0];
        this.items[this.items.length] = newitem; 
    },
    addnew:function(){
        newitem = {
            id:rsslistitem.id,
            source:rsslistitem.source,
            category:rsslistitem.category,
            title:rsslistitem.title,
            pubDate:rsslistitem.pubDate,
            datetosort:rsslistitem.datetosort,
            downloaded:false
        };
        this.items[this.items.length] = newitem;
    },
    upitem:function(selectrssid){
        $.each(downloadlist.items, function(itidx,itelem){
            if(itelem.id == selectrssid){
                if(itidx != 0){
                    var aux = downloadlist.items[itidx-1];
                    downloadlist.items[itidx-1] = downloadlist.items[itidx];
                    downloadlist.items[itidx] = aux;
                    return false;
                }
            }
        });
        downloadlist.refreshlist();
    },
    downitem:function(selectrssid){
        $.each(downloadlist.items, function(itidx,itelem){
            if(itelem.id == selectrssid){
                if(itidx != (downloadlist.items.length-1)){
                    var aux = downloadlist.items[itidx+1];
                    downloadlist.items[itidx+1] = downloadlist.items[itidx];
                    downloadlist.items[itidx] = aux;
                    return false;
                }
            }
        });
        downloadlist.refreshlist();
    },
    deleteitem:function(selectrssid){
        var delidx = false;
        $.each(downloadlist.items,function(dlidx,dlitem){
            if(dlitem.id == selectrssid){
                delidx = dlidx;
                return false;
            }
        });
        if(delidx !== false)
            downloadlist.items.splice(delidx,1);  
    },
    sorto:[],
    sort:function(sortby){
        if(this.sorto.length){
            if(this.sorto[0] == sortby){
                this.sorto[1] = !this.sorto[1];
            }
            else{
                this.sorto[0] = sortby;
                this.sorto[1] = true;
            }
        }
        else{
            this.sorto[0] = sortby;
            this.sorto[1] = true;
        }
        var alfasortval = ['0','1','2','3','4','5','6','7','8','9','_','/','.','-','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
        switch(this.sorto[0]){
            case 'source':
                downloadlist.items.sort(function(a,v){
                    if(downloadlist.sorto[1])
                        return alfasortval.indexOf(sourcelist.sourcename(a.source)[0]) - alfasortval.indexOf(sourcelist.sourcename(v.source)[0]);
                    else
                        return alfasortval.indexOf(sourcelist.sourcename(v.source)[0]) - alfasortval.indexOf(sourcelist.sourcename(a.source)[0]);
                });
            break;
            case 'title':
                downloadlist.items.sort(function(a,v){
                    if(downloadlist.sorto[1])
                        return alfasortval.indexOf(a.title[0]) - alfasortval.indexOf(v.title[0]);
                    else
                        return alfasortval.indexOf(v.title[0]) - alfasortval.indexOf(a.title[0]);
                });      
            break;
            case 'pubDate':
                downloadlist.items.sort(function(a,v){
                        var ddate = a.datetosort.split(' ')[0].split('-');
                        var dtime = a.datetosort.split(' ')[1].split(':');
                        ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
                        
                        var ddate_ = v.datetosort.split(' ')[0].split('-');
                        var dtime_ = v.datetosort.split(' ')[1].split(':');
                        ddate_ = new Date(parseInt(ddate_[0]),(parseInt(ddate_[1])-1),parseInt(ddate_[2]),dtime_[0],dtime_[1],dtime_[2]);
                        
                        if(downloadlist.sorto[1])
                            return ddate_ - ddate;
                        else
                            return ddate - ddate_;
                });
            break;
        }
        downloadlist.refreshlist();
    },
    refreshlist:function(){
        var list = '';
        $.each(this.items,function(idx,elem){
            list += '<li class="downloadlistitem">'
                        +'<span class="dlitemtitle">'+elem.title+'</span>'
                        +'<span class="dlitemact dlup" id="dlup_'+elem.id+'">&uarr;</span>'
                        +'<span class="dlitemact dldown" id="dldown_'+elem.id+'">&darr;</span>'
                        +'<span class="dlitemact dldel" id="dldel_'+elem.id+'">X</span>'
                    +'</li>';
        });
        $('#downloadlist').html(list);
        
        $('#paneltext').html(this.items.length);
        
        $('.downloadlistitem').on('click', function(){
            if($(this).attr('class').indexOf('active') === -1){
                $('.downloadlistitem').removeClass('active');
                $(this).addClass('active');
            }
            else{
                $(this).removeClass('active');
            }
        })
    }
};


var page ='rss';
var currentsource = 0;
var downloaded = {
    articles:[],
    rssids:[],
    downloadid:0
};

function readerkeys(){
    $(document).on('keydown',function(key){
        if($('#menudownloaded').attr('class').indexOf('active') != -1){
            if($('#thewoord').attr('class').indexOf('active') === -1){
                switch(key.which){
                    case 88:
                        clsdownloadedarticle();
                    break;
                    case 82:/*r*/
                        if(!$('#articlelistcontainer').children().length){
                            page = 'rss';
                            changepage(page,false);
                            return;
                        }
                        $('#reviewmode').addClass('active');
                        $('#articlelistcontainer').addClass('readingmode');
                        $('body').find('.opaquebg').eq(0).addClass('readingmodeactive');
                        if(mobile){
                            setTimeout(function(){
                                $('#reviewmode').addClass('blur');
                                $('#princewoordphone').addClass('blur');
                            },1000);   
                        }
                    break;
                    case 78:/*n*/
                        if($('#nightmode').attr('class').indexOf('active') == -1){
                            $('#daymode').removeClass('active');
                            $('.articlepage').addClass('nightmode');
                            $('#nightmode').addClass('active');
                        }
                    break;
                    case 68:/*d*/
                        if($('#daymode').attr('class').indexOf('active') == -1){
                            $('#nightmode').removeClass('active');
                            $('.articlepage').removeClass('nightmode');
                            $('#daymode').addClass('active');
                        }
                    break;
                    case 86:/*v*/
                        reviewmodefn();
                    break;
                    case 80:
                        if(typeof $('#princewoorddictionary').attr('class') === 'undefined' || $('#princewoorddictionary').attr('class').indexOf('active') === -1){
                            $('#princewoorddictionary').addClass('active');
                            $('#thewoord').addClass('active').val('').focus();
                        }
                    break;
                    case 40:
                        key.preventDefault();
                        currentpaper.scrollpaper(0);
                    break;
                    case 38:
                        key.preventDefault();
                        currentpaper.scrollpaper(1);
                    break;
                    case 27:
                        if(typeof $('#princewoorddictionary').attr('class') !== 'undefined' && $('#princewoorddictionary').attr('class').indexOf('active') !== -1){
                            $('#princewoorddictionary').removeClass('active');
                        }
                    break;
                }
            }
            else{
                if(key.which === 27){
                     $('#princewoorddictionary').removeClass('active');
                     $('#thewoord').removeClass('active');
                }
            }
        }
        else{
            if(key.which == 82){
                page = 'downloaded';
                changepage(page,false);
            }
        }
    });
}

function panelmenu(){
    $('.panelbutton').on('click',function(){
        if($('.sidebarpanel').attr('class').indexOf('active') === -1 ){
            hidesourceopt();
            var panelmenu = $(this).children('.active');
            $('.toolbox').hide();
            $('.toolbox'+$(panelmenu).attr('id').substr(6)).show();
            $('.sidebarpanel').addClass('active');   
        }
        else{
            $('.sidebarpanel').removeClass('active');   
        }
    });
    
    $('#downloaddownloadlist').on('click',function(){
        bulkdownloader.articdownload();
    });
    
    $('.dismissballoon').on('click',function(event){
        event.stopPropagation();
        $(this).parent().removeClass('active');
        $(this).parent().parent().removeClass('active');
    });
    
    $('#pdfdownloadlist').on('click',function(){
        if(downloadlist.items.length == 0)
            return;
        
        if($(this).attr('class').indexOf('active') != -1){
            return;
        }
        
        $('#downloadlistbox').find('.rssactionbutton').removeClass('active');
        $('#downloadopt').removeClass('active');
        $(this).addClass('active');
                
        $('#downloadingpdf').addClass('active');
        $('#downloadingpdf').children('.actionsubcontent').html('processing...');
    
        var todownloadaspdf = [];
        $.each(downloadlist.items,function(idx,ele){
            todownloadaspdf[todownloadaspdf.length] = ele.id;
        });
       
        $.ajax({
            url:'./',
            data:{app:appname,p:'ajax',a:'downloadPDF',d:{rssids:todownloadaspdf,userid:userdata.userid}},
            type:'POST'
        }).done(function(msg){
            var response = $.parseJSON(msg);
            userdata.setuserid(response.userid);
            if(response.status){
                downloadlist.items = [];
                downloadlist.refreshlist();
                $('.addtodownload').removeClass('disabled');
                window.open('./?app=nownews&p=ajax&a=fetchDownloadItem&d='+response.downloadid);
                
                $('#downloadingpdf').children('.actionsubcontent').html('Finished downloading, <br/><a href="./?p=ajax&a=fetchDownloadItem&d='+response.downloadid+'" target="_blank" id="fetchdownloadedpdf">fetch downloaded news</a>');
            }
            else{
                downloadingNews(response);
            }
        });
    });
    
    $('#downloaddownloadedaspdf').on('click',function(){
        if(downloaded.articles.length){
            if(downloaded.downloadid==0){
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'ajax',a:'localcontent',d:{content:$('#articlelistcontainer').html()}}
                }).done(function(msg){
                    if($('#downloadingdownloadedaspdf').attr('class').indexOf('active') === -1){
                        var downloadid = downloaded.downloadid;
                        $('#downloaddownloadedaspdf').addClass('active');
                        $('#downloadingdownloadedaspdf').children('.actionsubcontent').html('Click <a href="./?p=ajax&a=fetchDownloadItem&d='+downloadid+'" target="_blank">here</a> if popup doesnt open');
                        $('#downloadingdownloadedaspdf').addClass('active');
                        
                        window.open('./?app=nownews&p=ajax&a=fetchDownloadItem&d='+downloaded.downloadid);      
                    }
                });
                
                return;
            }
            if($('#downloadingdownloadedaspdf').attr('class').indexOf('active') === -1){
                var downloadid = downloaded.downloadid;
                $(this).addClass('active');
                $('#downloadingdownloadedaspdf').children('.actionsubcontent').html('Click <a href="./?p=ajax&a=fetchDownloadItem&d='+downloadid+'" target="_blank">here</a> if popup doesnt open');
                $('#downloadingdownloadedaspdf').addClass('active');
                
                window.open('./?app=nownews&p=ajax&a=fetchDownloadItem&d='+downloaded.downloadid);      
            }
        }
    });
    
    $('#articlelistcontainer').on('scroll',function(event){
        currentpaper.save(-1);
    });
    
    $('#cleardownloadedarticle').on('click',function(){
        clsdownloadedarticle();
    });
    
    $('#reviewmode').on('click',function(){
        if(mobile && $(this).attr('class').indexOf('blur') !== -1){
            $(this).removeClass('blur');
            setTimeout(function(){
                if($('#reviewmode').attr('class').indexOf('active') !== -1){
                    $('#reviewmode').addClass('blur');
                }
            },3000);
            return;
        }
        $('#articlelistcontainer').removeClass('readingmode');
        $('body').find('.opaquebg').eq(0).removeClass('readingmodeactive');
        $('#reviewmode').removeClass('active');
        $('#princewoordphone').removeClass('blur');
    });
    $('#readingmode').on('click',function(){
        $('#reviewmode').addClass('active');
        $('#articlelistcontainer').addClass('readingmode');
        $('body').find('.opaquebg').eq(0).addClass('readingmodeactive');
        $('.sidebarpanel').removeClass('active');
        
        if(mobile){
            setTimeout(function(){
                $('#reviewmode').addClass('blur');
                $('#princewoordphone').addClass('blur');
            },1000);   
        }
    });
        
    $('#nightmode').on('click',function(){
        if($(this).attr('class').indexOf('active') == -1){
            $('#daymode').removeClass('active');
            $('.articlepage').addClass('nightmode');
            $(this).addClass('active');
            $('.sidebarpanel').removeClass('active');
        }
    });
    $('#daymode').on('click',function(){
        if($(this).attr('class').indexOf('active') == -1){
            $('#nightmode').removeClass('active');
            $('.articlepage').removeClass('nightmode');
            $(this).addClass('active');
            $('.sidebarpanel').removeClass('active');
        }
    });
}
function downloadingNowNews(response){
    var downloaded      = response.downloaded;
    var downloadid      = response.downloadid;
    var downloadremain  = downloadlist.items.length;
    
    if($('#downloadingnow').attr('class').indexOf('active') == -1){
        $('#downloadopt').removeClass('active');
        $('#downloadingnow').addClass('active');
    }
    $('#downloadingnow').children('.actionsubcontent').html('processing...<br/>'+(downloadremain)+' download remaining');
        
    updateDownloadNow(downloadid);
}
function updateDownloadNow(downloadid){
    var downloadremainingstart = downloadlist.toDownload(1);
    $.ajax({
        url:'./',
        data:{app:appname,p:'ajax',a:'updateDownloadNow',d:{downloadid:downloadid,downloadremainingstart:downloadremainingstart}},
        type:'POST'
    }).done(function(msg){
        var response = $.parseJSON(msg);
        if(typeof(response.newsitems) !== 'undefined'){
            $('#downloadedcontainer').find('.descriptioncontainer').addClass('hide');
            
            var newlydownloaded = [];
            var nightmode = '';
            if($('#nightmode').attr('class').indexOf('active') !== -1){
                nightmode = ' nightmode';
            }
                
            $.each(response.newsitems, function(newsitemidx,newsitemelem){
                newlydownloaded[newlydownloaded.length] = newsitemelem.id;
                var downloaditem = downloadlist.getById(newsitemelem.id);
                rsslistitem.reset();
                rsslist.getrssbysourceandid(downloaditem.source,downloaditem.id);
                 
                 if(!bulkdownloader.started){
                     var newdownload = '<div class="articlepage'+nightmode+'" id="articlepage_'+ rsslistitem.id +'">'
                     +'<div class="articletitle">'+rsslistitem.title+'</div>'
                     +'<div class="articledate">'+rsslistitem.pubDate+' By '+ rsslistitem.creator +'</div>'
                     +'<div class="articlecategory"><span class="articlelabel">Category</span><span class="colon">:</span><span class="articleattr">'+source.getCategoryById(rsslistitem.category)+'</span></div>'
                     +'<div class="articlepublisher"><span class="articlelabel">Publisher</span><span class="colon">:</span><span class="articleattr">'+sourcelist.sourcename(rsslistitem.source)+'</span></div>'
                     +'<div class="articlecontent">'+newsitemelem.content+'</div>'
                     +'</div>';
                         
                    downloaded.articles[downloaded.articles.length] = newdownload;
                }
                else{
                    downloaded.articles[downloaded.articles.length] = rsslistitem.id;
                }
                downloaded.rssids[downloaded.rssids.length]     = rsslistitem.id;
                
                
                $('#downloadnow_'+rsslistitem.id).addClass('downloaded');
                $('#downloadnow_'+rsslistitem.id).removeClass('downloading');
                
                if(!bulkdownloader.started){
                    $('#articlepage_'+rsslistitem.id).replaceWith(newdownload);
                    $('#articlepage_'+rsslistitem.id).find('a').addClass('leavingpage').prop('target','_blank');
                    $('#articlepage_'+rsslistitem.id).find('img').addClass('newsart').prop('srcset','');   
                }
            });
            downloadlist.markDownloaded(newlydownloaded,true);
            $('#downloadingnow').children('.actionsubcontent').html('processing...<br/>'+(downloadlist.items.length)+' download remaining');
            if(!bulkdownloader.started){
                $('#downloadcount').html('('+ downloaded.articles.length +')');
                $('#princewoordphone').removeClass('unoccupied');
            }
        }
        if(response.status == 'finished'){
            $('.addtodownload').removeClass('disabled');
            
            if($('#downloadingnow').attr('class').indexOf('active') !== -1){
                if($('#downloadingnow').children('.actionsubcontent').html().indexOf('processing') !== -1){
                    $('#downloadingnow').children('.actionsubcontent').html('Finished, '+downloadnowcount+' items successfully downloaded');
                    downloadlist.items = [];
                    downloadlist.refreshlist();
                    if(!bulkdownloader.started){
                        currentpaper.save($('#articlelistcontainer').html());
                    }
                    else{
                        bulkdownloader.nextstep();
                        bulkdownloader.bulkdownload();
                    }
                }
            }
            $('#menurss').removeClass('processing');
        }
        else{
            updateDownloadNow(downloadid);
        }
    });
}
function checkDownloadStatus(downloadid){
    var downloadremainingstart  = downloadlist.toDownload(1);
    $.ajax({
        url:'./',
        data:{app:appname,p:'ajax',a:'checkDownloadStatus',d:{downloadid:downloadid,downloadremainingstart:downloadremainingstart}},
        type:'POST'
    }).done(function(msg){
        var response = $.parseJSON(msg);
        if(typeof(response.newsitems) !== 'undefined' && response.newsitems.length){
            downloadlist.markDownloaded(response.newsitems,true);
            $('#downloadingpdf').children('.actionsubcontent').html('processing...<br/>'+(downloadlist.items.length)+' download remaining');
        }
        
        if(response.status == 'finished'){
            downloadlist.items = [];
            downloadlist.refreshlist();
            $('.addtodownload').removeClass('disabled');
            
            if($('#downloadingpdf').attr('class').indexOf('active') !== -1){
                if($('#downloadingpdf').children('.actionsubcontent').html().indexOf('processing') !== -1){
                    window.open('./?app=nownews&p=ajax&a=fetchDownloadItem&d='+downloadid);
                    $('#downloadingpdf').children('.actionsubcontent').html('Finished downloading, <br/><a href="./?p=ajax&a=fetchDownloadItem&d='+downloadid+'" target="_blank">fetch downloaded news</a>');
                }
            }
        }
        else{
            if($('#downloadingpdf').attr('class').indexOf('active') !== -1){
                if($('#downloadingpdf').children('.actionsubcontent').html().indexOf('processing') !== -1){
                    $('#downloadingpdf').children('.actionsubcontent').html('processing...<br/>'+(downloadlist.items.length)+' download remaining');
                }
            }
            checkDownloadStatus(downloadid);
        }
    });
}
function downloadingNews(response){
    var downloadid              = response.downloadid;
    var downloadremain          = downloadlist.items.length;
    
    if($('#downloadingpdf').attr('class').indexOf('active') == -1){
        $('#downloadopt').removeClass('active');
        $('#downloadingpdf').addClass('active');
    }
    $('#downloadingpdf').children('.actionsubcontent').html('processing...<br/>'+(downloadremain)+' download remaining');
    
    checkDownloadStatus(downloadid);
}
function hidepanelmenu(){
    $('.sidebarpanel').removeClass('active');
}
function nextrss(dest){
    rsswidth = $('#rsslistcontainer').width();
    
    $('#rss_'+currentsource).children('.rsshead').addClass('slidingmode');
    $('#rss_'+currentsource).animate({'margin-left':(0-rsswidth)+'px'},'fast',function(){
        $('.prevrss').show();
        source.setSource(parseInt($('#rss_'+currentsource).next().attr('id').substr(4)));
        $('#rss_'+source.id).children('.rsshead').removeClass('slidingmode');
        
        if(typeof($('#rss_'+source.id).next().attr('id')) == 'undefined'){
            $('.nextrss').hide();
        }
        else{
            if(dest !== 0 && source.id != dest){
                nextrss(dest);
            }
        }
    });
}
function prevrss(destrss){
    rsswidth = $('#rsslistcontainer').width();
    $('#rss_'+source.id).children('.rsshead').addClass('slidingmode');
    if(typeof($('#rss_'+source.id).prev().attr('id')) !== 'undefined'){
        source.setSource(parseInt($('#rss_'+source.id).prev().attr('id').substr(4)));
        $('#rss_'+source.id).animate({'margin-left':'0px'},'fast',function(){
            $('#rss_'+source.id).children('.rsshead').removeClass('slidingmode');
            
            if( ('rss_'+source.id) === $('#rsslistcontainer').children('.rsslist').eq(0).attr('id'))
                $('.prevrss').hide();
                
            $('.nextrss').show();
            
            if(destrss !== 0){
                if(destrss != source.id){
                    prevrss(destrss);
                }
            }
        });   
    }
}
function rssnav(){
    $('.nextrss').on('click',function(){
        nextrss(0);
    });    
    $('.prevrss').on('click',function(){
        prevrss(0);
    });
    $('#clsdownloadlist').on('click',function(){
        downloadlist.items = [];
        downloadlist.refreshlist();
        
        $('#downloadlistbox').find('.actionsub').removeClass('active');
        $('#downloadlistbox').find('.rssactionbutton').removeClass('active');
        
        $('.addtodownload').removeClass('disabled');
    });
    
    $('#sortdownloadlist').on('click',function(){
        if(typeof($('#downloadopt').attr('class')) === 'undefined' || $('#downloadopt').attr('class').indexOf('active') === -1){
            $('#downloadlistbox').find('.actionsub').removeClass('active');
            $('#downloadlistbox').find('.rssactionbutton').removeClass('active');
            
            $('#downloadopt').addClass('active');
            $(this).addClass('active');
        }
        else{
            $(this).removeClass('active');
            $('#downloadopt').removeClass('active');
        }
    });
    $('.downloadoptitem').on('click',function(){
        var sortby = this.id.substr(12);
        downloadlist.sort(sortby);
    });
    $('#downloadlist').delegate('.dldel','click',function(){
       var selectrssid = this.id.substr(6);
       downloadlist.deleteitem(selectrssid);
       downloadlist.refreshlist();
       $('#'+this.id).parent().remove();
       $('#addtodownload_'+selectrssid).removeClass('disabled');
    });
    $('#downloadlist').delegate('.dlup','click',function(){
       var selectrssid = this.id.substr(5);
       downloadlist.upitem(selectrssid);
    });
    $('#downloadlist').delegate('.dldown','click',function(){
       var selectrssid = this.id.substr(7);
       downloadlist.downitem(selectrssid);
    });
}
function pagetabs(){
    $('.menutab').on('click',function(){
        page = $(this).attr('id').substr(4);
        changepage(page,false);
    });
}
function changepage(newpage,showsource){
    closemessage();
    hidepanelmenu();
    if(!showsource)
        hidesourceopt();
    page = newpage;
    

    
    $('.sidebarpanel').removeClass('hidden');
    
    if(page !== 'rss'){
        if(page == 'settings'){
            $('.sidebarpanel').addClass('hidden');
        }
        $('#togglesource').addClass('hide');
    }
    else{
        $('#togglesource').removeClass('hide');
    }
    $('.menutab').removeClass('active');
    $('#menu'+page).addClass('active');
    
    $('.panelbutton').children().removeClass('active');
    $('.panelbutton').children('#pbmenu'+page).addClass('active');
    
    $('.contentcontainer').removeClass('active');
    $('#'+page+'container').addClass('active');
    
    if(page =='downloaded'){
        currentpaper.scrollpaper(false);
    }
}
function sourceopt(){
    $('#togglesource').on('click',function(){
        if(typeof($('#togglesource').attr('class')) === 'undefined' || $('#togglesource').attr('class').indexOf('active') === -1){
            showsourceopt();
        }
        else{
            hidesourceopt();
        }
    })
}
function sourcelistnav(){
    $('#sourcenavnext').on('click',function(){
        $.each($('.sourcelistgroup'),function(sli,slv){
            if($(slv).attr('class').indexOf('active') !== -1){
                if(typeof($(slv).next().attr('class')) !== 'undefined'){
                    $(slv).removeClass('active');
                    $(slv).next().addClass('active');
                    if(((sli+2) * sourcelist.sourcepergroup) >= sourcelist.numofsource){
                       $('#sourcenavnext').removeClass('active');
                       $('#sourcelist').addClass('endorfirst');
                    }
                    else{
                        $('#sourcelist').removeClass('endorfirst');
                    }
                    $('#sourcenavprev').addClass('active'); 
                    return false;
                }
                else{
                    $('#sourceopt').addClass('loading');
                    $.ajax({
                        url:'./',
                        type:'POST',
                        data:{app:appname,p:'ajax',a:'loadSource',d:{offset:$('.sourceitem').length}}
                    }).done(function(msg){
                        msg = $.parseJSON(msg);
                        var listgroup = '<div class="sourcelistgroup">';
                        $.each(msg.sources,function(slidx,slival){
                            if(slidx % 10 == 0 && slidx > 0){
                                slidx += '</div><div class="sourcelistgroup">';
                            }
                            listgroup += '<li class="sourceitem" id="'+slival.id+'">'+slival.content+'</li>';
                        });
                        listgroup += '</div>';
                        
                        $(slv).after(listgroup);
                        $(slv).removeClass('active');
                        $(slv).next().addClass('active');
                        if(((sli+2) * sourcelist.sourcepergroup) >= sourcelist.numofsource){
                            $('#sourcenavnext').removeClass('active');
                            $('#sourcelist').addClass('endorfirst');
                        }
                        else{
                            $('#sourcelist').removeClass('endorfirst');
                        }
                        $('#sourcenavprev').addClass('active'); 
                        
                        $('#sourceopt').removeClass('loading');
                        return false;
                    });
                }
            }
        });
    });
    $('#sourcenavprev').on('click',function(){
        $.each($('.sourcelistgroup'),function(sli,slv){
            if($(slv).attr('class').indexOf('active') !== -1 && typeof($(slv).prev().attr('class')) !== 'undefined'){
                $(slv).removeClass('active');
                $(slv).prev().addClass('active');
                
                $('#sourcenavnext').addClass('active');
                if((sli-1) == 0){
                    $('#sourcenavprev').removeClass('active');  
                    $('#sourcelist').addClass('endorfirst');
                }
                else{
                    $('#sourcelist').removeClass('endorfirst');
                }
                return false;
            }
        });
    });
}
function showsourceopt(){
    hidepanelmenu();
    $('#togglesource').addClass('active');
    $('#sourceopt').addClass('active');
}
function hidesourceopt(){
    $('#togglesource').removeClass('active');
    $('#sourceopt').removeClass('active');
}
function rss(){
    $('#sourcelist').delegate('.sourceitem','click',function(event){
        event.stopPropagation();
        $('#menurss').addClass('processing');
        
        var sourceid = this.id.substr(11);
        getRss(sourceid); 
    });
    $('.descriptioncontainer').on('click',function(){
        closemessage();
        hidesourceopt();
        hidepanelmenu();
    });
    $('#rsslistcontainer').on('click',function(){
        closemessage();
        hidesourceopt();
        hidepanelmenu();
        $('.rssitem').removeClass('opaque');
        $('.categorieslist').removeClass('active');
        $('.rsstags').removeClass('active');
    });
    $('#rsslistcontainer').delegate('.rssitem','click',function(event){
        event.stopPropagation();
        closemessage();
        hidesourceopt();
        hidepanelmenu();
        $('.rssitem').removeClass('opaque');
        $('.categorieslist').removeClass('active');
        $('.rsstags').removeClass('active'); 
    });
    $('.descriptioncontainer').on('click',function(event){
        closemessage();
        hidesourceopt();
        hidepanelmenu();
    });
    $('#articlelistcontainer').on('click',function(event){
        event.stopPropagation();
        closemessage();
        hidesourceopt();
        hidepanelmenu();
        if($('#reviewmode').attr('class').indexOf('active') === -1){
            $('#princewoorddictionary').removeClass('active');   
        }
    });
}

function freshnews(sourceid,newsource){
    source.save();
    source.reset();
    source.setitem(newsource);
    
    sourcelist.addSource(source);
    var message     = '<b>'+newsource.name+'</b> was last fetched on :<br/><div><br/>'+newsource.lastfetched+'</div><br/></div>';
    var submitopt   = '<span class="threecol"><a href="javascript:void(0);" onclick="closemessage();" class="button left">Cancel</a></span><span class="threecol"><a href="javascript:void(0);" onclick="archive('+sourceid+')" class="button center">Archive</a></span><span class="threecol"><a href="javascript:void(0);" class="button right" onclick="rssupdates('+sourceid+')">Update</a></span>';
    var title       = 'Rss Download';
    displaymessage(title,message,submitopt);
}
function displaymessage(title,message,submitopt){
    $('#messagetitle').html(title);
    $('#themessage').html(message);
    $('#submitoption').html(submitopt);
    $('#messagepup').addClass('active');
    
    $('body').children('.opaquebg').addClass('active');
}
function closemessage(){
    $('#messagetitle').html('');
    $('#themessage').html('');
    $('#messagepup').removeClass('active');
    
    $('body').children('.opaquebg').removeClass('active');
}
function populatersslist(rss,newsource,limit){
    if(typeof(newsource) == 'object'){
        source.setitem(newsource);
        sourcelist.addSource(source);
    }
    else{
        source.setitem(sourcelist.items[sourcelist.getSourceidx(newsource)]);
    }
    if(rss.length){
        for(var ti=0;ti<rss.length;ti++){
            rsslistitem.reset();
            if(searchresult.items.length && source.searchmode !== false){
                rsslist.getrssbysourceandid(source.id,rss[ti].id);
                if(rsslistitem.id === 0){
                    rsslistitem.setData(rss[ti].id,rss[ti].category,rss[ti].tags,rss[ti].description,rss[ti].newssource,rss[ti].title,rss[ti].pubDate,rss[ti].creator,rss[ti].link,rss[ti].downloadcount,rss[ti].datetosort);
                    rsslist.addrssitem(rsslistitem);   
                }
                else{
                    rss.splice(ti,1,[]);
                    ti--;
                }
            }
            else{
                rsslistitem.setData(rss[ti].id,rss[ti].category,rss[ti].tags,rss[ti].description,rss[ti].newssource,rss[ti].title,rss[ti].pubDate,rss[ti].creator,rss[ti].link,rss[ti].downloadcount,rss[ti].datetosort);
                rsslist.addrssitem(rsslistitem); 
            }
        }
        
        if(sourcelist.items.length ===1){
            newrsslist(rss,source.id );
        }
        else{
            appendrsslist(rss,source.id );
        }   
    }
    
        if(bulkdownloader.started){
            var idxofsid = bulkdownloader.drsslistqueue.indexOf(parseInt(source.id));
            bulkdownloader.drsslistqueue.splice(idxofsid,1);   
        }
}
function shortlinklong(shortlink){
    $(shortlink).removeClass('active');
    var longlink = $(shortlink).siblings('.linklong');
    $(longlink).addClass('active');
    $(longlink).focus();
    $(longlink).on('blur',function(){
        $(shortlink).addClass('active');
        $(this).removeClass('active');
    });
}
function messageloading(){
    if($('#messageloading').attr('class').indexOf('active') == -1){
        $('#messageloading').addClass('active');
        $('#themessage').addClass('hidden');
    }
    else{
        $('#messageloading').removeClass('active');
        $('#themessage').removeClass('hidden');
    }
}
function displayloading(parentdiv){
    $('#'+parentdiv).children('.loadingnotifcontainer').css('display','block');
    $('#'+parentdiv).children('.opaquebg').css('display','block');
}
function hideloading(parentdiv){
    $('#'+parentdiv).children('.loadingnotifcontainer').css('display','none');
    $('#'+parentdiv).children('.opaquebg').css('display','none');
}
function getRss(sourceid){
    closemessage();
    hidesourceopt();
    hidepanelmenu();
    
    var waitingline = false;
    if(sourceid===false){
        sourceid = 0-parseInt(downloadnowqueue[0]);
        downloadnowqueue.splice(0,1);
        waitingline = true;
    }
    if(typeof $('#rss_'+sourceid).attr('class') === 'undefined'){
        if(downloadnowprocessing && waitingline===false){
            var inqueue = 0-parseInt(sourceid);
            downloadnowqueue.unshift(inqueue);
            return;
        }
         $.ajax({
            url:'./',
            data:{app:appname,p:'ajax',a:'getRss',d:{source:sourceid}},
            type:'POST'
        }).done(function(msg){
            msg = $.parseJSON(msg);
            if(msg.downloadnew){
                source.oldestid = msg.rss[msg.rss.length -1].id;
                populatersslist(msg.rss,msg.nsource,false);
            }
            else{
                freshnews(sourceid,msg.nsource);
            }
            if(!downloadnowqueue.length)
                $('#menurss').removeClass('processing');
            else{
                downloadnow(false);
            }
        });   
    }
    else{
        var currentsourceidx = sourcelist.getSourceidx(currentsource);
        var destsourceidx = sourcelist.getSourceidx(sourceid);
        if(currentsourceidx < destsourceidx){
            nextrss(sourceid);
        }
        else{
            prevrss(sourceid);
        }
        if(!downloadnowqueue.length)
            $('#menurss').removeClass('processing');
        else{
            downloadnow(false);
        }
    }
}
function archive(sourceid){
    closemessage();
    hidesourceopt();
    hidepanelmenu();
    $('#menurss').addClass('processing');
    $.ajax({
        url:'./',
        data:{app:appname,p:'ajax',a:'getArchive',d:{source:sourceid}},
        type:'POST'
    }).done(function(msg){
        msg = $.parseJSON(msg);
        if(msg.rss.length){
            populatersslist(msg.rss,msg.nsource,msg.limit);
            source.oldestid = msg.rss[msg.rss.length -1].id;
        }
        $('#menurss').removeClass('processing');    
    });
}
function rssupdates(sourceid){
    closemessage();
    hidesourceopt();
    hidepanelmenu();
    $('#menurss').addClass('processing');
    $.ajax({
        url:'./',
        data:{app:appname,p:'ajax',a:'getRss',d:{source:sourceid,downloadupdates:true}},
        type:'POST'
    }).done(function(msg){
        msg = $.parseJSON(msg);
        if(msg.rss.length){
            populatersslist(msg.rss,msg.nsource,false);
            source.oldestid = msg.rss[msg.rss.length -1].id;   
        }
        $('#menurss').removeClass('processing');
    });
}
function olderSearch(){
    closemessage();
    hidesourceopt();
    hidepanelmenu();
    
    $('#rss_'+source.id).children('.rssupdatecontainer').addClass('loadolder');
    
      var nowsearch         = searchresult.currentsearch[source.searchmode];
      var start             = nowsearch['resultlen']+1;
      searchresult.currentsearch[source.searchmode]['resultlen'] += 1;
      
      var excludingcat      = [];
      var excludingcatcount = [];
      var excludingcatoldest= [];
      
      $.each(source.excludeinolder,function(six,selem){
          excludingcat[excludingcat.length]             = selem['category'];
          excludingcatcount[excludingcatcount.length]   = selem['count'];
          excludingcatoldest[excludingcatoldest.length] = selem['oldestid'];
      });
      
        var caction = 'searchNews';
        if(nowsearch['keywords'] ==0){
            caction = 'searchNewsByDate';
        }
        else if(nowsearch['dateend'] == 0 && nowsearch['datestart'] == 0){
            caction = 'searchByKey';
        }
      
      $.ajax({
          url:'./',
          data:{app:appname,p:'ajax',a:caction,d:{userid:userdata.userid,source:source.id,start:start,excludecat:excludingcat,excludecatcount:excludingcatcount,excludeoldestid:excludingcatoldest,oldestid:source.oldestid,keywords:nowsearch['keywords'],startdate:nowsearch['datestart'],enddate:nowsearch['dateend']}},
          type:'POST'
      }).done(function(msg){
          msg = $.parseJSON(msg);
          userdata.setuserid(msg.userid);
          
          if(msg.excluding.length){
              source.excludeinolder = [];
              $.each(msg.excluding, function(eix,eelem){
                  if(eelem['count'] > 0){
                      var excludeidx = source.excludeinolder.length;
                      source.excludeinolder[excludeidx] = [];
                      source.excludeinolder[excludeidx]['category'] = eelem['category'];
                      source.excludeinolder[excludeidx]['count'] = eelem['count'];
                      source.excludeinolder[excludeidx]['oldestid'] = eelem['oldestid'];
                  }
              });
          }
          
          var oldkey = [];
          if(msg.limit){
            searchresult.currentsearch[source.searchmode]['resultlen'] = false;
          }
          displaysearchresult(msg.searchresult,oldkey,msg.limit);
      });
}
function olderNews(sourceid){
    closemessage();
    hidesourceopt();
    hidepanelmenu();
    $('#rss_'+sourceid).children('.rssupdatecontainer').addClass('loadolder');
    
    if(source.currentcategory != 0){
        var currentcatindexes = rsslist.rsscategorymap.getmap(source.currentcategory);
        currentcatindexes = currentcatindexes == false ? 0 : currentcatindexes.length;
        var start =  currentcatindexes;
        
        $.each(currentcatindexes,function(mapidxidx,mapidx){
            if($('#rssitem_'+rsslist.list[mapidx].id).attr('class').indexOf('searchresult') !== -1){
                start -=1;
            }
        });
        
        $.ajax({
            url:'./',
            data:{app:appname,p:'ajax',a:'olderNewsCategory',d:{source:sourceid,start:start,category:source.currentcategory}},
            type:'POST'
        }).done(function(msg){
            msg = $.parseJSON(msg);
            if(msg.rss.length > 0){
                var loadedbefore = false;
            
                if(source.excludeinolder.length){
                    $.each(source.excludeinolder,function(eidx,eelem){
                        if(eelem['category'] == source.currentcategory){
                            source.excludeinolder[eidx]['count']    += msg.rss.length;
                            source.excludeinolder[eidx]['oldestid'] = msg.rss[msg.rss.length-1].id;
                            loadedbefore = true;
                            return false;
                        }
                    });
                }
                
                if(loadedbefore === false){
                    excludeidx = source.excludeinolder.length;
                    source.excludeinolder[excludeidx] = [];
                    source.excludeinolder[excludeidx]['category']   = source.currentcategory;
                    source.excludeinolder[excludeidx]['count']      = msg.rss.length;
                    source.excludeinolder[excludeidx]['oldestid']   = msg.rss[msg.rss.length-1].id;
                }
                
                populatersslist(msg.rss,sourceid,false);
            }
  
            $('#rss_'+sourceid).children('.rssupdatecontainer').removeClass('loadolder');
            if(msg.limit){
                source.categorylimit[source.categorylimit.length] = source.currentcategory;
            }
            updaterssupdatebutton('rsslist');
        });
    }
    else{
        var start = rsslist.rsssourcemap.getmap(sourceid).length;
        var excludingcat = [];
        var excludingcatcount = [];
        
        $.each(source.excludeinolder,function(six,selem){
            excludingcat[excludingcat.length]           = selem['category'];
            excludingcatcount[excludingcatcount.length] = selem['count'];
            start -= selem['count'];
        });
        
        start -= $('#rss_'+source.id).children('.rssitem.searchresult').length;
        
        $.ajax({
            url:'./',
            data:{app:appname,p:'ajax',a:'olderNews',d:{source:sourceid,start:start,excludecat:excludingcat,excludecatcount:excludingcatcount}},
            type:'POST'
        }).done(function(msg){
            msg = $.parseJSON(msg);
            
            if(msg.excluding.length){
                source.excludeinolder = [];
                $.each(msg.excluding, function(eix,eelem){
                    if(eelem['count'] > 0){
                        var excludeidx = source.excludeinolder.length;
                        source.excludeinolder[excludeidx] = [];
                        source.excludeinolder[excludeidx]['category'] = eelem['category'];
                        source.excludeinolder[excludeidx]['count'] = eelem['count'];
                        
                        var oldestid = 0;
                        $.each(msg.rss,function(rssidx,rsselem){
                            if(rsselem.category == eelem.category)
                            oldestid = rsselem.id;
                        });
                        source.excludeinolder[excludeidx]['oldestid'] = oldestid;
                    }
                    else{
                        if(source.oldestid !== 0){
                            if(eelem['oldestid'] < source.oldestid)
                                source.oldestid = eelem['oldestid'];
                        }
                        else{
                            source.oldestid = eelem['oldestid'];
                        }
                    }
                });
            }
            
            if(msg.rss.length){
                populatersslist(msg.rss,sourceid,false);
                
                if(source.oldestid !== 0){
                    if(msg.rss[msg.rss.length-1].id < source.oldestid)
                        source.oldestid = msg.rss[msg.rss.length-1].id;
                }
                else{
                        source.oldestid = msg.rss[msg.rss.length-1].id;
                }
            }
 

                
            $('#rss_'+sourceid).children('.rssupdatecontainer').removeClass('loadolder');
            
            if(msg.limit){
                source.categorylimit[source.categorylimit.length] = source.currentcategory;
            }
            updaterssupdatebutton('rsslist');
        });
    }
}
function newrsslist(therss, sourceid){
    source.setitem(sourcelist.items[sourcelist.getSourceidx(sourceid)]);
    var rsscategorylist = '<li class="rsscategorylistitem"><a href="javascript:void(0)" id="rssbycat_0_'+sourceid+'">All Category</a></li>';
    $.each(source.getCategories(), function(idx,elem){
        rsscategorylist += '<li class="rsscategorylistitem"><a href="javascript:void(0)" id="rssbycat_'+elem.id+'">'+elem.name+'</a></li>';
    });
    
    if(typeof($('#rss_'+sourceid).attr('id')) === 'undefined'){
        var newrss = '<div class="rsslist" id="rss_'+sourceid+'">';
        newrss += '<div class="rsshead">'
                        +'<div class="rssheadlogo"><div class="table"><div class="tablecell"><img src="'+ source.logo +'"></div></div></div>'
                        +'<div class="rssheaddescription">'+source.description+'</div>'
                        +'<div class="rssaction">'
                            +'<span class="rsslink"><a href="javascript:void(0);" onclick="shortlinklong(this);" class="linkshort active">http://</a><input type="text" value="'+source.url+'" class="linklong"></span>'
                            +'<span class="rssallcategory"><span class="activecategory">All Category</span><ul class="categorieslist">'+rsscategorylist+'</ul></span>'
                            +'<span class="rssactionbutton search">Search</span>'
                        +'</div>'
                    +'</div>'
                    +'<div class="rssheadbg"></div>';
                    
            $.each(therss, function(index,elem){
                if(typeof(elem.id) !== 'undefined'){
                    if(elem.tags.length > 0){
                        var elemcategory = '<span class="rssactionbutton category tagslist">categories<ul class="rsstags">';
                        $.each(elem.tags,function(tagidx,tagelem){
                            elemcategory += '<li class="rsscategoryitem" id="rssitemcat_'+tagelem+'_'+elem.id+'"><a href="javascript:void(0);">'+source.getCategoryById(tagelem)+'</a></li>';
                        });
                        elemcategory += '</ul></span>';
                    }
                    else{
                        var elemcategory = '<span class="rssactionbutton category" id="rssitemcat_'+elem.category+'_'+elem.id+'">'+source.getCategoryById(elem.category)+'</span>';
                    }
                    newrss+= '<div class="rssitem" id="rssitem_'+elem.id+'">'
                                +'<div class="rsstitle">'+elem.title+'<span class="pubDate">'+elem.pubDate+'</span></div>'
                                +'<div class="hiddensortvar">'+elem.datetosort+'</div>'
                                +'<div class="rsscontent">'+elem.description+'</div>'
                                +'<div class="rssaction">'
                                    +'<span class="rsslink"><a href="javascript:void(0);" onclick="shortlinklong(this);" class="linkshort active">http://</a><input type="text" value="'+elem.link+'" class="linklong"></span>'
                                    + elemcategory
                                    +'<span class="rssactionbutton addtodownload" id="addtodownload_'+elem.id+'"></span>'
                                    +'<span class="rssactionbutton downloadnow" id="downloadnow_'+elem.id+'"></span>'
                                +'</div>'
                            +'</div>';
                }
            });
        
        newrss += '<div class="rssupdatecontainer">Older News</div>';
        newrss += '</div>';
        
        $('#rsslistcontainer').html(newrss);
        $('#rsslistcontainer').siblings('.descriptioncontainer').addClass('hide');
        $('#rsslistcontainer').addClass('notempty');
        
        rsslinks('rss_'+sourceid);
        rsslistwidth();
    }
    else{
        var newrss = '';
        $.each(therss, function(index,elem){
            if(typeof(elem.id) !== 'undefined'){
                if(elem.tags.length>0){
                    var elemcategory = '<span class="rssactionbutton category tagslist">categories<ul class="rsstags">';
                    $.each(elem.tags,function(tagidx,tagelem){
                        elemcategory += '<li class="rsscategoryitem" id="rssitemcat_'+tagelem+'_'+elem.id+'"><a href="javascript:void(0);">'+source.getCategoryById(tagelem)+'</a></li>';
                    });
                    elemcategory += '</ul></span>';
                }
                else{
                    var elemcategory = '<span class="rssactionbutton category" id="rssitemcat_'+elem.category+'_'+elem.id+'">'+source.getCategoryById(elem.category)+'</span>';
                }
                
                newrss+= '<div class="rssitem" id="rssitem_'+elem.id+'">'
                             +'<div class="rsstitle">'+elem.title+'<span class="pubDate">'+elem.pubDate+'</span></div>'
                             +'<div class="hiddensortvar">'+elem.datetosort+'</div>'
                             +'<div class="rsscontent">'+elem.description+'</div>'
                             +'<div class="rssaction">'
                                 +'<span class="rsslink"><a href="javascript:void(0);" onclick="shortlinklong(this);" class="linkshort active">http://</a><input type="text" value="'+elem.link+'" class="linklong"></span>'
                                 + elemcategory
                                 +'<span class="rssactionbutton addtodownload" id="addtodownload_'+elem.id+'"></span>'
                                 +'<span class="rssactionbutton downloadnow" id="downloadnow_'+elem.id+'"></span>'
                             +'</div>'
                         +'</div>';
            }
        });
        newrss += '<div class="rssupdatecontainer">Older News</div>';
        $('#rss_'+sourceid).children('.rssupdatecontainer').replaceWith(newrss);
    }
    source.setSource(sourceid);
}
function appendrsslist(therss,sourceid){
    var rsscategorylist = '<li class="rsscategorylistitem"><a href="javascript:void(0)" id="rssbycat_0_'+sourceid+'">All Category</a></li>';
    
    $.each(source.getCategories(), function(idx,elem){
        rsscategorylist += '<li class="rsscategorylistitem"><a href="javascript:void(0)" id="rssbycat_'+elem.id+'">'+elem.name+'</a></li>';
    });
    
    if(typeof($('#rss_'+sourceid).attr('id')) === 'undefined'){
        var newrss = '<div class="rsslist" id="rss_'+sourceid+'">';
        newrss += '<div class="rsshead slidingmode">'
                    +'<div class="rssheadlogo"><div class="table"><div class="tablecell"><img src="'+ source.logo +'"></div></div></div>'
                    +'<div class="rssheaddescription">'+source.description+'</div>'
                    +'<div class="rssaction">'
                        +'<span class="rsslink"><a href="javascript:void(0);" onclick="shortlinklong(this);" class="linkshort active">http://</a><input type="text" value="'+source.url+'" class="linklong"></span>'
                        +'<span class="rssallcategory"><span class="activecategory">All Category</span><ul class="categorieslist">'+rsscategorylist+'</ul></span>'
                        +'<span class="rssactionbutton search">Search</span>'
                    +'</div>'
                +'</div>'
                +'<div class="rssheadbg"></div>';
    
        $.each(therss, function(index,elem){
            if(typeof(elem.id) !== 'undefined'){
                if(elem.tags.length>0){
                    var elemcategory = '<span class="rssactionbutton category tagslist">categories<ul class="rsstags">';
                    $.each(elem.tags,function(tagidx,tagelem){
                        elemcategory += '<li class="rsscategoryitem" id="rssitemcat_'+tagelem+'_'+elem.id+'"><a href="javascript:void(0);">'+source.getCategoryById(tagelem)+'</a></li>';
                    });
                    elemcategory += '</ul></span>';
                }
                else{
                    var elemcategory = '<span class="rssactionbutton category" id="rssitemcat_'+elem.category+'_'+elem.id+'">'+source.getCategoryById(elem.category)+'</span>';
                }
                newrss+= '<div class="rssitem" id="rssitem_'+elem.id+'">'
                            +'<div class="rsstitle">'+elem.title+'<span class="pubDate">'+elem.pubDate+'</span></div>'
                            +'<div class="hiddensortvar">'+elem.datetosort+'</div>'
                            +'<div class="rsscontent">'+elem.description+'</div>'
                            +'<div class="rssaction">'
                                +'<span class="rsslink"><a href="javascript:void(0);" onclick="shortlinklong(this);" class="linkshort active">http://</a><input type="text" value="'+elem.link+'" class="linklong"></span>'
                                + elemcategory
                                +'<span class="rssactionbutton addtodownload" id="addtodownload_'+elem.id+'"></span>'
                                +'<span class="rssactionbutton downloadnow" id="downloadnow_'+elem.id+'"></span>'
                            +'</div>'
                        +'</div>';
            }
        });
        
        newrss += '<div class="rssupdatecontainer">Older News</div>';
        newrss += '</div>';
        
        $('#rsslistcontainer').append(newrss);    
        rsslinks('rss_'+sourceid);
        rsslistwidth();
        
        
        $('#rsslistcontainer').siblings('.descriptioncontainer').addClass('hide');
        $('#rsslistcontainer').addClass('notempty');
        
        
        if($('#rsslistcontainer').children('.rsslist').length > 1){
            source.setitem(sourcelist.items[sourcelist.getSourceidx(sourceid)]);
            $('.prevrss').show();
            if(bulkdownloader.started){
                bulkdownloader.progressing();
            }
            else
                nextrss(sourceid);
        }
        else{
            source.setSource(sourceid);
        }
        $('.nextrss').hide();   
    }
    else{
        var newrss = '';
        $.each(therss, function(index,elem){
                if(elem.tags.length>0){
                    var elemcategory = '<span class="rssactionbutton category tagslist">categories<ul class="rsstags">';
                    $.each(elem.tags,function(tagidx,tagelem){
                        elemcategory += '<li class="rsscategoryitem" id="rssitemcat_'+tagelem+'_'+elem.id+'"><a href="javascript:void(0);">'+source.getCategoryById(tagelem)+'</a></li>';
                    });
                    elemcategory += '</ul></span>';
                }
                else{
                    var elemcategory = '<span class="rssactionbutton category" id="rssitemcat_'+elem.category+'_'+elem.id+'">'+source.getCategoryById(elem.category)+'</span>';
                }
                
                newrss+= '<div class="rssitem" id="rssitem_'+elem.id+'">'
                           +'<div class="rsstitle">'+elem.title+'<span class="pubDate">'+elem.pubDate+'</span></div>'
                           +'<div class="hiddensortvar">'+elem.datetosort+'</div>'
                           +'<div class="rsscontent">'+elem.description+'</div>'
                           +'<div class="rssaction">'
                               +'<span class="rsslink"><a href="javascript:void(0);" onclick="shortlinklong(this);" class="linkshort active">http://</a><input type="text" value="'+elem.link+'" class="linklong"></span>'
                               +elemcategory
                               +'<span class="rssactionbutton addtodownload" id="addtodownload_'+elem.id+'"></span>'
                               +'<span class="rssactionbutton downloadnow" id="downloadnow_'+elem.id+'"></span>'
                           +'</div>'
                       +'</div>';
        });
        newrss += '<div class="rssupdatecontainer">Older News</div>';
        $('#rss_'+sourceid).children('.rssupdatecontainer').replaceWith(newrss);
    }
}
function updaterssupdatebutton(view){
    if(view == 'rsslist'){
        if($.inArray(source.currentcategory,source.categorylimit) !== -1 || $.inArray(0,source.categorylimit) !== -1){
            $('#rss_'+source.id).children('.rssupdatecontainer').addClass('hide');
        }
        else{
            var rssupdatebutton = $('#rss_'+source.id).children('.rssupdatecontainer');
            
            if(source.currentcategory !== 0){
                $(rssupdatebutton).html('Older '+ source.getCategoryById(source.currentcategory) +' News');
            }
            else{
                $(rssupdatebutton).html('Older News');
            }
            $(rssupdatebutton).removeClass('hide');
        }
    }
    else{
        if(source.searchmode !== false){
             if(searchresult.currentsearch[source.searchmode]['resultlen'] !== false){
                 var rssupdatebutton = $('#rss_'+source.id).children('.rssupdatecontainer');
                 
                 $(rssupdatebutton).html('Older Search Result');
                 $(rssupdatebutton).removeClass('hide');
             }
             else{
                 $('#rss_'+source.id).children('.rssupdatecontainer').addClass('hide');
             }
        }
    }
}
function filterrsslist(){
    if(source.currentcategory !== 0){
        var rsscategorymap  = rsslist.rsscategorymap.getmap(source.currentcategory);
        var rssidincategory = [];
        
        $.each(rsscategorymap,function(rsslistmapidx,rsslistmapelem){
            rssidincategory[rssidincategory.length] = parseInt(rsslist.list[rsslistmapelem].id);
        });
        
        $.each($('#rss_'+source.id).children('.rssitem'),function(ritemidx,ritemelem){
            ritemid = parseInt($(ritemelem).attr('id').substr(8));
            var found = $.inArray(ritemid,rssidincategory);
            if(found == -1){
                $(ritemelem).addClass('hide');
            }
            else{
                $(ritemelem).removeClass('hide');
                rssidincategory.splice(found,1);
            }
        });
    }
    else{
        $('#rss_'+source.id).children('.rssitem').removeClass('hide');
    }
}
function rsslinks(newlist){
    $('#'+newlist).delegate('.search','click', function(event){
        event.stopPropagation();
        searchinsource(this);
    });
    
    $('#'+newlist).delegate('.addtodownload','click', function(){
        addtodownloadlist(this);
    });
    
    $('#'+newlist).delegate('.downloadnow','click', function(){
        downloadnow(this);
    });
    
    $('#'+newlist).delegate('.rssupdatecontainer','click', function(){
        if(typeof($('#rss_'+source.id).find('.rssactionbutton.searchresult').attr('class')) == 'undefined' || $('#rss_'+source.id).find('.rssactionbutton.searchresult').attr('class').indexOf('active') === -1)
            olderNews(source.id);
        else{
            olderSearch();
        }
    });
    
    $('#'+newlist).delegate('.rssallcategory','click', function(event){
        event.stopPropagation();
        if(typeof($('#rss_'+source.id).find('.rssactionbutton.searchresult').attr('class')) === 'undefined' || $('#rss_'+source.id).find('.rssactionbutton.searchresult').attr('class').indexOf('active') === -1){
            if($(this).children('.categorieslist').attr('class').indexOf('active') === -1){
                $('#rss_'+source.id).children('.rssitem').addClass('opaque');
                $(this).children('.categorieslist').addClass('active');
            }
            else{
                $('#rss_'+source.id).children('.rssitem').removeClass('opaque');
                $(this).children('.categorieslist').removeClass('active');
            }
        }
    });
    
    $('#'+newlist).delegate('.tagslist','click', function(event){
        event.stopPropagation();
        if(typeof($('#rss_'+source.id).find('.rssactionbutton.searchresult').attr('class')) === 'undefined' || $('#rss_'+source.id).find('.rssactionbutton.searchresult').attr('class').indexOf('active') === -1){
            if($(this).children('.rsstags').attr('class').indexOf('active') === -1){
                $('#rss_'+source.id).children('.rssitem').addClass('opaque');
                $(this).parent().parent().removeClass('opaque');
                $(this).children('.rsstags').addClass('active');
            }
            else{
                $('#rss_'+source.id).children('.rssitem').removeClass('opaque');
                $(this).children('.rsstags').removeClass('active');
            }
        }
    });
    
    $('#'+newlist).delegate('.rsscategoryitem','click', function(event){
        var jumpcategoryname    = $(this).children('a').html();
        var jumpcategoryid      = $(this).attr('id').substr(11);
        jumpcategoryid          = jumpcategoryid.substr(0,jumpcategoryid.indexOf('_'));
        
        source.setCategory(jumpcategoryid);
        filterrsslist();
        updaterssupdatebutton('rsslist');
        
        $('#rss_'+source.id).find('.activecategory').html(jumpcategoryname);
    });
    
    $('#'+newlist).delegate('.rsscategorylistitem','click', function(event){
        var jumpcategoryid      = $(this).children('a').attr('id').substr(9);
        var jumpcategoryname    = $(this).children('a').html();
        
        if(jumpcategoryid.indexOf('0_') !== -1){
            source.setCategory(0);
            $('#rss_'+source.id).children('.rssitem').removeClass('hide');
            $('#rss_'+source.id).find('.activecategory').html(jumpcategoryname);
            
            updaterssupdatebutton('rsslist');
        }
        else{
            source.setCategory(jumpcategoryid);
            filterrsslist();
            updaterssupdatebutton('rsslist');
            $('#rss_'+source.id).find('.activecategory').html(jumpcategoryname);
        }
    });
    
    $('#'+newlist).delegate('.category','click', function(event){
        if(typeof($(this).attr('id')) === 'undefined'){
            return;
        }
        var jumpcategoryname    = $(this).html();
        var jumpcategoryid      = $(this).attr('id').substr(11);
        jumpcategoryid          = jumpcategoryid.substr(0,jumpcategoryid.indexOf('_'));
          
        source.setCategory(jumpcategoryid);
        
        var searchbutton = $('#rss_'+source.id).find('.rssactionbutton.searchresult');
        if(typeof($(searchbutton).attr('class')) !== 'undefined' && $(searchbutton).attr('class').indexOf('active') !== -1){
            $(searchbutton).removeClass('active');
            $('#rss_'+source.id).find('.rssactionbutton.rssview').addClass('active');
            rssview();
        }
        else{                
            filterrsslist();
            updaterssupdatebutton('rsslist');
        }
    
        
        $('#rss_'+source.id).find('.activecategory').html(jumpcategoryname);
    });
}
function searchinsource(linkitem){
    var message     = '<input type="text" name="keywords, separate by comma" value="keywords, separate by comma" id="keywordssearch">'
                        +'<input type="text" class="datefield floatleft" name="date start" value="date start" id="datefromsearch">'
                        +'<input type="text" class="datefield floatright" name="date end" value="date end" id="dateendsearch">'
                        +'<span class="validationmsg"><span>';
    var submitopt   = '<span class="fiftycent"><a href="javascript:void(0);" class="button left" onclick="closemessage();">Cancel</a></span><span class="fiftycent"><a class="button right" id="submitsearch">Search</a></span>';
    var title       = 'Search '+source.name;
    
    displaymessage(title,message,submitopt);
    $('#messagepup').find('.datefield').datepicker({
		dateFormat: "yy-mm-dd",
		changeYear:false,changeMonth:false
	});
    $('#messagepup').find('.datefield').on('click',function(){
        if($(this).val() == $(this).attr('name')){
            $(this).val('');
        }
    });
    $('#messagepup').find('.datefield').on('blur',function(){
        if($(this).val() == ''){
            $(this).val($(this).attr('name'));
        }
    });

    $('#keywordssearch').on('click',function(){
        if($(this).val() == $(this).attr('name')){
            $(this).val('');
        }
    });
    $('#keywordssearch').on('blur',function(){
        if($(this).val() == ''){
            $(this).val($(this).attr('name'));
        }
    });
    
    $('#submitsearch').on('click',function(){
        messageloading();
        var keywords    = $('#keywordssearch').val()    == $('#keywordssearch').attr('name') ? 0 :$('#keywordssearch').val();
        var datestart   = $('#datefromsearch').val()    == $('#datefromsearch').attr('name') ? 0 : $('#datefromsearch').val();
        var dateend     = $('#dateendsearch').val()     == $('#dateendsearch').attr('name') ? 0 : $('#dateendsearch').val();
        var searchby    = 'searchNews';
        
        if(keywords == 0){
            if(datestart == 0 && dateend ==0){
                $('#messagepup').find('.validationmsg').html('undefined search criteria');
                messageloading();
                return;
            }
            searchby = 'searchNewsByDate';
        }
        else{
            if(datestart == 0 && dateend == 0){
                searchby = 'searchByKey';
            }
        }
        
        var start = 0;
        var excludingcat = [];
        var excludingcatcount = [];
        var excludingcatoldest = [];
        
        $.each(source.excludeinolder,function(six,selem){
            excludingcat[excludingcat.length]               = selem['category'];
            excludingcatcount[excludingcatcount.length]     = selem['count'];
            excludingcatoldest[excludingcatoldest.length]   = selem['oldestid'];
        });
        
        $.ajax({
            url:'./',
            data:{app:appname,p:'ajax',a:searchby,d:{userid:userdata.userid,sourceid:source.id,start:start,excludecat:excludingcat,excludecatcount:excludingcatcount,excludeoldestid:excludingcatoldest,oldestid:source.oldestid,keywords:keywords,startdate:datestart,enddate:dateend}},
            type:'POST'
        }).done(function(msg){
            var result = $.parseJSON(msg);
            userdata.setuserid(msg.userid);
            if(result.searchresult.length > 0){
                closemessage();
                
                if(result.excluding.length){
                    source.excludeinolder = [];
                    $.each(result.excluding, function(eix,eelem){
                        if(eelem['count'] > 0){
                            var excludeidx = source.excludeinolder.length;
                            source.excludeinolder[excludeidx] = [];
                            source.excludeinolder[excludeidx]['category']   = eelem['category'];
                            source.excludeinolder[excludeidx]['count']      = eelem['count'];
                            source.excludeinolder[excludeidx]['oldestid']   = eelem['oldestid'];
                        }
                    });
                }
                
                if(result.limit){
                    searchresult.setcurrent(keywords,datestart,dateend,false);
                }
                else{
                    searchresult.setcurrent(keywords,datestart,dateend,0);
                }
                
                displaysearchresult(result.searchresult,result.keywithid,result.limit);
            }
            else{
                $('#messagepup').find('.validationmsg').html('empty search result');
            }
            messageloading();
        });
    });
}
function displaysearchresult(rss,keywords,limit){
    displayloading('rsscontainer');
    if(keywords.length>0){
        $.each(keywords,function(kidx,kelem){
            searchresult.addkey(kelem[0],kelem[1]);
        });
    }
    
    $('#rss_'+source.id).children('.rssitem').addClass('hide');
    $('#rss_'+source.id).children('.rssitem.searchresult').removeClass('hide');
    
    var newrss = '';
    $.each(rss,function(idx,elem){
         var skip = false;
         rsslistitem.reset();
         if(searchresult.items.length && source.searchmode !== false){
             rsslist.getrssbysourceandid(source.id,elem.id);
             if(rsslistitem.id === 0){
                 rsslistitem.setData(elem.id,elem.category,elem.tags,elem.description,elem.newssource,elem.title,elem.pubDate,elem.creator,elem.link,elem.downloadcount,elem.datetosort);
                 rsslist.addrssitem(rsslistitem);   
             }
             else{
                skip = true;
                rss.splice(idx,1,[]);
             }
         }
         else{
             rsslistitem.setData(elem.id,elem.category,elem.tags,elem.description,elem.newssource,elem.title,elem.pubDate,elem.creator,elem.link,elem.downloadcount,elem.datetosort);
             rsslist.addrssitem(rsslistitem); 
         }
         
        if(!skip){
            searchresult.addresult(elem);
            
            if(elem.tags.length > 0){
                var elemcategory = '<span class="rssactionbutton category tagslist">categories<ul class="rsstags">';
                $.each(elem.tags,function(tagidx,tagelem){
                    elemcategory += '<li class="rsscategoryitem" id="rssitemcat_'+tagelem+'_'+elem.id+'"><a href="javascript:void(0);">'+source.getCategoryById(tagelem)+'</a></li>';
                });
                elemcategory += '</ul></span>';
            }
            else{
                var elemcategory = '<span class="rssactionbutton category" id="rssitemcat_'+elem.category+'_'+elem.id+'">'+source.getCategoryById(elem.category)+'</span>';
            }
            
            newrss+= '<div class="rssitem searchresult" id="rssitem_'+elem.id+'">'
                        +'<div class="rsstitle">'+elem.title+'<span class="pubDate">'+elem.pubDate+'</span></div>'
                        +'<div class="rsscontent">'+elem.description+'</div>'
                        +'<div class="rssaction">'
                            +'<span class="rsslink"><a href="javascript:void(0);" onclick="shortlinklong(this);" class="linkshort active">http://</a><input type="text" value="'+elem.link+'" class="linklong"></span>'
                            + elemcategory
                            +'<span class="rssactionbutton addtodownload" id="addtodownload_'+elem.id+'"></span>'
                            +'<span class="rssactionbutton downloadnow" id="downloadnow_'+elem.id+'"></span>'
                        +'</div>'
                    +'</div>';     
        }
    });
    
    if(limit)
        newrss += '<div class="rssupdatecontainer hide">Older Search Result</div>';
    else
        newrss += '<div class="rssupdatecontainer">Older Search Result</div>';
        
    $('#rss_'+source.id).children('.rssupdatecontainer').replaceWith(newrss);
    
    var rsssearchbutton = $('#rss_'+source.id).find('.rssactionbutton.search');
    if(typeof($(rsssearchbutton).next().attr('class')) == 'undefined' || $(rsssearchbutton).next().attr('class').indexOf('rssactionbutton') === -1 ){
        $(rsssearchbutton).after('<span class="rssactionbutton searchandrssview searchresult active"></span><span class="searchandrssview rssactionbutton rssview"></span>');
        searchandrssview();
    }
    
    $('#rss_'+source.id).find('.activecategory').html(searchresult.activekeywords(source.searchmode));
    
    hideloading('rsscontainer');
}
function searchresultview(){
      $('#rss_'+source.id).find('.activecategory').html(searchresult.activekeywords(source.searchmode));
      
      $('#rss_'+source.id).children('.rssitem').addClass('hide');
      $('#rss_'+source.id).children('.rssitem.searchresult').removeClass('hide');     
      
      updaterssupdatebutton('searchresult');
}
function rssview(){
    $('#rss_'+source.id).find('.activecategory').html(source.getCategoryById(source.currentcategory));
    
    filterrsslist();
    updaterssupdatebutton('rsslist');
}
function searchandrssview(){
    $('#rss_'+source.id).find('.rssactionbutton.searchresult').on('click',function(event){
        event.stopPropagation();
        
        if($(this).attr('class').indexOf('active') === -1){
            $('#rss_'+source.id).find('.searchandrssview').removeClass('active');
            $(this).addClass('active');
            searchresultview();
        }
    });
    
    $('#rss_'+source.id).find('.rssactionbutton.rssview').on('click',function(event){
        event.stopPropagation();
        
        if($(this).attr('class').indexOf('active') === -1){
            $('#rss_'+source.id).find('.searchandrssview').removeClass('active');
            $(this).addClass('active');
            rssview();
        }
    });
}
function addtodownloadlist(linkitem){
    if($(linkitem).attr('class').indexOf('disabled') !== -1)
        return;
    
    var rssid = parseInt($(linkitem).attr('id').split('_')[1]);
    $(linkitem).addClass('disabled');
    
    if(bulkdownloader.started){
        downloadlist.addtobulk(linkitem);
        return;
    }
        bulkdownloader.checkbuttons();
        rsslistitem.reset();
        rsslist.getrssbysourceandid(source.id,rssid);
    
        downloadlist.addnew();
        $('#downloadlistbox').find('.actionsub').removeClass('active');
        $('#downloadlistbox').find('.rssactionbutton').removeClass('active');
        $('#downloadingpdf').children('.actionsubcontent').html('');
        downloadlist.refreshlist();
        
        $('#paneltext').html(downloadlist.items.length);
        $('.panelbutton').children('.table').eq(0).addClass('active');
    
}
var downloadnowqueue = [];
var downloadnowprocessing = false;
function downloadnow(linkitem){
    var rssid;
    
    if(linkitem === false){
        rssid = downloadnowqueue[0];
        if(parseInt(rssid) < 0){
            rssid = (0-parseInt(rssid));
            getRss(false);
            return;
        }
        linkitem = $('#downloadnow_'+rssid);
    }
    else{
        if($(linkitem).attr('class').indexOf('downloaded') !== -1 || $(linkitem).attr('class').indexOf('downloading') !== -1)
           return;
           
        $('#menurss').addClass('processing');
           
        $('#'+$(linkitem).attr('id')).addClass('downloading');
        rssid = parseInt($(linkitem).attr('id').substr(12));
        if(downloadnowprocessing){
            downloadnowqueue[downloadnowqueue.length] = rssid;
            return;
        }   
    }
    downloadnowprocessing = true;
    
    $('#downloadingdownloadedaspdf').removeClass('active');
    $('#downloadingdownloadedaspdf').children('.actionsubcontent').html('processing...');
    
    rsslistitem.reset();
    rsslist.getrssbysourceandid(parseInt($('#rssitem_'+rssid).parent().attr('id').split('_')[1]),rssid);
    $.ajax({
        url:'./',
        data:{app:appname,p:'ajax',a:'downloadNow',d:{rssid:rssid,downloadid:downloaded.downloadid,userid:userdata.userid}},
        type:'POST'
    }).done(function(msg){
        msg = $.parseJSON(msg);
        userdata.setuserid(msg.userid);
        
        var nightmode = '';
        if($('#nightmode').attr('class').indexOf('active') !== -1){
            nightmode = ' nightmode';
        }
        
        $('#downloadedcontainer').find('.descriptioncontainer').addClass('hide');
        var newdownload = '<div class="articlepage'+nightmode+'" id="articlepage_'+ rssid +'">'
        +'<div class="articletitle">'+rsslistitem.title+'</div>'
        +'<div class="articledate">'+rsslistitem.pubDate+' By '+ rsslistitem.creator +'</div>'
        +'<div class="articlecategory"><span class="articlelabel">Category</span><span class="colon">:</span><span class="articleattr">'+source.getCategoryById(rsslistitem.category)+'</span></div>'
        +'<div class="articlepublisher"><span class="articlelabel">Publisher</span><span class="colon">:</span><span class="articleattr">'+sourcelist.sourcename(rsslistitem.source)+'</span></div>'
        +'<div class="articlecontent">'+msg.content+'</div>'
        +'</div>';
            
        downloaded.articles[downloaded.articles.length] = newdownload;
        downloaded.rssids[downloaded.rssids.length]     = rssid;
        downloaded.downloadid                           = msg.downloadid;
        
        $('#articlelistcontainer').append(newdownload);
        $('#articlepage_'+rssid).find('a').addClass('leavingpage').prop('target','_blank');
        $('#articlepage_'+rssid).find('img').addClass('newsart').prop('srcset','');
        $('#'+$(linkitem).attr('id')).removeClass('downloading');
        $('#'+$(linkitem).attr('id')).addClass('downloaded');
        
        $('#downloadcount').html('('+ downloaded.articles.length +')');
        $('#princewoordphone').removeClass('unoccupied');
        downloadnowprocessing = false;
        
        if(downloadnowqueue.length){
            currentpaper.save($('#articlelistcontainer').html());   
            var inqueue = downloadnowqueue.indexOf(rssid);
            if(inqueue !== -1){
                downloadnowqueue.splice(inqueue,1);
            }
            if(downloadnowqueue.length){
                downloadnow(false);   
            }
            else{
                $('#menurss').removeClass('processing');
            }
        }
        else{
            currentpaper.save($('#articlelistcontainer').html());
            $('#menurss').removeClass('processing');
        }
    });
}
function rsslistwidth(){
    var containerwidth = $('#pbody').width();
    var containerchild = $('#rsslistcontainer').children('.rsslist');
    $('#rsslistcontainer').css('width',((containerchild.length+1) * containerwidth)+'px');
    $('#rsslistcontainer').children('.rsslist').css('width',containerwidth+'px');
}
function miscpage(){
    $('.miscaccordmenu').on('click',function(){
        if($(this).parent().attr('class').indexOf('active') === -1 ){
            $(this).parent().addClass('active');
            $(this).parent().siblings().removeClass('active');
        }
    });
    
    $('#statselect').on('change',function(){
       statchart(this.value,false); 
    });
    
    $('#submitperiodchart').on('click',function(){
        statchart($('#statselect').val(),true);
    });
    
    
    $('#statisticperiodsett').find('.datefield').datepicker({
		dateFormat: "yy-mm-dd",
		changeYear:false,changeMonth:true
	});
    
    $('.statperiodinput').on('click',function(){
        if($(this).val() == $(this).attr('name')){
            $(this).val('');
        }
    });
    
    $('.statperiodinput').on('blur',function(){
        if($(this).val() == ''){
            $(this).val($(this).attr('name'));
        }
    });
    
    $('.newsletteremail').on('click',function(){
        if($(this).val() == $(this).attr('name')){
            $(this).val('');
        }
    });
    
    $('.newsletteremail').on('blur',function(){
        if($(this).val() == ''){
            $(this).val($(this).attr('name'));
        }
    });
    
    $('#settingscontainer').delegate('.newslettersourcekeywords','click',function(){
        if($(this).val() == $(this).attr('name')){
            $(this).val('');
        }
        
        $(this).on('blur',function(){
            if($(this).val() == ''){
                $(this).val($(this).attr('name'));
            }
        });
    });
    
    $('#settingscontainer').delegate('.newsletteraddsources','click',function(event){
        event.stopPropagation();
        var newslettersourcesett = '<div class="row newestnewslettersource">'
                                        +'<select class="newslettersource"></select>'
                                        +'<select class="newslettersourcecategory" name="source category"><option value="0">All Category</option></select>'
                                        +'<input type="text" class="newslettersourcekeywords" name="keywords, separate by comma" value="keywords, separate by comma">'
                                        +'<input type="button" class="newsletteraddsources" value="+">'
                                        +'<input type="button" class="newsletterremsources" value="-">'
                                    +'</div>';
        
        
        $(this).parent().after(newslettersourcesett);
        var sourceoptions = $('.newestnewslettersource').prev().children('.newslettersource').html();
        $('.newestnewslettersource').children('.newslettersource').html(sourceoptions);
        $('.newestnewslettersource').removeClass('newestnewslettersource');
    });
    
    $('#settingscontainer').delegate('.newsletterremsources','click',function(event){
        event.stopPropagation();
        var sourcecount = $(this).parent().parent().find('.newslettersourcekeywords').length;
        if(sourcecount > 1){
            $(this).parent().remove();
        }
        else{
            $(this).parent().children('.newslettersource').val(0);
            $(this).parent().children('.newslettersourcecategory').val(0);
            $(this).parent().children('.newslettersourcekeywords').val($(this).parent().children('.newslettersourcekeywords').attr('name'));
        }
    });
    
    $('#settingscontainer').delegate('.newslettersource','change',function(){
        $(this).siblings('.newslettersourcecategory').replaceWith('<div class="newslettersourcecatloading"></div>');
        var sourceid            = $(this).val();
        var selectedsource      = sourcelist.getSourceidx(sourceid);
        var selectedsourcecat   = this;
        
        if(selectedsource === false){
            $.ajax({
                url:'./',
                data:{app:appname,p:'ajax',a:'getSourceWithCat',d:{sourceid:sourceid}},
                type:'POST'
            }).done(function(msg){
                var sourcewithcat = $.parseJSON(msg);
                var sourceidx = sourcelist.addSource(sourcewithcat);
                
                var categories = '<select class="newslettersourcecategory"><option value="0">All Category</option>';
                if(sourcewithcat.categories.length){
                    $.each(sourcewithcat.categories,function(catidx,catelem){
                       categories += '<option value="'+catelem.id+'">'+catelem.name+'</option>';
                    });   
                }
                categories += '</select>';
                $(selectedsourcecat).siblings('.newslettersourcecatloading').replaceWith(categories);
            });
        }
        else{
            var categories = '<select class="newslettersourcecategory"><option value="0">All Category</option>';
            $.each(sourcelist.items[selectedsource].categories,function(catidx,catelem){
                categories += '<option value="'+catelem.id+'">'+catelem.name+'</option>';
            });
            categories += '</select>';
            $(selectedsourcecat).siblings('.newslettersourcecatloading').replaceWith(categories);
        }
    });
        
    $('.submitnewsletterreq').on('click',function(){
        var email                 = $(this).parent().find('.newsletteremail').eq(0).val();
        
        if(email !== 'email'){
            $(this).parent().find('.newsletteremail').eq(0).parent().siblings('.message').eq(0).addClass('hidden');
            $(this).addClass('loading');
            
            var sources_input         = $(this).parent().find('.newslettersource');
            var sourcescategory_input = $(this).parent().find('.newslettersourcecategory');
            var sourceskey_input      = $(this).parent().find('.newslettersourcekeywords');
            
            var sources = [];
            var sourcescategory = [];
            var sourceskey = [];
            
            $.each(sources_input,function(index,elem){
                if($(elem).val() != 0){
                    sources[sources.length] = $(elem).val();
                    sourcescategory[sourcescategory.length] = $(sourcescategory_input[index]).val();
                    sourceskey[sourceskey.length] = $(sourceskey_input[index]).val() == $(sourceskey_input[index]).attr('name') ? '' : $(sourceskey_input[index]).val();   
                }
            });
            
            if(sources.length){
                $.ajax({
                    url:'./',
                    data:{app:appname,p:'ajax',a:'submitNewsletter',d:{userid:userdata.userid,email:email,sources:sources,sourcescategory:sourcescategory,sourceskey:sourceskey}},
                    type:'POST'
                }).done(function(msg){
                    $('.emailerror').addClass('hidden');
                    
                    $('.submitnewsletterreq').removeClass('loading');
                    var message = $('.emailerror');
                    $(message).html('Subscription for <b>'+email+'</b> was successfully added');
                    $(message).removeClass('hidden');
                    $(message).addClass('successnotif');
                });
            }
            else{
                $('.submitnewsletterreq').removeClass('loading');
                $('.newssourceerror').removeClass('hidden');
            }
        }
        else{
            var message = $('.emailerror');
            $(message).html('Email should not be empty');
            $(message).removeClass('hidden');
        }
    });
    
    $('.loadnewslettersettings').on('click',function(){
        $('.submitnewsletterreq').removeClass('submitted');
        var email                 = $(this).parent().find('.newsletteremail').eq(0).val();
        
        if(email !== 'email'){
            $(this).parent().find('.newsletteremail').eq(0).parent().siblings('.message').eq(0).addClass('hidden');
            $(this).addClass('loading');
            $.ajax({
                url:'./',
                data:{app:appname,p:'ajax',a:'loadNewsletter',d:{email:email}},
                type:'POST'
            }).done(function(msg){
                msg = $.parseJSON(msg);
                if(msg.newsletter){
                    var formcount = $('.loadnewslettersettings').parent().parent().find('.newslettersource').length-1;
                    
                    var sourcesetting = (msg.settings);
                    $.each(sourcesetting, function(settingidx,settingval){
                        $.each(settingval,function(settingvalidx,settingvalval){
                            if(formcount > -1){
                                $('.loadnewslettersettings').parent().parent().find('.newslettersource').eq(formcount).val(settingvalval.source);
                                        
                                var selectedsource      = sourcelist.getSourceidx(settingvalval.source);                        
                                if(selectedsource === false){
                                    var formidx = formcount;
                                    $.ajax({
                                        url:'./',
                                        data:{app:appname,p:'ajax',a:'getSourceWithCat',d:{sourceid:settingvalval.source}},
                                        type:'POST'
                                    }).done(function(msg){
                                        var sourcewithcat   = $.parseJSON(msg);
                                        var sourceidx       = sourcelist.addSource(sourcewithcat);
                                        
                                        var categories = '<select class="newslettersourcecategory"><option value="0">All Category</option>';
                                        if(sourcewithcat.categories.length){
                                            $.each(sourcewithcat.categories,function(catidx,catelem){
                                               categories += '<option value="'+catelem.id+'">'+catelem.name+'</option>';
                                            });   
                                        }
                                        categories += '</select>';
                                        $('.loadnewslettersettings').parent().parent().find('.newslettersourcecategory').eq(formidx).replaceWith(categories);
                                        $('.loadnewslettersettings').parent().parent().find('.newslettersourcecategory').eq(formidx).val(settingvalval.category);
                                    });
                                }
                                else{
                                    var categories = '<select class="newslettersourcecategory"><option value="0">All Category</option>';
                                    $.each(sourcelist.items[selectedsource].categories,function(catidx,catelem){
                                        categories += '<option value="'+catelem.id+'">'+catelem.name+'</option>';
                                    });
                                    categories += '</select>';
                                    $('.loadnewslettersettings').parent().parent().find('.newslettersourcecategory').eq(formcount).replaceWith(categories);
                                    $('.loadnewslettersettings').parent().parent().find('.newslettersourcecategory').eq(formcount).val(settingvalval.category);
                                }
                                if(settingvalval.keywords != ''){
                                    $('.loadnewslettersettings').parent().parent().find('.newslettersourcekeywords').eq(formcount).val(settingvalval.keywords);
                                }
                                formcount -= 1;
                            }
                            else{
                                var newform = '<div class="row newestnewslettersource">'
                                                    +'<select class="newslettersource"></select>'
                                                    +'<select class="newslettersourcecategory" name="source category"><option value="0">All Category</option></select>'
                                                    +'<input type="text" class="newslettersourcekeywords" name="keywords, separate by comma" value="keywords, separate by comma">'
                                                    +'<input type="button" class="newsletteraddsources" value="+">'
                                                    +'<input type="button" class="newsletterremsources" value="-">'
                                                +'</div>';
                                $('.newssourceerror').before(newform);
                                var sourceoptions = $('.newestnewslettersource').prev().children('.newslettersource').html();
                                $('.newestnewslettersource').children('.newslettersource').html(sourceoptions);
                                $('.newestnewslettersource').children('.newslettersource').val(settingvalval.source);
                                
                                var selectedsource      = sourcelist.getSourceidx(settingvalval.source);                        
                                if(selectedsource === false){
                                    $.ajax({
                                        url:'./',
                                        data:{app:appname,p:'ajax',a:'getSourceWithCat',d:{sourceid:settingvalval.source}},
                                        type:'POST'
                                    }).done(function(msg){
                                        var sourcewithcat   = $.parseJSON(msg);
                                        var sourceidx       = sourcelist.addSource(sourcewithcat);
                                        
                                        var categories = '<select class="newslettersourcecategory"><option value="0">All Category</option>';
                                        if(sourcewithcat.categories.length){
                                            $.each(sourcewithcat.categories,function(catidx,catelem){
                                               categories += '<option value="'+catelem.id+'">'+catelem.name+'</option>';
                                            });   
                                        }
                                        categories += '</select>';
                                        $('.newestnewslettersource').children('.newslettersourcecategory').replaceWith(categories);
                                        $('.newestnewslettersource').children('.newslettersourcecategory').val(settingvalval.category);
                                        
                                        $('.newestnewslettersource').removeClass('newestnewslettersource');
                                    });
                                }
                                else{
                                    var categories = '<select class="newslettersourcecategory"><option value="0">All Category</option>';
                                    $.each(sourcelist.items[selectedsource].categories,function(catidx,catelem){
                                        categories += '<option value="'+catelem.id+'">'+catelem.name+'</option>';
                                    });
                                    categories += '</select>';
                                    $('.newestnewslettersource').children('.newslettersourcecategory').replaceWith(categories);
                                    $('.newestnewslettersource').children('.newslettersourcecategory').val(settingvalval.category);
                                    
                                    $('.newestnewslettersource').removeClass('newestnewslettersource');
                                }
                                
                                if(settingvalval.keywords != '')
                                    $('.newestnewslettersource').children('.newslettersourcekeywords').val(settingvalval.keywords);
                                                                
                                formcount -= 1;
                            }
                        });
                    });
                    
                    $('.newssourceerror').addClass('hidden');
                    $('.emailerror').addClass('hidden');
                }
                else{
                    var message = $('.emailerror');
                    $(message).html('Subscription for <b>'+email+'</b> was not found');
                    $(message).removeClass('hidden');
                    $(message).removeClass('successnotif');
                }
                $('.loadnewslettersettings').removeClass('loading');
            });
        }
        else{
            var message = $('.emailerror');
            $(message).html('Email should not be empty');
            $(message).removeClass('successnotif');
            $(message).removeClass('hidden');
        }
    });
    
    $('.removesubscription').on('click',function(){
        $('.submitnewsletterreq').removeClass('submitted');
        var email                 = $(this).parent().find('.newsletteremail').eq(0).val();
        
        if(email !== 'email'){
            $(this).parent().find('.newsletteremail').eq(0).parent().siblings('.message').eq(0).addClass('hidden');
            $(this).addClass('loading');
            
            $.ajax({
                url:'./',
                data:{app:appname,p:'ajax',a:'removeSubscription',d:{email:email}},
                type:'POST'
            }).done(function(msg){
                msg = $.parseJSON(msg);
                var message = $('.emailerror');
                $(message).html('Subscription for <b>'+email+'</b> was successfully removed');
                $(message).addClass('successnotif');
                $(message).removeClass('hidden');
                $('.removesubscription').removeClass('loading');
            });
        }
        else{
            var message = $('.emailerror');
            $(message).html('Email should not be empty');
            $(message).removeClass('successnotif');
            $(message).removeClass('hidden');
        }
    });
}
function hidechartdivs(){
    $('.statchart').css('height','0px');
}
function chartinteractions(chartdiv){
    $(chartdiv).bind("plotclick", function (event, pos, item) {
        if (item) {
            downloadpopart(chartdiv,chartdataset[item.dataIndex]);
        }
    });
}
function downloadpopart(chartdiv,downloaditem){
    var rssid = downloaditem.id;
    $(chartdiv).addClass('loading');
    $.ajax({
        url:'./',
        data:{app:appname,p:'ajax',a:'downloadpopart',d:{rssid:rssid,downloadid:downloaded.downloadid,userid:userdata.userid}},
        type:'POST'
    }).done(function(msg){
        msg = $.parseJSON(msg);
        userdata.setuserid(msg.userid);
                
        var nightmode = '';
        if($('#nightmode').attr('class').indexOf('active') !== -1){
            nightmode = ' nightmode';
        }
                
        $('#downloadedcontainer').find('.descriptioncontainer').addClass('hide');
        var newdownload = '<div class="articlepage'+nightmode+'" id="articlepage_'+ rssid +'">'
        +'<div class="articletitle">'+msg.title+'</div>'
        +'<div class="articledate">'+msg.pubDate+' By '+ msg.creator +'</div>'
        +'<div class="articlecategory"><span class="articlelabel">Category</span><span class="colon">:</span><span class="articleattr">'+msg.categoryname+'</span></div>'
        +'<div class="articlepublisher"><span class="articlelabel">Publisher</span><span class="colon">:</span><span class="articleattr">'+msg.name+'</span></div>'
        +'<div class="articlecontent">'+msg.content+'</div>'
        +'</div>';
            
        downloaded.articles[downloaded.articles.length] = newdownload;
        downloaded.rssids[downloaded.rssids.length]     = rssid;
        downloaded.downloadid                           = msg.downloadid;
        
        $('#articlelistcontainer').append(newdownload);
        $('#articlepage_'+rssid).find('a').addClass('leavingpage').prop('target','_blank');
        $('#articlepage_'+rssid).find('img').addClass('newsart').prop('srcset','');
        
        $('#downloadcount').html('('+ downloaded.articles.length +')');
        $('#princewoordphone').removeClass('unoccupied');
        $(chartdiv).removeClass('loading');
        
        currentpaper.save($('#articlelistcontainer').html());
    });
}
function statchart(chartdiv,submit){
    var charttype = submit ? $('#statselect').val() : chartdiv;
    hidechartdivs();
    if(chartdiv == 0){
        return;
    }
    
    chartelem = chartdivelem(chartdiv);
    if($(chartelem).html() == '' && submit || submit){
        $(chartelem).css('height','100%');
        $(chartelem).addClass('loading');
            $.ajax({
                url:'./',
                method:'POST',
                data:{app:'nownews',p:'statistics',a:'onlinecharts',d:{type:charttype,startp:$('#statperiodoptstart').val(),endp:$('#statperiodoptend').val()}}
            }).done(function(msg){
                msg = $.parseJSON(msg);
                var data = msg.data;
                var clickable = false;
                var hoverable = false;
                var fillbar = true;
                if(charttype == 'articledownload'){
                    chartdataset = msg.dataset;
                    chartinteractions(chartelem);
                    clickable = true;
                    hoverable = true;
                    fillbar = false;
                }
                $.plot(chartelem, [ data ], {
                    shadowSize:1,
                    legend: {
                        show: true,
                        noColumns: 1, // number of colums in legend table
                        labelFormatter: null, // fn: string -> string
                        labelBoxBorderColor: "#ccc", // border color for the little label boxes
                        container: null, // container (as jQuery object) to put legend in, null means default on top of graph
                        position: "ne", // position of default legend container within plot
                        margin: 5, // distance from grid edge to default legend container within plot
                        backgroundColor: null, // null means auto-detect
                        backgroundOpacity: 0, // set to 0 to avoid background
                    },
                    grid: {
                        show: true,
                        aboveData: false,
                        color: "#dbdbdb", // primary color used for outline and labels
                        backgroundColor: null, // null for transparent, else color
                        borderColor: "#dbdbdb", // set if different from the grid color
                        tickColor: null, // color for the ticks, e.g. "rgba(0,0,0,0.15)"
                        margin: 0, // distance from the canvas edge to the grid
                        labelMargin: 5, // in pixels
                        axisMargin: 0, // in pixels
                        borderWidth: 0.4, // in pixels
                        minBorderMargin: null, // in pixels, null means taken from points radius
                        markings: null, // array of ranges or fn: axes -> array of ranges
                        markingsColor: "#f4f4f4",
                        markingsLineWidth: 1,
                        // interactive stuff
                        clickable: clickable,
                        hoverable: hoverable,
                        autoHighlight: true, // highlight in case mouse is near
                        mouseActiveRadius: 10 // how far the mouse can be away to activate an item
                    },
                    colors:["#6f82c7"],
                    series: {
                        bars: {
                            show: true,
                            barWidth: 0.6,
                            lineWidth: 1, // in pixels
                            fill: fillbar,
                            fillColor: "#7a8fdb",
                            align: "center", // "left", "right", or "center"
                            horizontal: false,
                            zero: true
                        }
                    },
                    xaxis: {
                        mode: "categories",
                        tickLength: 0
                    }
                });
                $(chartelem).removeClass('loading');
            });
    }
    else{
        $(chartelem).css('height','100%');
    }    
}
function chartdivelem(chartname){
    return $("#"+chartname+"_chart");
}

function reviewmodefn(){
    $('#articlelistcontainer').removeClass('readingmode');
    $('body').find('.opaquebg').eq(0).removeClass('readingmodeactive');
    $('#reviewmode').removeClass('active blur');
    $('#princewoordphone').removeClass('blur');
}

function clsdownloadedarticle(){
    if(downloaded.articles.length){
        downloaded.articles     = [];
        downloaded.downloadid   = 0;
        downloaded.rssids       = [];
        
        $('#articlelistcontainer').html('');
        $('#downloadcount').html('(0)');
        $('#princewoordphone').addClass('unoccupied');
        $('#downloadedcontainer').find('.descriptioncontainer').removeClass('hide');
        $('.sidebarpanel').removeClass('active');
        
        $('.rssactionbutton.downloadnow.downloaded').removeClass('downloaded');
        currentpaper.save(null);
        
        if(typeof $('#articlelistcontainer').attr('class') === 'undefined' || $('#articlelistcontainer').attr('class').indexOf('reviewmode') === -1){
            reviewmodefn();
        }
    }
    bulkdownloader.started = false;
}

var searchedwoord = [];
var currentsearchedwoordidx = -1;
function nownewspw(){
    $('#thewoord').on('click',function(){
        $(this).addClass('active');
        if($(this).val() == $(this).attr('name')){
            $(this).val('');
        }
    });
    $('#thewoord').on('blur',function(){
        $(this).removeClass('active');
        if($(this).val() == ''){
            $(this).val($(this).attr('name'));
        }
    });
    
    $('#woordnetmenu').children().on('click',function(){
        if(typeof $(this).attr('class') != 'undefined' && $(this).attr('class').indexOf('empty') !== -1)
            return;
        
        $('#woordnetmenu').children().removeClass('active');
        $(this).addClass('active');
        
       $('.pwsearchresult').removeClass('active');
       var container = this.id.substr(4);
       $('#pw_'+container).addClass('active');
    });
    
    $('#princewoordphone').on('click',function(event){
        event.stopPropagation();
        if(mobile && $('#reviewmode').attr('class').indexOf('active') !== -1 && (typeof $(this).attr('class') !== 'undefined' && $(this).attr('class').indexOf('blur') !== -1) ){
            $(this).removeClass('blur');
            setTimeout(function(){
                if(typeof $('#princewoorddictionary').attr('class') === 'undefined' || $('#princewoorddictionary').attr('class').indexOf('active') === -1){
                    if($('#reviewmode').attr('class').indexOf('active') !== -1)
                        $('#princewoordphone').addClass('blur');
                }
            },3000);
            return;
        }
        if(typeof $('#princewoorddictionary').attr('class') === 'undefined' || $('#princewoorddictionary').attr('class').indexOf('active') === -1){
            $('#princewoorddictionary').addClass('active');
            $('#thewoord').focus().val('').addClass('active');   
        }
    });
    $('#closepwdictionary').on('click',function(event){
        event.stopPropagation();
        $('#princewoorddictionary').removeClass('active');
        if($('#reviewmode').attr('class').indexOf('active') !== -1){
            if(mobile){
                setTimeout(function(){
                    if($('#reviewmode').attr('class').indexOf('active') !== -1)
                        $('#princewoordphone').addClass('blur');
                },300);      
            }
        }
    });
    
    $('.searchedwoord').on('click',function(){
       if(this.id == 'nextwoord') {
            if( searchedwoord.length>=2 && currentsearchedwoordidx<(searchedwoord.length-1) && currentsearchedwoordidx !== -1){
                currentsearchedwoordidx +=1;
                displayprincewoordresult(searchedwoord[currentsearchedwoordidx]['content']);
                $('#thewoord').val(searchedwoord[currentsearchedwoordidx]['qwoord']);
                
                if(currentsearchedwoordidx == searchedwoord.length-1)
                    $('#nextwoord').removeClass('active');
                else
                    $('#nextwoord').addClass('active');
                    
                if(currentsearchedwoordidx == 0)
                    $('#previouswoord').removeClass('active');
                else
                    $('#previouswoord').addClass('active');
                    
            }
       }
       else{
            if(currentsearchedwoordidx == -1){
                currentsearchedwoordidx = searchedwoord.length-2;
                displayprincewoordresult(searchedwoord[currentsearchedwoordidx]['content']);
                $('#thewoord').val(searchedwoord[currentsearchedwoordidx]['qwoord']);
            }
            else{
                if(currentsearchedwoordidx > 0){
                    currentsearchedwoordidx -= 1;
                    displayprincewoordresult(searchedwoord[currentsearchedwoordidx]['content']);
                    $('#thewoord').val(searchedwoord[currentsearchedwoordidx]['qwoord']);
                }
            }
            
            if(currentsearchedwoordidx == 0)
                $('#previouswoord').removeClass('active');
            else
                $('#previouswoord').addClass('active');
                
            if(currentsearchedwoordidx == searchedwoord.length-1)
                $('#nextwoord').removeClass('active');
            else
                $('#nextwoord').addClass('active');
       }
    });
    
    $('#thewoord').on('keyup',function(key){
        if(key.which !== 13)
            return;
            
        submitquerypw();
    });
    $('#querypw').on('click',function(event){
        event.stopPropagation();
       submitquerypw();
    });
    
    function searchprevsearchedwoord(qwoord){
        if(searchedwoord.length == 0){
            return false;
        }
        
        for(var idx=0;idx<searchedwoord.length;idx++){
            if(searchedwoord[idx].qwoord == qwoord){
                return idx;
            }
        }
        return false;
    }
    
    function submitquerypw(){
        var woord = $('#thewoord').val();
        if(woord !== $('#thewoord').attr('name') && woord != ''){
            var searchedalready= searchprevsearchedwoord(woord);
            if(searchedalready !== false){
                currentsearchedwoordidx = searchedalready;
                displayprincewoordresult(searchedwoord[currentsearchedwoordidx]['content']);
                if(currentsearchedwoordidx == 0)
                    $('#previouswoord').removeClass('active');
                else
                    $('#previouswoord').addClass('active');
                    
                if(currentsearchedwoordidx == searchedwoord.length-1)
                    $('#nextwoord').removeClass('active');
                else
                    $('#nextwoord').addClass('active');
                
                return;
            }
            $('#querypw').addClass('loading');
            $('#princewoordphone').addClass('loading');
            
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:'princewoord',p:'ajax',a:'querywoord',d:{woord:woord}}
            }).done(function(msg){
                msg = $.parseJSON(msg);
                if(msg.error || msg.response.length == 0){
                    $('#pw_message').html(msg.message);
                    $('#pw_message').addClass('active'); 
                }
                else{
                    $('#pw_message').removeClass('active');
                    
                    var searchedwoordidx = searchedwoord.length;
                    searchedwoord[searchedwoordidx] = [];
                    searchedwoord[searchedwoordidx]['content'] = msg.response;
                    searchedwoord[searchedwoordidx]['qwoord'] = woord;
                    
                    if(searchedwoord.length > 1){
                        $('#previouswoord').addClass('active');
                    }
                    currentsearchedwoordidx = (searchedwoord.length-1);
                    
                    displayprincewoordresult(msg.response);
                    $('#nextwoord').removeClass('active');
                    
            
                }
                
                $('#querypw').removeClass('loading');
                $('#princewoordphone').removeClass('loading');
                
            });   
        }
    }
}

function displayprincewoordresult(response){
    $('#woordnetmenu li').removeClass('empty');
    $('#pw_message').removeClass('active');
    var definition = '<ol>';
    
    var alsosee = '<ol>';
    var emptyalsosee = true;
    
    var similar = '<ol>';
    var emptysimilar = true;
    
    var derived = '<ol>';
    var emptyderived = true;
    
    var holonym = '<ol>';
    var emptyholonym = true;
    
    var meronym = '<ol>';
    var emptymeronym = true;
    
    var attribute = '<ol>';
    var emptyattribute = true;
    
    var hypernym = '<ol>';
    var emptyhypernym = true;
    
    var hyponym = '<ol>';
    var emptyhyponym = true;
    
    $.each(response,function(woordix,woordval){
            definition += '<li><b>'+woordval.woord+'.</b> '+'('+woordval.type+') '+woordval.definition+'</li>';
            
            if(typeof(woordval.alsosee) != 'undefined'){
                var alsoseeinner = '<li><ul>';
                
                $.each(woordval.alsosee,function(alsoidx,alsoval){
                    if(typeof(alsoval.woord) !== 'undefined'){
                        alsoseeinner += '<li><b>'+alsoval.woord+'.</b> '+'('+alsoval.type+') '+alsoval.definition+'</li>';
                        emptyalsosee = false;
                    }
                });
                alsoseeinner += '</ul></li>';
                
                if(alsoseeinner != '<li><ul></ul></li>'){
                    alsosee += alsoseeinner;
                }
                else{
                    alsosee += '<li><ul>-</ul></li>';
                }
            }

            
            
            if(typeof(woordval.similar) != 'undefined'){
                var similarinner = '<li><ul>';
                $.each(woordval.similar,function(similaridx,similarval){
                    if(typeof(similarval.woord) !== 'undefined'){
                        similarinner += '<li><b>'+similarval.woord+'.</b> '+'('+similarval.type+') '+similarval.definition+'</li>';
                        emptysimilar = false;
                    }
                });    
                similarinner += '</ul></li>';
                
                if(similarinner != '<li><ul></ul></li>')
                    similar += similarinner;   
                else{
                    similar += '<li><ul>-</ul></li>';
                }
            }

                                      
                                      
            if(typeof(woordval.derived) != 'undefined'){
                var derivedinner = '<li><ul>';
                $.each(woordval.derived,function(derivedidx,derivedval){
                    if(typeof(derivedval.woord) !== 'undefined'){
                        derivedinner += '<li><b>'+derivedval.woord+'.</b> '+'('+derivedval.type+') '+derivedval.definition+'</li>';
                        emptyderived = false;
                    }
                });
                derivedinner += '</ul></li>';
                
                if(derivedinner != '<li><ul></ul></li>')
                    derived += derivedinner;
                else{
                    derived += '<li><ul>-</ul></li>';
                }
            }

                       
            var holonyminner = '<li><ul>';                
            if(typeof(woordval.holonymcomponentof) != 'undefined'){
                $.each(woordval.holonymcomponentof,function(holonymidx,holonymval){
                    if(typeof(holonymval.woord) !== 'undefined'){
                        holonyminner += '<li><b>'+holonymval.woord+'.</b>'+'('+holonymval.type+') '+holonymval.definition+'</li>';
                        emptyholonym = false;
                    }
                });
            }
            if(typeof(woordval.holonymmemberof) != 'undefined'){
                $.each(woordval.holonymmemberof,function(holonymidx,holonymval){
                    if(typeof(holonymval.woord) !== 'undefined'){
                        holonyminner += '<li><b>'+holonymval.woord+'.</b>'+'('+holonymval.type+') '+holonymval.definition+'</li>';
                        emptyholonym = false;
                    }
                });
            }
            if(typeof(woordval.holonymtobuild) != 'undefined'){
                $.each(woordval.holonymtobuild,function(holonymidx,holonymval){
                    if(typeof(holonymval.woord) !== 'undefined'){
                        holonyminner += '<li><b>'+holonymval.woord+'.</b>'+'('+holonymval.type+') '+holonymval.definition+'</li>';
                        emptyholonym = false;
                    }
                });
            }
            holonyminner += '</ul></li>';
            
            if(holonyminner != '<li><ul></ul></li>')
                holonym += holonyminner;
            else{
                holonym += '<li><ul>-</ul></li>';
            }
            
            
            var meronyminner = '<li><ul>';
            if(typeof(woordval.meronymcomponentof) != 'undefined'){
                $.each(woordval.meronymcomponentof,function(meronymidx,meronymval){
                    if(typeof(meronymval.woord) !== 'undefined'){
                        meronyminner += '<li><b>'+meronymval.woord+'.</b>'+'('+meronymval.type+') '+meronymval.definition+'</li>';
                        emptymeronym = false;
                    }
                });
            }
            if(typeof(woordval.meronymmemberof) != 'undefined'){
                $.each(woordval.meronymmemberof,function(meronymidx,meronymval){
                    if(typeof(meronymval.woord) !== 'undefined'){
                        meronyminner += '<li><b>'+meronymval.woord+'.</b>'+'('+meronymval.type+') '+meronymval.definition+'</li>';
                        emptymeronym = false;
                    }
                });
            }
            if(typeof(woordval.meronymtobuild) != 'undefined'){
                $.each(woordval.meronymtobuild,function(meronymidx,meronymval){
                    if(typeof(meronymval.woord) !== 'undefined'){
                        meronyminner += '<li><b>'+meronymval.woord+'.</b>'+'('+meronymval.type+') '+meronymval.definition+'</li>';
                        emptymeronym = false;
                    }
                });
            }
            
            if(meronyminner != '<li><ul>'){
                meronym += meronyminner;
                meronym += '</ul></li>';
            }
            else{
                meronym += '<li><ul>-</ul></li>';
            }
            
            if(typeof(woordval.attribute) != 'undefined'){
                var attributeinner = '<li><ul>';
                $.each(woordval.attribute,function(attributeidx,attributeval){
                    if(typeof(attributeval.woord) !== 'undefined'){
                        attributeinner += '<li>'+attributeval.woord+'</li>';
                        emptyattribute = false;
                    }
                });
                attributeinner += '</ul></li>';
                
                if(attributeinner != '<li><ul></ul></li>')
                    attribute += attributeinner;
                else{
                    attribute += '<li><ul>-</ul></li>';
                }
            }
            
             if(typeof(woordval.hypernym) != 'undefined'){
                var hypernyminner = '<li><ul>';
                $.each(woordval.hypernym,function(attributeidx,hypernymval){
                    if(typeof(hypernymval.woord) !== 'undefined'){
                        hypernyminner += '<li><b>'+hypernymval.woord+'.</b>'+'('+hypernymval.type+') '+hypernymval.definition+'</li>';
                        emptyhypernym = false;
                    }
                });
                hypernyminner += '</ul></li>';
                
                if(hypernyminner != '<li><ul></ul></li>')
                    hypernym += hypernyminner;
                else{
                    hypernym += '<li><ul>-</ul></li>';
                }
            }
        
            if(typeof(woordval.hyponym) != 'undefined'){
                var hyponyminner = '<li><ul>';
                $.each(woordval.hyponym,function(hyponymidx,hyponymval){
                    if(typeof(hyponymval.woord) !== 'undefined'){
                        hyponyminner += '<li>'+hyponymval.woord+'</li>';
                        emptyhyponym = false;
                    }
                });
                hyponyminner += '</ul></li>';
                
                if(hyponyminner != '<li><ul></ul></li>')
                    hyponym += hyponyminner;
                else{
                    hyponym += '<li><ul>-</ul></li>';
                }
            }
    });
    
    definition += '</ol>';
    alsosee += '</ol>';
    similar += '</ol>';
    derived += '</ol>';
    holonym += '</ol>';
    meronym += '</ol>';
    attribute += '</ol>';
    hypernym += '</ol>';
    hyponym += '</ol>';
    
    if(emptyalsosee){
        $('#wnm_alsosee').addClass('empty');
    }
    if(emptysimilar){
        $('#wnm_similar').addClass('empty');
    }
    if(emptyderived){
        $('#wnm_derived').addClass('empty');
    }
    if(emptyholonym){
        $('#wnm_holonym').addClass('empty');
    }
    if(emptymeronym){
        $('#wnm_meronym').addClass('empty');
    }
    if(emptyattribute){
        $('#wnm_attribute').addClass('empty');
    }
    if(emptyhypernym){
        $('#wnm_hypernym').addClass('empty');
    }
    if(emptyhyponym){
        $('#wnm_hyponym').addClass('empty');
    }
    
    $('#pw_definition').html(definition);
    $('#pw_alsosee').html(alsosee);
    $('#pw_similar').html(similar);
    $('#pw_derived').html(derived);
    $('#pw_holonym').html(holonym);
    $('#pw_meronym').html(meronym);
    $('#pw_attribute').html(attribute);
    $('#pw_hypernym').html(hypernym);
    $('#pw_hyponym').html(hyponym);
}