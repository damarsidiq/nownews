<div class="sidebarpanel">
     <div class="panelbutton">
         <div class="table active panelmenu" id="pbmenurss"><div id="paneltext" class="tablecell">0</div></div>
         <div class="panelmenu" id="pbmenudownloaded">≡</div>
     </div>
     <div class="panelcontent">
          <div class="toolbox toolboxrss" id="downloadlistbox">
             <h3>Download List</h3>
             <?php $velp->printlist('','downloadlist','') ?>
             <div class="actionbutton">
               <span class="rssactionbutton" id="clsdownloadlist">Clear</span>
               <span class="rssactionseparator"></span>
               <span class="rssactionbutton" id="sortdownloadlist">Sort<ul id="downloadopt" class="actionsub">
                     <li class="downloadoptitem" id="downloadopt_title">Title</li>
                     <li class="downloadoptitem" id="downloadopt_source">News Source</li>
                     <li class="downloadoptitem" id="downloadopt_pubDate">pubDate</li>
                  </ul>
               </span>
               <span class="rssactionseparator"></span>
               <span class="rssactionbutton" id="downloaddownloadlist">Download<div id="downloadingnow" class="actionsub"><span class="dismissballoon"></span><div class="actionsubcontent"></div></div></span>
               <span class="rssactionseparator"></span>
               <span class="rssactionbutton" id="pdfdownloadlist">PDF<div id="downloadingpdf" class="actionsub"><span class="dismissballoon"></span><div class="actionsubcontent"></div></div></span>
             </div>
          </div>
          <div class="toolbox toolboxdownloaded" id="downloadedmenu">
               <div id="downloaddownloadedaspdf" class="downloadedactions">Download as PDF<div id="downloadingdownloadedaspdf" class="actionsub"><span class="dismissballoon"></span><div class="actionsubcontent"></div></div></div>
               
               <div class="toolboxmenuseparator"></div>
               
               <div id="cleardownloadedarticle" class="downloadedactions">Clear Reader</div>
               
               <div class="toolboxmenuseparator"></div>
                              
               <div class="downloadedviewmode">
                  <div id="readingmode" class="downloadedactions">Reading Mode(R)</div>
               </div>
               
               <div class="toolboxmenuseparator"></div>
               
               <div class="readingnightandday">
                  <div id="nightmode" class="downloadedactions">Night(N)</div>
               </div>
               
               <div class="readingnightandday">
                  <div id="daymode" class="downloadedactions active">Day(D)</div>
               </div>

               <div class="toolboxmenuseparator"></div>
               
               
          </div>
     </div>
</div>
<div id="rsscontainer" class="contentcontainer active">
   <div class="loadingnotifcontainer"><div class="loading"></div></div>
   <div class="opaquebg"></div>
   
   <div class="prevrss"><span>&lt;</span></div>
   <div class="nextrss"><span>&gt;</span></div>
   
   <div class="content">
        <div class="descriptioncontainer table">
            <div class="descriptiontext tablecell">
                <h3>Please select one or more news source available below</h3>
            </div>
        </div>
        <div id="rsslistcontainer"></div>
   </div>
 </div>
 
 <div id="downloadedcontainer" class="contentcontainer">
   <div class="loadingnotifcontainer"><div class="loading"></div></div>
   <div class="opaquebg"></div>
   <div id="reviewmode" class="downloadedactions">Review Mode(V)</div>
   <div class="content">
      <div class="descriptioncontainer table">
            <div class="descriptiontext tablecell">
                <h3>Please select one or more items from the rss page to download</h3>
            </div>
      </div>
      <div id="articlelistcontainer">
          <?php 
          
          
          if(isset($pagevar['content'])){
              include_once('newscontent.php');
          }
          
          ?>
      </div>
      <div id="princewoordphone" class="unoccupied">
          <div id="princewoorddictionary">
               <div id="previouswoord" class="searchedwoord pwuserquery">&larr;</div>
               <div id="nextwoord" class="searchedwoord pwuserquery">&rarr;</div>
               <input type="text" name="woord" value="woord" id="thewoord" class="pwuserquery">
               <div class="pwuserquery" id="querypw"></div>
               <div class="pwuserquery" id="closepwdictionary">X</div>
             
               <ul id="searchedwoord"></ul>
               <div class="pwsearchresult" id="pw_message"></div>
               <div class="pwsearchresult active" id="pw_definition"></div>
               <div class="pwsearchresult" id="pw_alsosee"></div>
               <div class="pwsearchresult" id="pw_similar"></div>
               <div class="pwsearchresult" id="pw_attribute"></div>
               <div class="pwsearchresult" id="pw_derived"></div>
               <div class="pwsearchresult" id="pw_meronym"></div>
               <div class="pwsearchresult" id="pw_holonym"></div>
               <div class="pwsearchresult" id="pw_hypernym"></div>
               <div class="pwsearchresult" id="pw_hyponym"></div>
               <ul id="woordnetmenu">
                    <li id="wnm_definition" class="active">Def</li>
                    <li id="wnm_alsosee">AlsoSee</li>
                    <li id="wnm_similar">Similar</li>
                    <li id="wnm_attribute">Attr</li>
                    <li id="wnm_derived">Derivatives</li>
                    <li id="wnm_meronym">Meron</li>
                    <li id="wnm_holonym">Holo</li>
                    <li id="wnm_hypernym">Hyper</li>
                    <li id="wnm_hyponym">Hypo</li>
               </ul>
          </div>
      </div>
   </div>
 </div>
                 
                 
 <div id="settingscontainer" class="contentcontainer">
   <div class="loadingnotifcontainer"><div class="loading"></div></div>
   <div class="opaquebg"></div>
   
   <div class="content">
       <div class="descriptioncontainer table">
            <div class="descriptiontext tablecell">
               <ul id="miscmenu">
                    <li class="active">
                         <div class="miscpage">
                              <div class="submitnewsletterreq"></div>
                              <div class="row center">
                                   <input type="text" class="newsletteremail" name="Email" value="Email">
                                   <div class="loadnewslettersettings"></div>
                                   <div class="removesubscription"></div>
                              </div>
                              <div class="row hidden message emailerror">
                                   Email should not be empty.
                              </div> 
                              <div class="row">
                                   <select class="newslettersource">
                                        <option value="0">Source</option>
                                        <?php
                                             $velp->formselectopt($pagevar['newslettersource']);
                                        ?>
                                   </select>
                                   <select class="newslettersourcecategory" name="source category">
                                        <option value="0">All Category</option>
                                   </select>
                                   <input type="text" class="newslettersourcekeywords" name="Keywords, separate by comma" value="Keywords, separate by comma">
                                   <input type="button" class="newsletteraddsources" value="+">
                                   <input type="button" class="newsletterremsources" value="-">
                              </div>
                              <div class="row hidden message newssourceerror">
                                   News source should not be empty.
                              </div> 
                         </div>
                         <div class="miscaccordmenu">Newsletter</div>
                    </li>
                    <li class="">
                         <div class="miscpage">
                              <select name="statselect" id="statselect">
                                   <option value="0">Select Category</option>
                                   <option value="articledownload">Articles Download</option>
                                   <option value="newssourcedownload">News Sources Downloads</option>
                                   <option value="trendingkeywords">Trending Keywords</option>
                              </select>
                              <div id="statisticperiodsett">
                                   <span>from</span>
                                   <span><input class="statperiodinput datefield" type="text" id="statperiodoptstart" name="Very early" value="Very early"></span>
                                   <span>to</span>
                                   <span><input class="statperiodinput datefield" type="text" id="statperiodoptend" name="Now" value="Now"></span>
                                   <span><input type="button" value="submit" id="submitperiodchart" class="rssactionbutton"></span>
                              </div>
                              
                              <div class="statcontainer">
                                   <div class="statchart" id="articledownload_chart" style="height:0px;width:100%;"></div>
                                   <div class="statchart" id="newssourcedownload_chart" style="height:0px;width:100%;"></div>
                                   <div class="statchart" id="trendingkeywords_chart" style="height:0px;width:100%;"></div>
                              </div>
                         </div>
                         <div class="miscaccordmenu">Statistics</div>
                    </li>
               </ul>
            </div>
       </div>
   </div>
 </div>