<script type="text/javascript">
var itsacontentpage = true;
</script>
<div class="articlepage" id="articlepage_<?php echo $pagevar['content']['newsid']; ?>">
    <div class="articletitle"><?php echo $pagevar['content']['title']; ?></div>
      <div class="articledate"><?php echo $pagevar['content']['pubDate'].' By '.$pagevar['content']['creator']; ?></div>
      <div class="articlecategory">
        <span class="articlelabel">Category</span>
        <span class="colon">:</span>
        <span class="articleattr"><?php echo $pagevar['content']['cats']; ?></span>
      </div>
      <div class="articlepublisher">
        <span class="articlelabel">Publisher</span>
        <span class="colon">:</span>
        <span class="articleattr"><?php echo $pagevar['content']['pubSher']; ?></span>
      </div>
      <div class="articlecontent">
          <?php echo $pagevar['content']['news']; ?>
      </div>
</div>