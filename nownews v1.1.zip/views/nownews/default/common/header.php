<!DOCTYPE html><html>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<head>
    <meta charset="UTF-8">
    <link rel="canonical" href="http://localhost/multifair/?app=nownews">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="robots" content="all">
    <?php $velp->printheadsrc(); ?>
    <title></title>
</head>
<body>
    <div id="messagepup">
        <h3 id="messagetitle"></h3>
        <div class="loading" id="messageloading"></div>
        <div id="themessage"></div>
        <div id="submitoption"></div>
    </div>
    <div class="opaquebg"></div>
    <div id="header">
        <a href="javascript:void(0);" id="branding">
            <span id="logotext"><span><span>NOW.</span><span id="newslogo">NEWS.</span></span></span>
            <span id="logo"></span>
        </a>
    </div>
    <div id="pbody">
    
    