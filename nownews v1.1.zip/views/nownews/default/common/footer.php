    <div id="togglesource"><span><?php if($pagevar['mobile']) echo '&dArr;'; ?></span></div>
    <div id="sourceopt">
            <div id="sourcenavprev" class="sourcenav"><span></span></div>
            <ul id="sourcelist" class="active endorfirst">
                <div class="sourcelistgroup active">
            <?php
                foreach($pagevar['sources'] as $sk=>$sv){
                        if($sk % 10 == 0 && $sk != 0){
                                echo '</div><div class="sourcelistgroup">';
                        }
                ?>
                
                        <li class="sourceitem" id="<?php echo $sv['id']; ?>"><?php echo $sv['content'] ?></li>
                
                <?php
                }
            ?>
                </div>
            </ul>
            <div id="sourcenavnext" class="sourcenav active"><span></span></div>
        </div>       
    </div>
    <div id="menucontainer">
        <ul id="menutabs">
            <li class="menutab active" id="menurss">RSS</li>
            <li class="menutab" id="menudownloaded">Reader &nbsp;<span id="downloadcount">(0)</span></li>
            <li class="menutab" id="menusettings">Misc</li>
        </ul>
    </div>
</body>
<script type="text/javascript">
    var numofsources = <?php echo $pagevar['numofsources']; ?>;
    var mobile = <?php echo $pagevar['mobile']; ?>;
</script>
<?php $velp->printfootsrc(); ?>
</html>