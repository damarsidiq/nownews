<?php

echo $pagevar['message'];

?>