<?php

Class newsImages extends Model{
    var $trio1 = false;
    function __construct(){
        parent::__construct('newsimages');
    }
    
    public function importimage($src,$rssid,$filename){
        list($width,$height)    = getimagesize($src);
        if($width < 230 && $height < 230){
            return false;
        }
        
        $this->addrecord(array('rssid','filename'),array($rssid,$filename));
        
    	$context=array(
			"ssl"=>array(
				"verify_peer"=>false,
				"verify_peer_name"=>false,
			),
		);  
		$handler = @fopen($src, 'rb', false, stream_context_create($context));
        if($handler){
            $handler2   = @fopen(App::getConfig('uploads').'newsimages/'.$filename.'.png','w');
            
            $content = '';
            $c=0;
            while(false !== ($readit = fgets($handler,4096))){
                $content .= $readit;
            }
            $wrote = fwrite($handler2,$content);
            if($wrote === false){
                return 0;
            }
            return App::getConfig('uploads').'newsimages/'.$filename.'.png';                   
        }
        
        return 0;
    }
    public function imageexists($link){
        $imagereading = @get_headers($link);
        if(!is_array($imagereading)){
            return false;
        }
        
        if(strpos($imagereading[0],'200') !== false){
            if($this->trio1){
                return $link;
            }
            return true;
        }
        
        if(strpos($imagereading[0],'301') !== false && strpos($link,'http://') !== false && $this->trio1 === false){
            $link = str_replace('http://','https://',$link);
            $this->trio1 = true;
            
            return $this->imageexists($link);
        }
        return false;
    }
    public function downloadimage($src,$rssid){
        $imagesizereading    = @getimagesize($src);
        if(is_array($imagesizereading)){
            list($width,$height) = $imagesizereading;
        }
        else{
            return false;
        }
        if($width < 230 && $height < 230){
            return false;
        }
        
        $added = $this->addrecord(array('rssid'),array($rssid));
        $imageid = $this->insertid();
        $filename = time().$imageid;
        $this->updaterecord(array('filename'=>$filename),array('id'=>$imageid));
        
    	$context=array(
			"ssl"=>array(
				"verify_peer"=>false,
				"verify_peer_name"=>false,
			),
		);  
		$handler = @fopen($src, 'rb', false, stream_context_create($context));
        if($handler){
            $handler2   = @fopen(App::getConfig('uploads').'newsimages/'.$filename.'.png','w');
            
            $content = '';
            $c=0;
            while(false !== ($readit = fgets($handler,4096))){
                $content .= $readit;
            }
            fwrite($handler2,$content);
            return App::getConfig('uploads').'newsimages/'.$filename.'.png';                   
        }
        
        return false;
    }
    
}


?>