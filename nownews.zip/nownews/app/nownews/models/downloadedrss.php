<?php

Class Downloadedrss extends Model{
    var $archivelimit = 15;
    var $searchlimit = 15;
    var $encodingdest = 'UTF-8';
    function __construct(){
        parent::__construct('downloadedrss');
    }
    public function searchByDate($datefilter,$source=false,$idolderthan=false,$start=0,$excluding=false){
        $start          = $start*$this->searchlimit;
        $datefilter[1]  = date('Y-m-d H:i:s',strtotime($datefilter[1]) + (3600*24) -1);
        $extracondi     = array(0=> array('pubDate'=>array('>=',$datefilter[0])), 1=>array('pubDate'=>array('<=',$datefilter[1])) );
        
        if($source !== false){
            $extracondi[] = array('newssource'=>$source);
        }
        if($idolderthan !== false){
           $extracondi[] = array('id'=> array('<',$idolderthan));
        }
        $searchresult =  $this->getrecords( array( 'and'=>$extracondi ) , null, array('id','DESC'), $start.','.($this->archivelimit+1) );
        
        if($excluding !==false){
            $searchres = array();
            foreach($searchresult as $sk=>$sv){
                $exclude = false;    
                
                foreach($excluding as $exck=>$excv){
                    if($excv['category'] == $sv['category'] && $sv['id'] >= $excv['oldestid']){
                        $excluding[$exck]['count']      -= 1;
                        $excluding[$exck]['oldestid']   = $sv['id'];
                        if($excluding[$exck]['count']>=0){
                            $exclude = true;
                        }
                    }
                }
                
                if(!$exclude){
                    $searchres[] = $sv;
                }
            }
            
            $limit = false;
            if(count($searchres) <= $this->searchlimit){
                $limit = true;
            }
            else{
                unset($searchres[count($searchres)-1]);
            }
            
            return array($searchres,$limit,$excluding);
        }
        else{
            $searchres = $searchresult;
        }
        
        $limit = false;
        if(count($searchres) <= $this->searchlimit){
            $limit = true;
        }
        else{
            unset($searchres[count($searchres)-1]);
        }
        
        return array($searchres,$limit);
    }
    public function searchedNews($rssids,$datefilter=false,$source=false,$idolderthan=0,$start=0,$excluding=false){
        $start          = $start*$this->searchlimit;
        $extracondi     = array();
        
        if($datefilter != false){
            $datefilter[1]  = date('Y-m-d H:i:s',strtotime($datefilter[1]) + (3600*24) -1);
            $datestart      = $datefilter[0];
            $dateend        = $datefilter[1];
            
            $extracondi = array(0=> array('pubDate'=>array('>=',$datestart)), 1=>array('pubDate'=>array('<=',$dateend)) );
        }
        if($source !== false){
            $extracondi[] = array('newssource'=>$source);
        }
        
        if($idolderthan != 0){
            $extracondi[] = array('id'=>array('<',$idolderthan));
            $searchresult = $this->getrecords( array('id'=>array('in',$rssids), 'and'=>$extracondi), null, array('id','DESC'), $start.','.($this->searchlimit+1) );            
        }
        else{
            if(count($extracondi)){
                $searchresult = $this->getrecords( array('id'=>array('in',$rssids), 'and'=>$extracondi ), null, array('id','DESC'), $start.','.($this->searchlimit+1) );
            }
            else
                $searchresult = $this->getrecords(array('id'=>array('in',$rssids)) , null, array('id','DESC'), $start.','.($this->searchlimit+1) );
        }

        
        if($excluding !==false){
            $searchres = array();
            foreach($searchresult as $sk=>$sv){
                $exclude = false;    
                
                foreach($excluding as $exck=>$excv){
                    if($excv['category'] == $sv['category'] && $sv['id'] >= $excv['oldestid']){
                        $excluding[$exck]['count']      -= 1;
                        $excluding[$exck]['oldestid']   = $sv['id'];
                        if($excluding[$exck]['count']>=0){
                            $exclude = true;
                        }
                    }
                }
                
                if(!$exclude){
                    $searchres[] = $sv;
                }
            }

            $limit = false;
            if(count($searchres) <= $this->searchlimit){
                $limit = true;
            }
            else{
                unset($searchres[count($searchres)-1]);
            }
            
            return array($searchres,$limit,$excluding);
        }
        else{
            $searchres = $searchresult;
        }
        
        $limit = false;
        if(count($searchres) <= $this->searchlimit){
            $limit = true;
        }
        else{
            unset($searchres[count($searchres)-1]);
        }
        
        return array($searchres,$limit);
    }
    public function getItem($rssid){
        $item = $this->getrecord(array('id'=>$rssid));
        return $item;
    }
    public function getItemDesc($rssid){
        $query = $this->query('select downloadedrss.*,newssource.name from downloadedrss,newssource where downloadedrss.id='.$rssid.' and downloadedrss.newssource = newssource.id');
        if($query){
            return $this->fetchQueryResult($query);
        }
        return false;
    }
    public function getCategoryArchive($sourceid,$start,$category){
        $archives   = $this->fetchQueryResult($this->query('select * from downloadedrss where newssource = '.$sourceid.' and tags like "%,'.$category.',%" or tags like "'.$category.',%" or tags like "%,'.$category.'" or category = '.$category.' or tags = "'.$category.'" order by id desc limit '.$start.','.($this->archivelimit+1)));
        $limit      = false;
        if(count($archives) <= $this->archivelimit){
            $limit = true;
        }
        else
            unset($archives[count($archives)-1]);
            
        foreach($archives as $arck =>$arcv){
            $archives[$arck]['title']       = stripslashes($archives[$arck]['title']);
            $archives[$arck]['creator']     = stripslashes($archives[$arck]['creator']);
            $archives[$arck]['description'] = stripslashes($archives[$arck]['description']);
            $archives[$arck]['pubDate']     = date('l, F jS Y H:i:s',strtotime($archives[$arck]['pubDate']));
            $archives[$arck]['datetosort']  = date('Y-m-d H:i:s',strtotime($archives[$arck]['pubDate']));
            $archives[$arck]['tags']        = $archives[$arck]['tags'] == '' ? array() : explode(',',$archives[$arck]['tags']);
        }
        return array($archives,$limit);
    }
    public function getArchiveAllBut($sourceid,$start,$excluding){
        $archives   = $this->getrecords(array('newssource'=>$sourceid),null,array('id','DESC'),$start.','.($this->archivelimit+1));
        $limit      = false;
        if(count($archives) <= $this->archivelimit){
            $limit = true;
        }
        else{
            unset($archives[count($archives)-1]);
        }
        
        $thearchive = array();
        foreach($archives as $arck =>$arcv){
            $exclude = false;
            foreach($excluding as $exck=>$excv){
                if($excv['category'] == $arcv['category']){
                    $excluding[$exck]['count'] -= 1;
                    if($excluding[$exck]['count']>=0){
                        $exclude = true;
                    }
                }
            }
            
            if(!$exclude){
                $archives[$arck]['title']       = stripslashes($archives[$arck]['title']);
                $archives[$arck]['creator']     = stripslashes($archives[$arck]['creator']);
                $archives[$arck]['description'] = stripslashes($archives[$arck]['description']);
                $archives[$arck]['pubDate']     = date('l, F jS Y H:i:s',strtotime($archives[$arck]['pubDate']));
                $archives[$arck]['datetosort']  = date('Y-m-d H:i:s',strtotime($archives[$arck]['pubDate']));
                $archives[$arck]['tags']        = $archives[$arck]['tags'] == '' ? array() : explode(',',$archives[$arck]['tags']);
                
                $thearchive[] = $archives[$arck];
            }
        }
        return array($thearchive,$limit,$excluding);
    }
    public function getArchive($sourceid,$start){
        $archives   = $this->getrecords(array('newssource'=>$sourceid),null,array('id','DESC'),$start.','.($this->archivelimit+1));
        $limit      = false;
        if(count($archives) <= $this->archivelimit){
            $limit = true;
        }
        else
            unset($archives[count($archives)-1]);
            
        foreach($archives as $arck =>$arcv){
            $archives[$arck]['title']       = stripslashes($archives[$arck]['title']);
            $archives[$arck]['creator']     = stripslashes($archives[$arck]['creator']);
            $archives[$arck]['description'] = stripslashes($archives[$arck]['description']);
            $archives[$arck]['pubDate']     = date('l, F jS Y H:i:s',strtotime($archives[$arck]['pubDate']));
            $archives[$arck]['datetosort']  = date('Y-m-d H:i:s',strtotime($archives[$arck]['pubDate']));
            $archives[$arck]['tags']        = $archives[$arck]['tags'] == '' ? array() : explode(',',$archives[$arck]['tags']);
        }
        return array($archives,$limit);
    }
    public function saveNewsItem($newsitem,$sourceid){
        $newsitem['pubDate']        = date('Y-m-d H:i:s',strtotime($newsitem['pubDate']));
        
        $keys   = array();
        $values = array();
        
        foreach($newsitem as $nik=>$niv){
            if($nik === 'dc:creator')
                $nik = 'creator';
            elseif($nik == 'tags'){
                $niv = is_array($niv) ? implode(',',$niv) : $niv;
            }
            $keys[]     = $nik;
            $values[]   = ($nik == 'title' || $nik == 'description' || $nik == 'creator') ? mb_convert_encoding(str_replace(array('‘','’','“','”','—'),array("'","'",'"','"','-'),$niv),$this->encodingdest) : $niv;
        }
        
        if($this->addrecord($keys,$values))
            return $this->insertid();
        
        return false;
    }
    public function updateDownloadCount($rssid){
        $rssitem = $this->getItem($rssid);
        return $this->updaterecord(array('downloadcount'=>($rssitem['downloadcount']+1)), array('id'=>$rssid) );
    }
    public function updateDownloadCountNewsletter($toupdate){
        $updated = $this->query('update downloadedrss set downloadcount=downloadcount+1 where id in('. implode(',',$toupdate) .')');
        return $updated;
    }
    public function newsletterRss($source){
        list($startdate,$enddate)   = $this->sourceLastCycleDates($source);
        $rss                        = $this->getrecords(array('newssource'=> $source['source'] ,'pubDate' =>array('>=',$startdate)));
        
        return array($rss,$enddate);
    }
    public function sourceLastCycleDates($source){
        $youngest       = $this->getrecord(array('newssource'=>$source['source']),null,array('pubDate','desc'),'1');
        $youngesttime   = strtotime($youngest['pubDate']);
        $youngestdate   = date('Y-m-d H:i:s',$youngesttime);
        
        $aday       = 86400;
        $aweek      = 604800;
        $amonth     = 2678400;
        
        $onecycle       = $source['cycle'] == 'daily' ? $aday : ($source['cycle'] == 'weekly' ? $aweek : ($source['cycle'] == 'monthly' ? $amonth : $aday));
        $oldestincycle  = date('Y-m-d H:i:s', strtotime(date('Y-m-d',$youngesttime-$onecycle)) );
        
        $oldest         = $this->getrecord(array('newssource'=>$source['source'],'pubDate'=>array('>=',$oldestincycle)),null,array('pubDate','asc'),'1');
        $oldestdate     = $oldest['pubDate'];
        
        return array($oldestdate,$youngestdate);
    }
    public function fiximageurl($rssitem,$articlebody){
        if(substr($rssitem['link'],-1) == '/')
            $rssitem['link'] = substr($rssitem['link'],0,-1);
            
        
        foreach($articlebody as $key=>$val){
            if($val['attribute'][0] == 'img'){
                for($i=1;$i<count($val['attribute']);$i++){
                    if(strpos($val['attribute'][$i],'src') !== false && strpos($val['attribute'][$i],'srcset') === false){
                        $src = explode('"',$val['attribute'][$i]);
                        if(isset($src[1])){
                            $imagereadingsuccess = false;
                            if($src[1] !== '' && $src[1][0] == '/'){
                                if($src[1][1] == '/'){
                                    $src[1] = 'http:'.$src[1];
                                    $imagereadingsuccess = $this->model('newsimages')->imageexists($src[1]);
                                }
                                else{
                                    $fixlink = str_replace(array('http://','https://'),'',$rssitem['link']);
                                    $fixlinkx = explode('/',$fixlink);
                                    
                                    $thelink = 'http:/';
                                    for($fouri=0;$fouri<=(count($fixlinkx)-1);$fouri++){
                                        $thelink .= '/'.$fixlinkx[$fouri];
                                        if($this->model('newsimages')->imageexists(($thelink.$src[1]))){
                                            $src[1] = ($thelink.$src[1]);
                                            $imagereadingsuccess = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            elseif($src[1] !== '' && substr($src[1],0,2) == './'){
                                $thelinkx = explode('/',$rssitem['link']);
                                unset($thelinkx[count($thelinkx)-1]);
                                
                                $thelink = implode('/',$thelinkx);
                                $src[1] = ($thelink.''.substr($src[1],2));
                                $imagereadingsuccess = $this->model('newsimages')->imageexists($src[1]);
                            }
                            else{
                                $imagereadingsuccess = $this->model('newsimages')->imageexists($src[1]);
                            }
                            
                            if($imagereadingsuccess!==false){
                                if($imagereadingsuccess !== true){
                                    $src[1] = $imagereadingsuccess;
                                }
                                $imagesrcnew = $this->model('newsimages')->downloadimage($src[1],$rssitem['id']);
                                if($imagesrcnew !== false){
                                    $src[1] = $imagesrcnew;
                                }      
                            }
                            $articlebody[$key]['attribute'][$i] = str_replace('data-src','src',implode('"',$src));
                        }
                    }
                }
            }
            else{
                if(count($val['elements'])){
                    $articlebody[$key]['elements'] = $this->fiximageurl($rssitem,$val['elements']);
                }
            }
        }
        return $articlebody;
    }
    
}
?>