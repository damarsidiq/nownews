<?php

Class Keywords extends Model{
    function __construct(){
        parent::__construct('keywords');
    }
    
    public function getKeyIds($keywords){
        if(is_array($keywords)){
            $keycond = array('or'=>array());
            foreach($keywords as $kk=>$kv){
                $keycond['or'][] = array('keyword'=>strtolower(trim($kv)));
            }
            return ($this->getrecords($keycond));
        }
        else{
            return $this->getrecords(array('keyword'=>strtolower(trim($keywords))));
        }
    }
    public function addKeywords($keywords){
        $keyids = array();
        foreach($keywords as $keywordsk=>$keywordsv){
            $keywords[$keywordsk] = strtolower(trim($keywordsv));
            $keyid = $this->getrecord(array('keyword'=>$keywords[$keywordsk]),array('id'));
            if($keyid !== false){
                $keyids[] = $keyid;
            }
            else{
                $keyid = $this->addrecord('keyword',$keywords[$keywordsk]);
                $keyids[] = $keyid;
            }
        }
        return array($keyids,$keywords);
    }
    
    public function extractkeywords($xmldata,$keywordsett){
        $thekeywords = array();
        foreach($keywordsett as $keywordnodek=>$keywordnodev){
           $node = $keywordnodev;
           
           $keywordnode    = Pxpedia::xmldata($node,'',$xmldata);
           if(count($keywordnode)){
               $response   = $keywordnode;
               foreach($response as $responsek=>$responsev){
                    foreach($responsev['attribute'] as $attk=>$attv){
                        if(strpos($attv,'content') !== false){
                            $response = trim(str_replace(array('"','=','content','}','/','{',"'"),array(''),$attv));
                            $thekeywords = array_merge($thekeywords,explode(',',$response));
                        }
                    }
               }
               break;
           }
        }
        $filteredkeys = array();
        foreach($thekeywords as $thekeywordsk=>$thekeywordsv){
            $thekeywords[$thekeywordsk] = str_replace('/','',strtolower(trim($thekeywordsv)));
            if($thekeywords[$thekeywordsk] != '')
                $filteredkeys[] = $thekeywords[$thekeywordsk];
        }
        return $filteredkeys;
    }
}


?>