<?php
if(!class_exists('Pxpedia')){
	die();
}
Class App extends Pxpedia{
    function __construct(){
		parent::__construct();
		
    }
}


