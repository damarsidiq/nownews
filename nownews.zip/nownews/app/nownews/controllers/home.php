<?php

Class Home extends Controller{
    function __construct() {
        parent::__construct();
    }
    public function pageInit($data=null,$view='home'){
		list($sourcelist,$numofsource)  = $this->model('source')->getSources(null,10);
		$sourcelistitems    	        = array();
		$newslettersource 	            = array();
		
		$count = 0;
		foreach($sourcelist as $sk=>$sv){
			if($sk<10){
				$sourcelistitems[$count]['id'] 		= 'newssource_'.$sv['id'];
				$sourcelistitems[$count]['content'] = '<div class="table"><div class="tablecell"><img src="'.$sv['logo'].'" title="'. $sv['name'] .'"></div></div>';
			}

			
			$newslettersource[$count]['name'] 	= $sv['name'];
			$newslettersource[$count]['value'] 	= $sv['id'];
			
			$count++;
		}
		$this->setPagevar('numofsources',$numofsource);
		$this->setPagevar('newslettersource',$newslettersource);
		$this->setPagevar('sources',$sourcelistitems);
		$this->setPagevar('mobile','false');
		
		if(App::isMobile()){
		    $this->setPagevar('mobile','true');
		    $this->addheadfootsrc(false,array('mobile'=>App::getConfig('appviews').'/styles/mobile.css'));
		}
		return $view;
    }
}