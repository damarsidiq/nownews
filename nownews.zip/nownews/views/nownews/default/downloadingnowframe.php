<?php $velp->printfootsrc(); ?>
<style>
    html,body,form{width: 100%;height: 100%;padding: 0px;margin: 0px;}
    h3{display: block;clear: both;margin-top:20px;margin-left:10px;}
    .submitdownloadsetting, .inputrow{display: block;width:100%;margin-bottom:10px;clear:both;float:left}
    .submitdownloadsetting{margin-top:30px;margin-left:10px;}
    .submitdownloadsetting input{display: block;}
    .inputrow div{display: inline-block;float: left;margin-left:10px;}
    input[type="text"]{width: 207px;color:#949494;}
    input[type="text"].filled{color:black;}
</style>


<div class="inputrow"><h3>Source</h3></div>

<div class="inputrow">
    <div>
    <select id="source">
        <option value="0">---------</option>
        <?php
            $options = '';
            foreach($pagevar['source'] as $sourcek=>$sourcev){
                $options .= '<option value="'. $sourcev['id'] .'">'. $sourcev['name'] .'</option>';        
            }
            echo $options;
        ?>
    </select>
    </div>
</div>


<ul id="menulist">
    <li class="menulistitem">Descriptions</li>
    <li class="menulistitem">Content Settings</li>
    <li class="menulistitem"></li>
</ul>
<div class="settingscontent">    
    <div class="inputrow"><h3>Content</h3></div>
    <div class="inputrow contentinput">
        <div><input type="text" name="content tag" value="content tag"></div>
        <div><input type="text" name="content tag attribute" value="content tag attribute"></div>
        <div><input type="text" name="content tag attribute value" value="content tag attribute value"></div>
    </div>
    <div class="inputrow"><h3>Exclude</h3></div>
    <div class="inputrow excludeinput">
        <div><input type="text" name="content tag" value="content tag"></div>
        <div><input type="text" name="content tag attribute" value="content tag attribute"></div>
        <div><input type="text" name="content tag attribute value" value="content tag attribute value"></div>
        <div><input type="button" class="addexclude" value="+"></div>
    </div>
    <div class="inputrow excludeinput">
        <div><input type="text" name="content tag" value="content tag"></div>
        <div><input type="text" name="content tag attribute" value="content tag attribute"></div>
        <div><input type="text" name="content tag attribute value" value="content tag attribute value"></div>
        <div><input type="button" class="addexclude" value="+"></div>
    </div>
    <div class="inputrow excludeinput">
        <div><input type="text" name="content tag" value="content tag"></div>
        <div><input type="text" name="content tag attribute" value="content tag attribute"></div>
        <div><input type="text" name="content tag attribute value" value="content tag attribute value"></div>
        <div><input type="button" class="addexclude" value="+"></div>
    </div>
        
    <div class="submitdownloadsetting"><input type="button" value="save" id="savedownloadsetting"></div>
</div>
   


