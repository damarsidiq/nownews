<form action="<?php echo App::pluginUrl('source_setting',array('p'=>'admin','a'=>'addnew')); ?>" method="POST" name="" class="sourceform" enctype="multipart/form-data">
    <div class="<?php echo $messageclass; ?>">
        <?php echo $pagevar['message']; ?>
    </div>
    
    
    <div class="inputrow nownewsmenu">
        <ul id="menulist" class="innersubmenus">
            <li class="menulistitem active" id="descriptionstab"><a href="javascript:void(0);">Descriptions</a></li>
            <li class="menulistitem " id="settingstab"><a href="javascript:void(0);">Settings</a></li>
        </ul>
    </div>

    <div class="inputrow title"><label>&nbsp;</label></div>
    <div class="sourcecontent descriptionscontent active">
        <div class="editsource">
          <div class="inputrow title"><label>Name</label></div>
            <div class="inputrow">
                <div><input type="text" name="sourcename"></div>
            </div>
            <div class="inputrow title"><label>Url</label></div>
            <div class="inputrow">
                <div>
                    <input type="text" name="url" value="">
                </div>
            </div>
            <div class="inputrow title"><label>Cycle</label></div>
            <div class="inputrow">
                <select name="cycle" class="cycle">
                    <option value=""></option>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="bimonthly">Bi-Monthly</option>
                    <option value="other">Other</option>
                </select>
            </div>
            <div class="inputrow hidden title"><label>Describe</label></div>
            <div class="inputrow hidden">
                <div>
                    <input type="text" name="cycledescription" value="">
                </div>
            </div>
            <div class="inputrow title"><label>Logo</label></div>
            <div class="inputrow">
                <div>
                    <div class="holder">
                        <img src="uploads/nownews/nownews.source.png" class="sourcelogo">
                    </div>
                    <input type="file" name="sourcelogo" class="sourcelogofile">
                </div>
            </div>
            <div class="inputrow title"><label>Description</label></div>
            <div class="inputrow">
                <div>
                    <textarea name="description"></textarea>
                 </div>
            </div>
            <div class="inputrow">
                <div>
                    <input type="submit" name="createnew"  value="Save" class="submitform">
                </div>
            </div>
        </div>
    </div>
    
    <div class="sourcecontent settingscontent">
        <div class="inputrow title"><label>Status</label></div>
        <div class="inputrow contentinput">
            <select name="sourcestatus">
                <option value="-1"></option>
                <option value="1">active</option>
                <option value="0">inactive</option>
            </select>
        </div>
        <div class="inputrow title"><label>Content</label></div>
        <div class="inputrow contentinput">
            <div><input type="text" name="content tag" value="content tag"></div>
            <div><input type="text" name="content tag attribute" value="content tag attribute"></div>
            <div><input type="text" name="content tag attribute value" value="content tag attribute value"></div>
            <div><input type="button" name="addcontent" class="addcontent" value="+"></div>
            <div><input type="button" name="removecontent" class="removecontent" value="-"></div>
        </div>
        
        <div class="inputrow title" id="addnewkeywordstitle"><label>Keywords</label></div>
        <div class="inputrow keywordsinput">
            <div><input type="text" name="keywords tag" value="keywords tag"></div>
            <div><input type="text" name="keywords tag attribute" value="keywords tag attribute"></div>
            <div><input type="text" name="keywords tag attribute value" value="keywords tag attribute value"></div>
        </div>
    
        <div class="inputrow title"><label>Exclude</label></div>
        <div class="inputrow excludeinput">
            <div><input type="text" name="exclude tag" value="exclude tag"></div>
            <div><input type="text" name="exclude tag attribute" value="exclude tag attribute"></div>
            <div><input type="text" name="exclude tag attribute value" value="exclude tag attribute value"></div>
            <div><input type="button" class="addexclude" value="+"></div>
            <div><input type="button" class="removeexclude" value="-"></div>
        </div>
        <div class="inputrow excludeinput">
            <div><input type="text" name="exclude tag" value="exclude tag"></div>
            <div><input type="text" name="exclude tag attribute" value="exclude tag attribute"></div>
            <div><input type="text" name="exclude tag attribute value" value="exclude tag attribute value"></div>
            <div><input type="button" class="addexclude" value="+"></div>
            <div><input type="button" class="removeexclude" value="-"></div>
        </div>
        <div class="inputrow excludeinput">
            <div><input type="text" name="exclude tag" value="exclude tag"></div>
            <div><input type="text" name="exclude tag attribute" value="exclude tag attribute"></div>
            <div><input type="text" name="exclude tag attribute value" value="exclude tag attribute value"></div>
            <div><input type="button" class="addexclude" value="+"></div>
            <div><input type="button" class="removeexclude" value="-"></div>
        </div>
    
    
        <input type="hidden" name="cscont" id="cscont" value="">
        <input type="hidden" name="csexc" id="csexc" value="">
        <input type="hidden" name="cskeywords" id="cskeywords" value="">
        <div class="submitdownloadsetting"><input type="submit" name="createnew" value="save" class="submitform" id="savedownloadsetting"></div>
    </div>
</form>