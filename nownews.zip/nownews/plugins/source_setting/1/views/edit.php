<form action="<?php echo App::pluginUrl('source_setting',array('p'=>'admin','a'=>'pageInit')); ?>" method="POST" name="" class="sourceform ajax" enctype="multipart/form-data">

<div class="<?php echo $messageclass; ?>">
    <?php echo $pagevar['message']; ?>
</div>

<div class="inputrow title"><label>Source</label></div>
<div class="inputrow">
    <select id="source" name="sourceid">
        <option value="0"></option>
        <?php echo $options; ?>
    </select>
</div>

<div class="inputrow nownewsmenu">
    <ul id="menulist" class="innersubmenus">
        <li class="menulistitem active" id="descriptionstab"><a href="javascript:void(0);">Descriptions</a></li>
        <li class="menulistitem " id="settingstab"><a href="javascript:void(0);">Settings</a></li>
        <li class="menulistitem black" id="deletetab"><a href="javascript:void(0);">Delete Source</a></li>
    </ul>
</div>

<div class="sourcecontent descriptionscontent active">
    <div class="loadingcontent"></div>
    <div class="editsource">
        <div class="inputrow title"><label>Name</label></div>
        <div class="inputrow">
            <div><input type="text" name="sourcename" value="<?php if(isset($pagevar['currentsource'])){ echo $pagevar['currentsource']['name']; } ?>"></div>
        </div>
        <div class="inputrow title"><label>Url</label></div>
        <div class="inputrow">
            <div>
                <input type="text" name="url"  value="<?php if(isset($pagevar['currentsource'])){ echo $pagevar['currentsource']['url']; } ?>">
            </div>
        </div>
        <div class="inputrow title"><label>Cycle</label></div>
        <div class="inputrow">
            <select name="cycle" class="cycle">
                <option value=""></option>
                <option value="daily"    <?php if(isset($pagevar['currentsource']) && $pagevar['currentsource']['cycle'] == 'daily'){ echo 'selected="selected"'; }  ?>>Daily</option>
                <option value="weekly"   <?php if(isset($pagevar['currentsource']) && $pagevar['currentsource']['cycle'] == 'weekly'){ echo 'selected="selected"'; }  ?>>Weekly</option>
                <option value="monthly"  <?php if(isset($pagevar['currentsource']) && $pagevar['currentsource']['cycle'] == 'monthly'){ echo 'selected="selected"'; }  ?>>Monthly</option>
                <option value="bimonthly" <?php if(isset($pagevar['currentsource']) && $pagevar['currentsource']['cycle'] == 'bimonthly'){ echo 'selected="selected"'; }  ?>>Bi-Monthly</option>
                <option value="other"    <?php if(isset($pagevar['currentsource']) && $pagevar['currentsource']['cycle'] == 'other'){ echo 'selected="selected"'; }  ?>>Other</option>
            </select>
        </div>
        <div class="inputrow hidden title"><label>Cycle Description</label></div>
        <div class="inputrow hidden">
            <div>
                <input type="text" name="cycledescription"  value="<?php if(isset($pagevar['currentsource'])){ echo $pagevar['currentsource']['cycledescription']; } ?>">
            </div>
        </div>
        <div class="inputrow title"><label>Logo</label></div>
        <div class="inputrow">
            <div>
                <div class="holder">
                    <img src="<?php if(isset($pagevar['currentsource']) && $pagevar['currentsource']['logo'] != '') echo $pagevar['currentsource']['logo']; else echo 'uploads/nownews/nownews.source.png'; ?>" class="sourcelogo">
                </div>
                <input type="file" name="sourcelogo" class="sourcelogofile">
            </div>
        </div>
        <div class="inputrow title"><label>Description</label></div>
        <div class="inputrow">
            <div>
                <textarea name="description"><?php if(isset($pagevar['currentsource'])){ echo $pagevar['currentsource']['description']; } ?></textarea>
             </div>
        </div>
    </div>
</div>

<div class="sourcecontent settingscontent">
    <div class="loadingcontent"></div>
    <div class="inputrow title"><label>Status</label></div>
    <div class="inputrow status">
        <select name="sourcestatus">
            <option value="1" <?php if(isset($pagevar['currentsource']) && $pagevar['currentsource']['status'] == 1) echo 'selected="selected"'; ?>>active</option>
            <option value="0" <?php if(isset($pagevar['currentsource']) && $pagevar['currentsource']['status'] == 0) echo 'selected="selected"'; ?>>inactive</option>
        </select>
    </div>
    <div class="inputrow title" id="contenttitle"><label>Content</label></div>
    <?php
        if(isset($pagevar['currentsource']) && $pagevar['currentsource']['downloadsetting'] != ''){
            $downloadsettings = json_decode($pagevar['currentsource']['downloadsetting'],true);
            foreach($downloadsettings['thecontent'] as $contk=>$contv){
            ?>
                <div class="inputrow contentinput">
                    <div><input type="text" name="content tag" class="filled" value="<?php $varkey = 'contenttag'; $velp->printvar($varkey,false,$contv); ?>"></div>
                    <div><input type="text" name="content tag attribute" class="filled" value="<?php $varkey = 'contenttagattr'; $velp->printvar($varkey,false,$contv); ?>"></div>
                    <div><input type="text" name="content tag attribute value" class="filled" value="<?php $varkey = 'contenttagattrvalue'; $velp->printvar($varkey,false,$contv); ?>"></div>
                    <div><input type="button" name="addcontent" class="addcontent" value="+"></div>
                    <div><input type="button" name="removecontent" class="removecontent" value="-"></div>
                </div>
            <?php
            }
        }
        else{
    ?>
            <div class="inputrow contentinput">
                <div><input type="text" name="content tag" value="content tag"></div>
                <div><input type="text" name="content tag attribute" value="content tag attribute"></div>
                <div><input type="text" name="content tag attribute value" value="content tag attribute value"></div>
                <div><input type="button" name="addcontent" class="addcontent" value="+"></div>
                <div><input type="button" name="removecontent" class="removecontent" value="-"></div>
            </div>
    <?php } ?>
    <div class="inputrow title" id="keywordstitle"><label>Keywords</label></div>
    <?php
        if(isset($pagevar['currentsource']) && $pagevar['currentsource']['downloadsetting'] != '' && count($downloadsettings['keywords'])){
            foreach($downloadsettings['keywords'] as $keyk=>$keyv){
            ?>
                <div class="inputrow keywordsinput">
                    <div><input type="text" name="keywords tag" class="filled" value="<?php $varkey = 'contenttag'; $velp->printvar($varkey,false,$keyv); ?>"></div>
                    <div><input type="text" name="keywords tag attribute" class="filled" value="<?php $varkey = 'contenttagattr'; $velp->printvar($varkey,false,$keyv); ?>"></div>
                    <div><input type="text" name="keywords tag attribute value" class="filled" value="<?php $varkey = 'contenttagattrvalue'; $velp->printvar($varkey,false,$keyv); ?>"></div>
                </div>
            <?php
            }
        }
        else{
    ?>
            <div class="inputrow keywordsinput">
                <div><input type="text" name="keywords tag" value="keywords tag"></div>
                <div><input type="text" name="keywords tag attribute" value="keywords tag attribute"></div>
                <div><input type="text" name="keywords tag attribute value" value="keywords tag attribute value"></div>
            </div>
    <?php } ?>
    <div class="inputrow title" id="excludetitle"><label>Exclude</label></div>
    <?php
        if(isset($pagevar['currentsource']) && $pagevar['currentsource']['downloadsetting'] != '' && count($downloadsettings['exclude'])){
            foreach($downloadsettings['exclude'] as $exck=>$excv){
                ?>
                    <div class="inputrow excludeinput">
                        <div><input type="text" name="exclude tag" class="filled" value="<?php $varkey = 'contenttag'; $velp->printvar($varkey,false,$excv); ?>"></div>
                        <div><input type="text" name="exclude tag attribute" class="filled" value="<?php $varkey = 'contenttagattr'; $velp->printvar($varkey,false,$excv); ?>"></div>
                        <div><input type="text" name="exclude tag attribute value" class="filled" value="<?php $varkey = 'contenttagattrvalue'; $velp->printvar($varkey,false,$excv); ?>"></div>
                        <div><input type="button" class="addexclude" value="+"></div>
                        <div><input type="button" name="removeexclude" class="removeexclude" value="-"></div>
                    </div>
                <?php
            }
        }
        else{
    ?>
            <div class="inputrow excludeinput">
                <div><input type="text" name="exclude tag" value="exclude tag"></div>
                <div><input type="text" name="exclude tag attribute" value="exclude tag attribute"></div>
                <div><input type="text" name="exclude tag attribute value" value="exclude tag attribute value"></div>
                <div><input type="button" class="addexclude" value="+"></div>
                <div><input type="button" class="removeexclude" value="-"></div>
            </div>
            <div class="inputrow excludeinput">
                <div><input type="text" name="exclude tag" value="exclude tag"></div>
                <div><input type="text" name="exclude tag attribute" value="exclude tag attribute"></div>
                <div><input type="text" name="exclude tag attribute value" value="exclude tag attribute value"></div>
                <div><input type="button" class="addexclude" value="+"></div>
                <div><input type="button" class="removeexclude" value="-"></div>
            </div>
            <div class="inputrow excludeinput">
                <div><input type="text" name="exclude tag" value="exclude tag"></div>
                <div><input type="text" name="exclude tag attribute" value="exclude tag attribute"></div>
                <div><input type="text" name="exclude tag attribute value" value="exclude tag attribute value"></div>
                <div><input type="button" class="addexclude" value="+"></div>
                <div><input type="button" class="removeexclude" value="-"></div>
            </div>
    <?php } ?>
    <input type="hidden" name="cscont" id="cscont" value="">
    <input type="hidden" name="csexc" id="csexc" value="">
    <input type="hidden" name="cskeywords" id="cskeywords" value="">
</div>

<div class="inputrow">
    <div class="submitdownloadsetting">
        <input type="submit" name="savesource" value="Save" class="submitform">
    </div>
</div
     
</form>