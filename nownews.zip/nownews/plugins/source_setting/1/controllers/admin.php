<?php

Class Admin_source_setting extends PluginController{
    function __construct($pluginid,$controllerpagevars) {
        parent::__construct($pluginid,$controllerpagevars);
    }
    public function pageInit($data=null){
        $this->setPagevar('currentp','admin');
        $this->setPagevar('selectednewssource',0);
        if(isset($data['savesource'])){
            $logo       = false;
            $postdata   = $data;
            switch($data['formmode']){
                case '0':
                    if(isset($data['cycle'])){
                        $created    = $this->model('newssource')->createNew($postdata['sourcename']);
                        if($created){
                            $new                    = $this->model('newssource')->insertid();
                            $postdata['sourceid']   = $data['sourceid'] = $new;
                            $updated                = $this->model('newssource')->updateSource($postdata['sourceid'],$postdata);

                            if($updated){
                                $response['message'] = 'New source successfully added';
                                $response['newsourceid'] = $new;
                            }
                            else{
                                $this->model('newssource')->deleterecords(array('id'=>$new));
                                $response['message'] = 'Failed adding new source';
                            }
                        }
                        else{
                            $response['message'] = 'Failed adding new source';
                        }
                    }

                    $data['sourceid'] = $data['sourceid'] != 0 ? $data['sourceid'] : $this->model('newssource')->getrecord(null,'id',array('id','desc'),1);
                    $thefile = false;
                    if(isset($_FILES) && count($_FILES)){
            			if($_FILES['file']['error'] == 0){
            			    $thefile = $_FILES['file'];
            			}
            		}
                    if($thefile !== false){
                        $thefile['sourcename']  = $data['sourcename'];
                        if(isset($_POST['filedescriptor'])){
        			        $descriptor = explode('|',$_POST['filedescriptor']);
        			        $thefile['type'] = $descriptor[0];
        			    }
        			    $logo       = $thefile;
                        $updated    = $this->model('newssource')->updateSource($data['sourceid'],false,$logo);
                        if($updated !== false){
                            $response['message'] = 'Logo update was successfull';
                        }
                        else{
                            $response['message'] = $this->model('newssource')->printerrors(false);
                        }
                    }
                    $this->setPagevar('ajax',true);
                    $this->setPagevar('response',$response);
                    return 'ajax';
                break;
                case '1':
                    if(isset($data['cycle'])){
                        $updated    = $this->model('newssource')->updateSource($data['sourceid'],$postdata);
                        if($updated){
                            $response['message'] = 'Update was successfull';
                        }
                        else{
                            $response['message'] = 'No changes was made';
                        }
                    }

                    $thefile = false;
                    if(isset($_FILES) && count($_FILES)){
            			if($_FILES['file']['error'] == 0){
            			    $thefile = $_FILES['file'];
            			}
            		}
                    if($thefile !== false){
                        $thefile['sourcename']  = $data['sourcename'];
                        if(isset($_POST['filedescriptor'])){
        			        $descriptor = explode('|',$_POST['filedescriptor']);
        			        $thefile['type'] = $descriptor[0];
        			    }
        			    $logo       = $thefile;
                        $updated    = $this->model('newssource')->updateSource($data['sourceid'],false,$logo);
                        if($updated !== false){
                            $response['message'] = 'Logo update was successfull';
                        }
                        else{
                            $response['message'] = $this->model('newssource')->printerrors(false);
                        }
                    }
                    $this->setPagevar('ajax',true);
                    $this->setPagevar('response',$response);
                    return 'ajax';
                break;
            }
        }

        $this->reports(false,true);
        $sourceasarray          = $this->model('newssource')->getSources(array('id','name','status'));
        $this->setPluginvar('source',$sourceasarray);

        if(Pxpedia::isLoggedin())
            return 'admin';
    }
    public function downloadSetting($data){
        if(isset($data['requestsource'])){
            $response['empty'] = false;
            $sourceasarray = $this->model('newssource')->getSource($data['sourceid']);
            if($sourceasarray['downloadsetting'] == ''){
                $response['empty'] = true;
                unset($sourceasarray['downloadsetting']);
                $response['descriptions'] = $sourceasarray;
            }
            else{
                $response['settings'] = $sourceasarray['downloadsetting'];
                unset($sourceasarray['downloadsetting']);
                $response['descriptions'] = $sourceasarray;
            }

            $this->setPagevar('ajax',true);
            $this->setPagevar('response',$response);

            return 'ajax';
        }

        if(isset($data['savedownloadsetting'])){

            return 'ajax';
        }

        return null;
    }
    public function addnew($data=false){
        if(isset($_POST['createnew'])){
            $this->setPagevar('selectednewssource',0);
            $logo = false;
            if($_FILES['sourcelogo']['error'] == 0){
                $logo = $_FILES['sourcelogo'];
            }
            $postdata   = $_POST;
            $created    = $this->model('newssource')->createNew($postdata['sourcename']);
            if($created){
                $new                    = $this->model('newssource')->insertid();
                $postdata['sourceid']   = $new;
                $updated                = $this->model('newssource')->updateSource($postdata,$logo);

                if($updated){
                    $this->setPagevar('message','New source successfully added');
                }
                else{
                    $this->model('newssource')->deleterecords(array('id'=>$new));
                    $this->setPagevar('message','Failed adding new source');
                }
            }
            else{
                $this->setPagevar('message','Failed adding new source');
            }
        }
        return 'addnew';
    }
    public function deleteSource($data){
        $response['deleted'] = 0;
        $response['message'] = 'server/db error';
        $deleted = $this->model('newssource')->deleteSource($data['sourceid']);
        if($deleted){
            if($this->model('newssource')->deletednum() == 1){
                $response['message'] = 'deleted succesfully';
                $response['deleted'] = 1;
            }
        }
        $this->setPagevar('response',$response);
        $this->setPagevar('ajax',true);
        return 'ajax';
    }
    public function reports($data=false,$home=false){
        $view = 'reports';
        if(!isset($data['request'])){
            list($reports['reports'],$reports['limit']) = $this->model('reports')->networkrelated($data);
        }
        else{
            list($reports['reports'],$reports['limit']) = $this->model('reports')->$data['request']($data);
            $this->setPagevar('ajax',true);
            $view = 'ajax';
        }
        if($home == true){
            $this->setPagevar('reports',$reports);
            return;
        }
        $this->setPagevar('currentp','reports');

        $this->setPagevar('response',$reports);
        return $view;
    }
    public function reportsnav($data=false){
        $view = 'ajax';
        $this->setPagevar('ajax',true);

        list($reports['reports'],$reports['limit']) = $this->model('reports')->$data['pagenavof']($data);
        $this->setPagevar('response',$reports);
        return $view;
    }
    public function deleteReport($data){
        $view = 'ajax';
        $this->setPagevar('ajax',true);

        $response = $this->model('reports')->deleteReport($data['errorid']);
        $this->setPagevar('response',$response);
        return $view;
    }
    public function test(){

    }
}
?>