<?php

Class Home_source_setting extends PluginController{
    function __construct($pluginid,$controllerpagevars) {
        parent::__construct($pluginid,$controllerpagevars);
        
    }
    public function pageInit($data=null){
        
        return 'home';
    }
    
}
?>