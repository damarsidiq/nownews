<div id="errornav">
    <select name="errortype" class="errortype" id="selecterrortype">
        <option value="networkrelated">network related</option>
        <option value="emptycontent">empty content</option>
        <option value="others">others</option>
    </select>
    
    <span class="errorpagenav next">next &rarr;</span>
    <span class="errorpagenav previous disabled">&larr; previous</span>
</div>

 <div class="errorline active head">
    <div class="rssid">rssid</div>
    <div class="thelog">Log (fetched content,log,sourceid)</div>
    <div class="thetime">Time</div>
    <div class="action">Actions</div>
</div>
 
 <div class="errorcontainer active" id="networkrelated">
    <?php foreach($pagevar['response']['reports'] as $errork=>$errorv){ ?>
        <div class="errorline active">
            <div class="errorid"><?php echo $errorv['id'] ?></div>
            <div class="rssid"><?php echo $errorv['rssid']; ?></div>
            <div class="thelog">
            <?php
                foreach($errorv['log'] as $lk=>$lv){
                    if($lv === false){
                        $errorv['log'][$lk] = 'false';
                    }
                }
                echo implode(',',$errorv['log']);
            ?>
            </div>
            <div class="thetime"><?php echo date('l, F jS Y, H:i:s',strtotime($errorv['time'])); ?></div>
            <div class="action"><span class="reportaction">&equiv;</span><span class="reportaction">X</span></div>
        </div>
    <?php } ?>
 </div>
 
<div class="errorcontainer" id="emptycontent"></div>

<div class="errorcontainer" id="others"></div>