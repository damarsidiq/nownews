<?php

Class Statistics extends Controller{
    function __construct() {
        parent::__construct();
    }
    
    public function onlinecharts($data){
        $this->setPagevar('ajax',true);
        $charttype  = $data['type'];
        $startp     = $data['startp'] == 'Very early' ? 0 : $data['startp'];
        $endp       = $data['endp'] == 'Now' ? 0 : $data['endp'];
        $data       = array();
        $dataset    = false;
        
        switch($charttype){
            case 'articledownload':
                list($data,$dataset) = $this->topdownloads($startp,$endp);
            break;
            case 'newssourcedownload':
                $data = $this->topsource($startp,$endp);
            break;
            case 'trendingkeywords':
                $data = $this->keywordstrend($startp,$endp);
            break;
        }
        
        $response['data'] = $data;
        $response['dataset'] = $dataset;
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    
    public function topdownloads($startdate,$enddate){
        $model  = $this->model('statmodel')->topArticles($startdate,$enddate);
        $data   = array();
        foreach($model as $datak=>$datav){
            $idx = count($data);
            
            $titlex = explode(' ',$datav['title']);
            $title = '';
            foreach($titlex as $titlek=>$titlev){
                $title.=$titlev.' ';
                if(strlen($title) > 31){
                    break;
                }
            }
            if(strlen($datav['title']) > strlen($title)){
                $title .= '...';
            }
            
            $data[$idx][] = $title;
            $data[$idx][] = $datav['downloadcount'];
        }
        return array($data,$model);
    }
    
    public function topsource($startdate,$enddate){
        $model  = $this->model('statmodel')->topSource($startdate,$enddate);
        $data   = array();
        foreach($model as $datak=>$datav){
            $idx = count($data);
            $data[$idx][] = $datav['name'];
            $data[$idx][] = $datav['totalsourcedownload'];
        }
        return $data;
    }
    
    public function keywordstrend($startdate,$enddate){
        $model  = $this->model('statmodel')->topKeywords($startdate,$enddate);
        $data   = array();
        foreach($model as $datak=>$datav){
            $idx = count($data);
            $data[$idx][] = $datav['keyword'];
            $data[$idx][] = $datav['trending'];
        }
        return $data;
    }
    
}