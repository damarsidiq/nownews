<?php
Class Paragraphcounter extends Controller{
    var $maxpc;
    var $maxpcelem;
    function __construct(){
        parent::__construct();
    }
    public function getContent($articlehtml,$sourcesetting,$rssitem){
        $newscontent = '';
        $nodeexclude = count($sourcesetting['exclude']) ? $sourcesetting['exclude'] : null;
        if(!empty($sourcesetting['keywords'])){
            $keywords       = $this->model('keywords')->extractkeywords($articlehtml,$sourcesetting['keywords']);
        }
        
        $this->maxpc = 0;
        $this->maxpcelem = false;
        foreach($articlehtml as $k=>$v){
            if(isset($v['elements']) && count($v['elements'])){
                $articlehtml[$k]['pcount'] = $this->paragraphcount($v);   
            }
        }
        if($this->maxpcelem !== false){
            $articlehtml    = $this->maxpcelem;
            $articlehtml['elements'] = $this->model('downloadedrss')->fiximageurl($rssitem,$articlehtml['elements']);
            $newscontent    = trim(Pxpedia::xmlcontent('',$articlehtml,'',true,$nodeexclude));
        }
        else{
            $this->maxpc = 0;
            $this->maxpcelem = false;
            
            foreach($articlehtml as $k=>$v){
                if(isset($v['elements']) && count($v['elements'])){
                    $articlehtml[$k]['pcount'] = $this->divcount($v);   
                }
            }
            
            if($this->maxpcelem !== false){
                $articlehtml    = $this->maxpcelem;
                $articlehtml['elements'] = $this->model('downloadedrss')->fiximageurl($rssitem,$articlehtml['elements']);
                $newscontent    = trim(Pxpedia::xmlcontent('',$articlehtml,'',true,$nodeexclude));
            }
        }
        
        return $newscontent;
    }
    public function paragraphcount($parent,$pc=0){
        foreach($parent['elements'] as $k=>$v){
            if($v['attribute'][0]=='p'){
                $pc++;
            }
            elseif(isset($v['elements']) && count($v['elements'])){
                $elements[$k]['pcount'] = $this->paragraphcount($v);   
            }
        }
        if($this->maxpc < $pc){
            $this->maxpc = $pc;
            $this->maxpcelem = $parent;
        }
        return $pc;
    }
    public function divcount($parent,$pc=0){
        foreach($parent['elements'] as $k=>$v){
            if($v['attribute'][0]=='div'){
                $pc++;
            }
            elseif(isset($v['elements']) && count($v['elements'])){
                $elements[$k]['pcount'] = $this->paragraphcount($v);   
            }
        }
        if($this->maxpc < $pc){
            $this->maxpc        = $pc;
            $this->maxpcelem    = $parent;
        }
        return $pc;
    }
}

?>