<?php 
Class Bulktest extends Controller{
	function __construct(){
		parent::__construct();
	}
	
	public function fixdb($data){
	    $w = $this->query('delete from downloadedrss where id not in(select rssid from news)');
	}
}
