<?php 
Class Syncapp extends Controller{
    var $config;
	function __construct(){
		parent::__construct();
		$this->syncconfig();
	}
	public function syncconfig($data=false){
	    $this->config['sync'] = array('app','view','res','plugin','appconfig','extra:syncreq');
	}
	public function getconfig(){
	    echo json_encode($this->config['sync']);
	    return 'plain';
	}
	public function syncreq($data){
	    $adapteddata = array('u'=>$data['url']);
	    return $this->controller('import')->import($adapteddata);
	}
}
