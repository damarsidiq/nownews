<?php

Class NewslettersCron extends Controller{
    var $rss;
    var $source;
    var $newsletters;
    var $newslettersettings;
    var $newsletterrss;
    var $tempnewslettersource;
    var $updatedownloadcount;
    
    function __construct() {
        parent::__construct();
        
        $this->rss                  = array();
        $this->tempnewslettersource = array();
        $this->newsletterrss        = array();
        $this->updatedownloadcount  = array();
        $this->newsletters = array();
    }
    public function pageInit($data=null,$view='newslettercron'){
        $this->setPagevar('ajax',true);
        
        list($this->newslettersettings,$this->newsletters) = $this->model('newslettersettings')->newsletterToUpdate();
        if(!empty($this->newslettersettings)){
            foreach($this->newslettersettings as $key=>$this->tempnewslettersource){
                $this->tempnewslettersource     = $this->processNewsletterRss($this->tempnewslettersource);
                $this->newslettersettings[$key] = $this->tempnewslettersource;
            }
            
            if(count($this->newsletterrss)){
                $this->downloadNewslettersContents();
                $this->sendNewsletters(); 
                $this->model('newslettersettings')->updateNextFetch($this->newslettersettings);
                
                $this->setPagevar('message','Newsletter Sent');
            }
            else{
                $this->setPagevar('message','0 Newsletter Items Found');
            }
        }
        return $view;
    }
    public function updatedownloadcount(){
        $this->model('downloadedrss')->updateDownloadCountNewsletter($this->updatedownloadcount);
        $this->updatedownloadcount = array();
    }
    public function addtoupdatedownloadcount($newslettersettingk){
        if(!empty($this->updatedownloadcount)){
            foreach($this->newsletterrss[$newslettersettingk]['rssitems'] as $rssitemk=>$rssitem){
                if(!in_array($rssitem['id'],$this->updatedownloadcount)){
                    $this->updatedownloadcount[] = $rssitem['id'];
                }
            }
        }
        else{
            foreach($this->newsletterrss[$newslettersettingk]['rssitems'] as $rssitemk=>$rssitem){
                $this->updatedownloadcount[] = $rssitem['id'];
            }
        }
    }
    public function sendNewsletters(){
        $currentemail   = $this->newsletters[0]['email'];
        $currentcontent = '';
        $emailmessage   = '';
        foreach($this->newsletters as $newsletterkey=>$newsletter){
            foreach($this->newsletterrss as $newslettersettingk=>$newslettersettingv){
                if($newsletter['source'] == $newslettersettingv['source'] && $newsletter['category'] == $newslettersettingv['category'] && $newsletter['keywords'] == $newslettersettingv['keywords']){
                    $sourcename         = $this->model('newssource')->sourceName($newsletter['source']);
                    $categoriesnames    = $this->model('category')->categoryName($newsletter['category']);
                    
                    $keywordsmessage    = $newsletter['keywords'] == '' ? 'none' : $newsletter['keywords'];
                    $categoriesnames    = $categoriesnames == '' ? 'All' : $categoriesnames;
                    $emailmessage       .= "Source: ". $sourcename .", Category: ".$categoriesnames ." , Keywords: ". $keywordsmessage . "<br/>";
                    
                    if(!empty($this->newsletterrss[$newslettersettingk]['rssitems'])){
                        $emailmessage.= count($this->newsletterrss[$newslettersettingk]['rssitems']).' results found'."<br/><br/>";
                        if(!isset($newslettersettingv['pdf'])){
                            $this->createPdfContent($newslettersettingk);
                        }
                        $currentcontent .= $this->newsletterrss[$newslettersettingk]['pdf'];                        
                    }
                    else{
                        $emailmessage.= '0 results found'."<br/><br/>";
                    }
                }
            }
            
            if(($newsletterkey+1) == count($this->newsletters) || $currentemail !== $this->newsletters[$newsletterkey+1]['email']){
                $this->sendSubscription($this->newsletters[$newsletterkey]['newsletterid'],$currentemail,$currentcontent,$emailmessage);
                $currentcontent = '';
                $emailmessage   = '';
            }
        }
    }
    public function sendSubscription($newsletterid,$email,$content,$summary){
        $pdffile            = $this->model('newspdf')->savePdf($newsletterid,$content);
        $rn                 = "rn";
        $boundary           = md5(rand());
        $boundary_content   = md5(rand());
        $msg                = '';
        
        $subject    = 'nownews.org News Subscription';
        $from       = 'nownews.org <newslettersubscription@nownews.org>';
        
        $headers  = "MIME-Version: 1.0" . "rn"; 
        $headers .= 'Content-Type: multipart/related;boundary=' . $boundary . $rn;
        $headers .= "From: $from" . $rn;
        
        $msg .= $rn . "--" . $boundary_content . $rn;
        $msg .= 'Content-Type: text/html; charset=ISO-8859-1' . $rn;
        $msg .= 'Content-Transfer-Encoding: quoted-printable' . $rn;
        
        $msg .= 'News Subscription for Nownews.org :'. "rn" .$summary;
        $msg .= $rn . '--' . $boundary_content . '--' . $rn;
        
        
        $msg .= $rn . '--' . $boundary . $rn;
        
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $ftype = finfo_file($finfo, $pdffile);
        $file = fopen($pdffile, "r");
        $attachment = fread($file, filesize($pdffile));
        $attachment = chunk_split(base64_encode($attachment));
        fclose($file);
        $msg = 'Content-Type: ' . $ftype . $rn. ' name="' . basename($pdffile) . '"' . $rn;
        $msg .= "Content-Transfer-Encoding: base64" . $rn;
        $msg .= 'Content-ID: <' . basename($pdffile) . '>' . $rn;
        $msg .= $rn . $attachment . $rn . $rn;

        $msg .= $rn . '--' . $boundary . '--' . $rn;
        
        echo $summary;
        
        //mail($email, $subject, $msg, $headers);
        
        $this->updatedownloadcount();
    }
    public function createPdfContent($index){
        foreach($this->newsletterrss[$index]['rssitems'] as $rssitemk=>$rssitemv){            
            $rssitemv['publisher']   = $this->model('newssource')->sourceName($rssitemv['newssource']);
            $rssitemv['categories']  = $this->model('category')->categoryName($rssitemv['category'],$rssitemv['tags']);
            
            $this->model('newspdf')->newsitem($rssitemv);
        }
        $this->addtoupdatedownloadcount($index);
        $this->newsletterrss[$index]['pdf'] = $this->model('newspdf')->pdfContent(true);
    }
    public function downloadPreceded($source,$indx,$predecesscat){
        $precededstart = $indx+1;
        for($i=$precededstart;$i<count($this->newsletterrss);$i++){
            if($this->newsletterrss[$i]['source'] == $source ){
                if(is_array($this->newsletterrss[$i]['rssitems']) && !empty($this->newsletterrss[$i]['rssitems']) && $predecesscat == 0 ){
                    $filtereditems = array();
                    foreach($this->newsletterrss[$i]['rssitems'] as $key=>$val){
                        $rssidx = false;
                        foreach($this->newsletterrss[$indx]['rssitems'] as $dk=>$dv){
                            if($dv['id'] == $val['id']){
                                $rssidx = $dk;
                                if($this->newsletterrss[$i]['keywords'] != ''){
                                     $keywordsx = explode(',',$this->newsletterrss[$i]['keywords']);
                                     foreach($keywordsx as $keyidx=>$keyval){
                                         $keywordsx[$keyidx] = strtolower(trim($keyval));
                                     }
                                            
                                    $keyfilteredpass = false;
                                    foreach($keywordsx as $keyidx=>$keyval){
                                        if(in_array( $keyval ,$this->newsletterrss[$indx]['rssitems'][$rssidx]['keywords'])){
                                            $keyfilteredpass = true;
                                            break;
                                        }
                                    }
                                    if($keyfilteredpass)
                                        $rssidx = false;
                                }
                                break;
                            }
                        }
                        if($rssidx !== false){
                            $filtereditems[] = $this->newsletterrss[$indx]['rssitems'][$rssidx];
                        }
                    }
                    $this->newsletterrss[$i]['rssitems'] = $filtereditems;
                }
                else{
                    if(is_array($this->newsletterrss[$i]['rssitems']) && empty($this->newsletterrss[$i]['rssitems'])){
                        continue;
                    }
                    
                    if($predecesscat != 0 && $predecesscat != $this->newsletterrss[$i]['category']){
                        continue;
                    }
                    
                    $twinidx                                = (int)$this->newsletterrss[$i]['rssitems'];
                    $this->newsletterrss[$i]['rssitems']    = array();
                    
                    if(!empty($this->newsletterrss[$twinidx]['rssitems'])){
                        $keywordsx = explode(',',$this->newsletterrss[$i]['keywords']);
                        foreach($keywordsx as $keyidx=>$keyval){
                            $keywordsx[$keyidx] = strtolower(trim($keyval));
                        }
                        
                        foreach($this->newsletterrss[$twinidx]['rssitems'] as $key=>$val){
                            if(!empty($val['keywords'])){
                                foreach($keywordsx as $keyidx=>$keyval){
                                    if(in_array( $keyval ,$val['keywords'])){
                                        $this->newsletterrss[$i]['rssitems'][] = $val;
                                    }
                                }   
                            }
                        }   
                    }
                }
            }
            else{
                break;
            }
        }
    }
    public function getKeys($rssitems){
        foreach($rssitems as $rk=>$rv){
            $rssitems[$rk]['keywords'] = $this->model('news')->getKeywords($rv['newsid']);
        }
        return $rssitems;
    }    
    public function downloadNewslettersContents(){
        foreach($this->newsletterrss as $newsletk=>$newsletv){
            if( is_array($newsletv['rssitems']) ){
                if(empty($newsletv['rssitems']))
                    continue;
                
                list($todownload,$alreadydownloaded,$downloadedcount) = $this->model('news')->newsletterFlagDownloaded($newsletv['rssitems']);
                if($downloadedcount < count($newsletv['rssitems'])){
                    foreach($todownload as $todownk=>$todownval){
                        $todownload[$todownk] = $this->downloadArticle($todownval);
                    }
                    if(!empty($alreadydownloaded)){
                        $alreadydownloaded = $this->getKeys($alreadydownloaded);
                    }
                    $this->newsletterrss[$newsletk]['rssitems'] = array_merge($todownload,$alreadydownloaded);   
                }
                else{
                    $alreadydownloaded = $this->getKeys($alreadydownloaded);
                    $this->newsletterrss[$newsletk]['rssitems'] = $alreadydownloaded;
                }
                if($newsletv['keywords'] != ''){
                    $this->newsletterrss[$newsletk]['rssitems'] = $this->filterByKeywords($newsletv['keywords'],$this->newsletterrss[$newsletk]['rssitems']);
                }
                else{
                    $this->downloadPreceded($newsletv['source'],$newsletk,$newsletv['category']);   
                }
            }
        }
    }
    public function filterByKeywords($keywords,$rssitems){
        $filtereditems  = array();
        $keywordsx      = explode(',',$keywords);
        foreach($rssitems as $key=>$val){
            if(!empty($val['keywords'])){
                foreach($keywordsx as $kk=>$kv){
                    if(in_array($kv,$val['keywords'])){
                        $filtereditems[] = $val;
                    }
                }
            }
        }
        return $filtereditems;
    }
    public function processNewsletterRss($newslettersource){
        if(isset($this->rss[$newslettersource['source']])){
            $this->filterNewsletterRss();
        }
        else{
            $this->rss[$newslettersource['source']] = array();
            if($this->model('source')->fetchCurrent($newslettersource['source'])){
                list($this->rss[$newslettersource['source']],$lastfetched) = $this->updateRss($newslettersource['source']);
            }
            
            if(empty($this->rss[$newslettersource['source']])){
                list($this->rss[$newslettersource['source']],$lastfetched) = $this->oldcycle($newslettersource);
            }
            $newslettersource['lastfetched'] = $lastfetched;
            
            $this->filterNewsletterRss();
        }
        return $newslettersource;
    }
    public function filterNewsletterRss(){
        $oldidx = false;
        if(!empty($this->newsletterrss) && $this->tempnewslettersource['keywords'] == ''){
            foreach($this->newsletterrss as $nrk=>$nrv){
                if($nrv['source'] == $this->tempnewslettersource['source'] && $nrv['category'] == $this->tempnewslettersource['category']){
                    $oldidx = $nrk;   
                }
            }
        }
        
        $idx = count($this->newsletterrss);
        $this->newsletterrss[$idx] = array();
         
        $this->newsletterrss[$idx]['source']    = $this->tempnewslettersource['source'];
        $this->newsletterrss[$idx]['category']  = $this->tempnewslettersource['category'];
        $this->newsletterrss[$idx]['keywords']  = $this->tempnewslettersource['keywords'];
        $this->newsletterrss[$idx]['rssitems']  = array();
         
        if($oldidx === false){
            if($this->tempnewslettersource['category'] == 0){
                $this->newsletterrss[$idx]['rssitems'] = $this->rss[$this->tempnewslettersource['source']];
            }
            else{
                foreach($this->rss[$this->tempnewslettersource['source']] as $rssk=>$rssv){
                    if($rssv['category'] == $this->tempnewslettersource['category']){
                        $this->newsletterrss[$idx]['rssitems'][]  = $rssv;
                    }
                    else{
                        if(!empty($rssv['tags']) && in_array($this->tempnewslettersource['category'],$rssv['tags']) ){
                            $this->newsletterrss[$idx]['rssitems'][]  = $rssv;    
                        }
                    }
                }
            }
        }
        else{
            $this->newsletterrss[$idx]['rssitems'] = $oldidx;
        }
    }
    public function oldcycle($source){
        list($rss,$lastfetched) = $this->model('downloadedrss')->newsletterRss($source);
        
        return array($rss,$lastfetched);
    }
    public function downloadArticle($rssitem){
        $rssitem['newssource']  = 5;
        $rssitem['link']        = 'uploads/nownews/msnbcsample.html';
        
        $sourcesetting  = $this->model('newssource')->getSettings($rssitem['newssource']);
        $articlehtml    = Pxpedia::parsexml($rssitem['link'],false,true);
        
        if($articlehtml === false){
            $this->model('reports')->addreport($rssitem,false,'fopen error');
            return '';
        }
        
        $nodeexclude    = count($sourcesetting['exclude']) ? $sourcesetting['exclude'] : null;
        $contentnode    = $sourcesetting['thecontent'];
        
        $newscontent = '';
        foreach($contentnode as $contentk=>$contentv){
            $node = $contentv;
            
            $articlebody    = Pxpedia::xmldata($node,'',$articlehtml);
            if(count($articlebody)){
                if(!empty($sourcesetting['keywords']))
                    $keywords       = $this->model('keywords')->extractkeywords($articlehtml,$sourcesetting['keywords']);
                
                $articlebody    = $this->model('downloadedrss')->fiximageurl($rssitem,$articlebody);
                $newscontent    = trim(Pxpedia::xmlcontent('',$articlebody,'',true,$nodeexclude));
                break;
            }
        }
        
        $rssitem['newscontent'] = $newscontent;
        
        if($newscontent !== ''){
            $this->model('news')->saveNews($newscontent,$rssitem['id']);
            $rssitem['newsid']      = $this->model('news')->insertid();
            
            if(isset($keywords) && count($keywords)){
                list($keyids,$keywords) = $this->model('keywords')->addKeywords($keywords);
                $rssitem['keywords']    = $keywords;
                
                $this->model('keytonews')->addNewsKeywords($this->model('news')->insertid(),$keyids);
            }        
            return $rssitem;
        }
        else{
            $this->model('reports')->addreport($rssitem,$newscontent);
        }
    }
    public function rsscategories($categories,$downloaded){
        if(is_array($categories)){
            $exists = false;
            foreach($categories as $ck=>$cv){
                if($categories[$ck]['id'] === $downloaded){
                    $exists = true;
                }
            }
            if(!$exists){
                $categories[] = $this->model('category')->getrecord(array('id'=>$downloaded));
            }
        }
        else{
            $categories = array();
            $categories[] = $this->model('category')->getrecord(array('id'=>$downloaded));
        }
        return $categories;
    }
    public function updateRss($sourceid){
        $source                 = $this->model('source')->getSource($sourceid);
        $source['categories']   = $this->model('category')->getBySource($sourceid);
        $rss                    = $this->model('source')->getRss($source);
        $youngestpubdate        = 0;
        
        if(!empty($rss))
        foreach($rss as $k=>$v){
            $pubdatetime = strtotime($rss[$k]['pubDate']);
            if($youngestpubdate < $pubdatetime){
                $youngestpubdate = $pubdatetime;
            }
            
            if(!isset($v['category']) || $v['category'] === '')
                $v['category'] = 'Uncategorized';
            
            if(count($v['category']) > 1){                    
                foreach($v['category'] as $vk=>$vv){
                    $tag                    = $v['category'][$vk];
                    $tagid                  = $this->model('category')->getId($tag,$source['id'],true);
                    $source['categories']   = $this->rsscategories($source['categories'],$tagid);
                    
                    $rss[$k]['tags'][]      = $tagid;
                    $v['tags'][]            = $tagid;
                }
                $rss[$k]['category']    = $tagid;
                $v['category']          = $tagid;
            }
            else{
                if(!isset($v['category'][0])){
                    $v['category'][0] = 'Uncategorized';
                }
                $v['category']          = $v['category'][0];
                $categoryid             = $this->model('category')->getId($v['category'],$source['id'],true);
                $source['categories']   = $this->rsscategories($source['categories'],$categoryid);
                
                $rss[$k]['tags']        = array();
                $v['tags']              = array();
                
                $rss[$k]['category']    = $categoryid;
                $v['category']          = $categoryid;
            }
            
            $rss[$k]['newssource']  = $source['id'];
            $v['newssource']        = $source['id'];
            $rss[$k]['pubDate']     = date('l, F jS Y H:i:s',$pubdatetime);
            $rss[$k]['creator']     = $rss[$k]['dc:creator'];
            
            unset($rss[$k]['dc:creator']);
            
            $newsitem               = $this->model('downloadedrss')->saveNewsItem($v,$source['id']);
            if($newsitem !== false){
                $rss[$k]['id']      = $newsitem;
            }
            else{
                unset($rss[$k]);
            }
        }
        if($youngestpubdate !==0)
            $this->model('source')->updateLastFetched($source['id'],date('Y-m-d H:i:s',$youngestpubdate));
            
        return array($rss,$youngestpubdate);
    }
    
}