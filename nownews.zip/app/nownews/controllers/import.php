<?php 

Class Import extends Controller{
     var $offset;
    function __construct() {
        parent::__construct();
        $this->offset = 0;
    }
    public function pageInit($data){
        if(!isset($data['offset'])){
            $offset = 0;
        }
        else{
            $offset = (int) $data['offset'];
        }
        
        if(substr($data['syncurl'],-1) !== '/'){
            $data['syncurl'] .= '/';
        }
        $theurl = $data['syncurl'].'?app=nownews&p=import&a=getdata&d='.$offset;
        
        if(substr($theurl,0,5) !== 'http:'){
            $theurl = 'http://'.$theurl;
        }
        
        
        $rssdata = file_get_contents($theurl);
        $return = json_decode($rssdata,true);
        
        
        if(!is_array($return)){
            
            echo '------------';
            echo print_r($return,true).'---1---';
            return 'plain';
        }
        $rss = $return['rss'];
        
        
        $countsaved = 0;
        foreach($rss as $rk=>$rv){
            $news = $rv['news'];
            $source = $rv['newssource'];
            
            unset($rv['news']);
            
            $rv['category'] = $this->model('category')->getId($rv['catname'],$source);
            unset($rv['catname']);
            
            $keywords = $rv['keywords'];
            unset($rv['keywords']);
            
            $newsimages = $rv['newsimages'];
            unset($rv['newsimages']);
            
            $rssid = $this->model('downloadedrss')->saveNewsItem($rv,$source);
            if($rssid === false){
                $rssid = $this->fetchQueryResult($this->query('select id from downloadedrss where link ="'. $rv['link'] .'"'));
                if(count($rssid)===1)
                    $rssid = $rssid[0]['id'];
                else
                    $rssid = false;
            }
            if($rssid !== false){
                $saved = $this->model('news')->saveNews($news,$rssid);
                
                if($saved){
                    $countsaved += 1;
                    
                    
                    foreach($newsimages as $kkk=>$vvv){
                        $filenamex = explode('/',$vvv);
                        $filename = $filenamex[count($filenamex)-1];
                        $imgimport = $this->model('newsimages')->importimage('http://'.$data['u'].$vvv.'.png',$rssid,$filename);
                        if($imgimport === 0){
                            echo $imgimport.'###############';
                            return 'plain';
                        }
                        else{
                            echo $imgimport.'<br/>';
                        }
                    }
                    
                    
                    list($keyids,$arr) = $this->model('keywords')->addKeywords($keywords);
                    $this->model('keytonews')->addNewsKeywords($saved,$keyids);
                }   
            }
        }
        
        echo 'saved : '.$countsaved.'<br/>';
        
        if(!$return['done']){
            $param = array( 'u'=>$data['u'],'offset'=>($offset+30) );
            return $this->import($param);   
        }
        else{
            echo $this->model('downloadedrss')->printerrors(false).'---2---';
            return 'plain';
        }
    }
    
     public function getdata($data){
        $offset = $data;
        $response['rss']    = $this->fetchQueryResult($this->query('select d.id as therssid,d.title,d.description,d.pubDate,d.creator,d.link,d.guid,d.newssource,n.news,n.id as newsid,c.name as catname from category c,downloadedrss d,news n where d.id = n.rssid and c.id = d.category limit '.$offset.',31'));
        $response['done'] = count($response['rss']) > 30 ? false : true;
        
        if(!$response['done']){
            unset($response['rss'][30]);
        }
        
        foreach($response['rss'] as $rkey=>$rval){
            $keywords =array();
            $keyvals = $this->fetchQueryResult($this->query('select keyword from keywords where id in (select keyid from keytonews where newsid = '. $rval['newsid'] .')'));
            foreach($keyvals as $keyvalk=>$keyvalval){
                $keywords[] = $keyvalval['keyword'];
            }
            $response['rss'][$rkey]['keywords'] = $keywords;
            
            
            $newsimages = array();
            $newsimagesvals = $this->fetchQueryResult($this->query('select * from newsimages where rssid='.$rval['therssid']));
            foreach($newsimagesvals as $keyvalk=>$keyvalval){
                $newsimages[] = str_replace(array('./'),array(''),App::getConfig('uploads').'newsimages/'.$keyvalval['filename']);
            }
            $response['rss'][$rkey]['newsimages'] = $newsimages;
            
            unset($response['rss'][$rkey]['newsid']);
            unset($response['rss'][$rkey]['therssid']);
        }
        
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function fiximage($data=false){
        $rec = $this->model('newsimages')->getrecords(null,null,array('id','desc'),array($this->offset,100));
        if(count($rec)){
            foreach($rec as $l=>$v){
                $this->model('newsimages')->updaterecord(array('filename'=>$v['id']),array('id'=>$v['id']));
            }
            $this->offset += 100;
            $this->fiximage();
        }
    }
}

?>