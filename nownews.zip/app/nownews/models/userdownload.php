<?php

Class Userdownload extends Model{
    function __construct(){
        parent::__construct('userdownload');
    }
    
    public function addDownload($rssids,$userid,$status){
        if(is_array($rssids))
            $rssid = implode(',',$rssids);
        else
            $rssid = $rssids;
        
        $reqtime = date('Y-m-d H:i:s',time());
        
        $saved = $this->addrecord(array('rssids','userid','status','request_time'),array($rssid,$userid,$status,$reqtime));
        return $saved;
    }
    
    public function getItem($downloadid){
        $downloaditem = $this->getrecord(array('id'=>$downloadid));
        return $downloaditem;
    }
    
    public function updateStatus($downloadid,$status){
        $this->updaterecord(array('status'=>$status),array('id'=>$downloadid));
    }
    
    public function updateRssid($downloadid,$rssid){
        if(is_array($rssid))
            $rssids = implode(',',$rssid);
        else
            $rssids = $rssid;
        
        $oldrssids = $this->getrecord(array('id'=>$downloadid),array('rssids'));
        $rssids = $oldrssids.','.$rssids;
        
        $this->updaterecord(array('rssids'=>$rssids),array('id'=>$downloadid));
    }
    
}


?>