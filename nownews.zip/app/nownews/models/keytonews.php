<?php

Class Keytonews extends Model{
    function __construct(){
        parent::__construct('keytonews');
    }
    public function getNewsWithKeys($keyids,$sourceid=false){
        $newsids = $this->getrecords(array('keyid'=>array('in',$keyids)));
        return $newsids;
    }
    public function addNewsKeywords($newsid,$keywordids){
        foreach($keywordids as $keywordidk=>$keywordid){
            $this->addrecord(array('newsid','keyid'),array($newsid,$keywordid));
        }
    }
    
    
}


?>