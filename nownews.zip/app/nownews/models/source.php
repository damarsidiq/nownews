<?php

Class Source extends Model{
    var $source = null;
    function __construct(){
        parent::__construct('newssource');
    }
    public function getSources($fields=null,$num=30,$offset=0){
        if($offset === 0){
            return array($this->getrecords(array('status'=>1),$fields,array('id','ASC'),$offset.','.$num),$this->countrows(array('status'=>1)));
        }
        return $this->getrecords(array('status'=>1),$fields,array('id','ASC'),$offset.','.$num);
    }
    public function getSource($sourceid){
        $source = $this->getrecord(array('id'=>$sourceid));
        $this->source = $source;
        return $source;
    }
    public function updateLastFetched($sourceid,$date=false){
        if($date === false)
            $date = date('Y-m-d H:i:s',time());
            
        $this->updaterecord(array('lastfetched'=>$date),array('id'=>$sourceid));
    }
    public function getLastFetched($sourceid){
        $source = $this->getrecord(array('id'=>$sourceid),'lastfetched');
        return $source;
    }
    public function fetchCurrent($source){
        if(!is_array($source)){
            $source = $this->getSource($source);
        }
        
        $fetchcurrent   = false;
        $now            = date('Y-m-d',time());
        $lastfetched    = date('Y-m-d',strtotime($source['lastfetched']));
        $ageindays      = (strtotime($now) - strtotime($lastfetched))/(3600*24);
        
        
        if($source['cycle'] === 'daily'){
            if($ageindays >1 ){
                $fetchcurrent = true;
            }
        }
        elseif($source['cycle'] === 'monthly'){
            if($ageindays >=30){
                $fetchcurrent = true;
            }
        }
        elseif($source['cycle'] === 'bimonthly'){
            if($ageindays >=60){
                $fetchcurrent = true;
            }
        }
        elseif($source['cycle'] === 'weekly'){
            if($ageindays >7){
                $fetchcurrent = true;
            }
        }
        else{
            $fetchcurrent = true;
        }
        
        return $fetchcurrent;
    }
    public function getRss($source,$debug=false){
        if($debug){
            if(strpos($source['url'],'http:') === false){
                $source['url']    = 'uploads/nownews/feedsample/'.$source['url'];
                $rssdata            = Pxpedia::parsexml($source['url'],false,false);
            }
            else{
                $rssdata            = Pxpedia::parsexml($source['url'],false,false,true);
            }
            
            
            if($rssdata === false){
                return false;
            }
            if(!empty($rssdata)){
                $rss                        = Pxpedia::xmldata('item','channel',$rssdata);
                if(empty($rss)){
                    $rss                        = Pxpedia::xmldata('item','rdf:RDF',$rssdata);
                }
                $newsitem                   = array();
            
                foreach($rss as $itemkey => $itemval){
                    $newsitem[] = $this->newsItem($itemval);
                }
                uasort($newsitem,function($a,$b){
                    if($a['pubDate'] < $b['pubDate'])
                        return -1;
                    elseif($a['pubDate'] == $b['pubDate'])
                        return 0;
                    else
                        return 1;
                });
                return $newsitem;
            }
            return array();
        }
        $this->source = $source;
        $rssdata        = Pxpedia::parsexml($source['url'],false,false,true);
        if($rssdata === false){
            return false;
        }
        if(!empty($rssdata)){
            $rss = Pxpedia::xmldata('item','channel',$rssdata);
            if(empty($rss)){
                $rss = Pxpedia::xmldata('item','rdf:RDF',$rssdata);
            }
            $newsitem = array();
            
            foreach($rss as $itemkey => $itemval){
                $newsitem[] = $this->newsItem($itemval);
            }
            uasort($newsitem,function($a,$b){
                if($a['pubDate'] < $b['pubDate'])
                    return -1;
                elseif($a['pubDate'] == $b['pubDate'])
                    return 0;
                else
                    return 1;
            });
            return $newsitem;
        }
        return array();
    }
    public function sortbypubdate($a,$b){
        if($a['pubDate'] < $b['pubDate'])
            return -1;
        elseif($a['pubDate'] == $b['pubDate'])
            return 0;
        else
            return 1;
    }
    public function sourceurl(){
        if(!isset($this->source['sourceurl'])){
            $urlx = explode('/',str_replace('http://','',$this->source['url']));
            $url = 'http://'.$urlx[0];
            $this->source['sourceurl'] = $url;            
        }
        return $this->source['sourceurl'];
    }
    public function newsItem($xmltree){
        $news = array(
                      'title'=>'',
                      'link'=>'',
                      'category'=>'',
                      'guid'=>'',
                      'pubDate'=>'',
                      'dc:creator' => '',
                      'description'=>''
                );
        foreach($news as $key=>$val){
            if($key == 'category'){
                $categories = Pxpedia::xmldata('category','',$xmltree);
                if($categories === ''){
                    $categories = Pxpedia::xmldata('subject','',$xmltree);
                }
                $news['category'] = array();
                foreach($categories as $ck=>$cv){
                    $news['category'][] = Pxpedia::xmlcontent($key,$cv,$val,false);
                }
                if(count($news['category']) == 1 && strpos($news['category'][0],',') !== false){
                    $news['category'] = explode(',',$news['category'][0]);
                }
            }
            elseif($key == 'link' || $key == 'guid'){
                $val = Pxpedia::xmlcontent($key,$xmltree,$val,false);
                if(strpos($val,'http://') === false && substr($val,0,1) == '/'){
                    $news[$key] = $this->sourceurl().$val;
                }
                else{
                    $news[$key] = $val;
                }
            }
            elseif($key == 'dc:creator'){
                $creator = Pxpedia::xmlcontent($key,$xmltree,$val,false);
                if($creator == ''){
                    $creator = Pxpedia::xmlcontent('author',$xmltree,$val,false);
                    if($creator == ''){
                        $creator = Pxpedia::xmlcontent('name',$xmltree,$val,false);
                        if($creator == ''){
                            $creator = 'Unknown';
                        }
                    }
                }
                $news[$key] = $creator;
            }
            elseif($key == 'pubDate'){
                $pdate = Pxpedia::xmlcontent($key,$xmltree,$val,false);
                if($pdate === ''){
                    $pdate = Pxpedia::xmlcontent('dc:date',$xmltree,$val,false);
                    if($pdate === ''){
                        $pdate = date('Y-m-d H:i:s',time());
                    }
                    else{
                        $pdate = date('Y-m-d H:i:s',strtotime($pdate));
                    }
                }
                else{
                    $pdate = date('Y-m-d H:i:s',strtotime($pdate));
                }
                $news[$key] = $pdate;
            }
            elseif($key == 'description'){
                $description                = Pxpedia::xmldata('description','',$xmltree);
                $preface                    = '';
                if(!isset($description[0])){
                    $description = '';
                    $news[$key] = $description;
                }
                else{
                    $htmltagdecoded             = html_entity_decode($description[0]['content']);
                    
                    if($description[0]['content'] != '' && strlen($description[0]['content']) != strlen($htmltagdecoded) ){
                        $nodekey                    = '';
                        $description[0]['content']  = html_entity_decode($description[0]['content']);
                        $prefacestop                = strpos($description[0]['content'],'<');
                        
                        if($prefacestop !== false){
                            $preface                    = substr($description[0]['content'],0,$prefacestop);
                            $description[0]['content']  = substr($description[0]['content'],$prefacestop);
                        }
                        $description = Pxpedia::parsexml(false,$description[0]['content'],true);
                    }
                    else{
                        $nodekey        = 'description';
                    }
                    
                    $exclude[0]['contenttag']           = 'div';
                    $exclude[0]['contenttagattr']       = 'class';
                    $exclude[0]['contenttagattrvalue']  = 'feedflare';
                    
                    $news[$key] = $preface.trim(trim(Pxpedia::xmlcontent($nodekey,$description,$val,false,$exclude,1000)));                    
                }

                
                if(strlen($news[$key]) >= 1000)
                  $news[$key] .= '...';
            }
            else{
                $news[$key] = Pxpedia::xmlcontent($key,$xmltree,$val,false);   
            }
        }
        return $news;
    }
}


?>