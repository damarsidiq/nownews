<?php

Class Newssource extends Model{
    function __construct(){
        parent::__construct('newssource');
    }
    public function getSettings($sourceid){
        $settings = $this->getrecord(array('id'=>$sourceid),'downloadsetting');
        return json_decode($settings,true);
    }
    public function sourceName($sourceid){
        return $this->getrecord(array('id'=>$sourceid),array('name'));
    }
}


?>