<?php

Class News extends Model{
    var $encodingdest = 'UTF-8';
    function __construct(){
        parent::__construct('news');
    }
    public function getNewsRssId($newsids){
        return $this->getrecords(array('id'=>array('in',$newsids)));
    }
    public function saveNews($content,$rssid){
        $content = str_replace(array('‘','’','“','”','—'),array("'","'",'"','"','-'),$content);
        $content = mb_convert_encoding($content,$this->encodingdest);
        if($this->exists(array('rssid'=>$rssid))){
            $saved = $this->updaterecord(array('content'=>$content),array('rssid'=>$rssid));
            return $saved;
        }
        $saved = $this->addrecord(array('news','rssid'),array($content,$rssid));
        return $saved;
    }
    public function downloaded($rssid){
        $news = $this->getrecord(array('rssid'=>$rssid),'news');
        //echo $this->querystring().'##'.print_r($news,true).'----'.$this->printerrors(false);
        return $news;
    }
    public function flagdownloadednews($rssids=null){
        if(is_null($rssids))
            return false;
        
        if(!is_array($rssids)){
            $rssids = array($rssids);
        }
      
        $exists         = $this->getrecords(array('rssid'=>array('IN',$rssids)),array('rssid','news','id'));
        $downloadednews = array();
        foreach($exists as $ek=>$ev){
            $downloadednews[] = $ev['rssid'];
        }
        
        $downloaditems      = array();
        $downloadedcount    = 0;
        foreach($rssids as $rssidk=>$rssidv){
            $downloadedidx = count($downloaditems);
            $downloaditems[$downloadedidx] = array();
            $downloaded = array_search($rssidv,$downloadednews);
            if($downloaded !== false){
                $downloaditems[$downloadedidx]['rssid']         = $rssidv;
                $downloaditems[$downloadedidx]['content']       = $exists[$downloaded]['news'];
                $downloaditems[$downloadedidx]['newsid']        = $exists[$downloaded]['id'];
                $downloaditems[$downloadedidx]['downloaded']    = true;
                $downloadedcount++;
            }
            else{
                $downloaditems[$downloadedidx]['rssid']         = $rssidv;
                $downloaditems[$downloadedidx]['content']       = '';
                $downloaditems[$downloadedidx]['downloaded']    = false;
            }
        }
        return array($downloaditems,$downloadedcount);
    }
    public function newsletterFlagDownloaded($rssitems){
        $rssids = array_column($rssitems,'id');
        $exists = $this->getrecords(array('rssid'=>array('IN',$rssids)),array('rssid','news','id'));
        
        $todownload         = array();
        $alreadydownloaded  = array();
        
        if(empty($exists)){
            $todownload         = $rssitems;
            $alreadydownloaded  = array();
            $downloadedcount    = 0;
            
            return array($todownload,$alreadydownloaded,0); 
        }
        
        $downloadednews = array();
        foreach($exists as $ek=>$ev){
            $downloadednews[] = $ev['rssid'];
        }
        
        $downloadedcount    = 0;
        foreach($rssitems as $rssidk=>$rssidv){
            $downloaded = array_search($rssidv['id'],$downloadednews);
            
            if($downloaded === false){
                $todownload[] = $rssidv;
                $downloadedcount++;
            }
            else{
                $rssitems[$rssidk]['newsid']        = $exists[$downloaded]['id'];
                $rssitems[$rssidk]['newscontent']   = $exists[$downloaded]['news'];
                $alreadydownloaded[] = $rssitems[$rssidk];
            }
        }
        return array($todownload,$alreadydownloaded,$downloadedcount);
    }
    public function getKeywords($newsid){
        $keywords       = $this->query('select k.keyword from keytonews ktn,keywords k where ktn.newsid ='.$newsid.' and k.id=ktn.keyid');
        if($keywords){
            $keywords = $this->fetchQueryResult($keywords);
        }
        $newskeywords   = array_column($keywords,'keyword');
        return $newskeywords;
    }
    
}


?>