<?php

Class Usersearch extends Model{
    function __construct(){
        parent::__construct('usersearch');
    }
    
    public function submitkeysearch($userid,$keywords,$source){
        $source = $source == false ? 0 : $source;
        
        if(is_array($keywords)){
            foreach($keywords as $k=>$val){
                $this->addrecord(array('userid','keyword','source','submitted'), array($userid,strtolower(trim($val)),$source,date('Y-m-d',time())));
            }
        }
        else{
            $this->addrecord(array('userid','keyword','source','submitted'), array($userid,strtolower(trim($keywords)),$source,date('Y-m-d',time())));
        }
    }
    
    
}


?>