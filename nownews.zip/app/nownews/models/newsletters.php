<?php

Class Newsletters extends Model{
    function __construct(){
        parent::__construct('newsletters');
    }
    
    public function getNewsletterid($email){
        $newsletterid = $this->getrecord(array('email'=>$email),'id');
        return $newsletterid;
    }
    public function addNewsletter($userid,$email){
        $newsletterid   = 0;
        $newsletter     = $this->getrecord(array('email'=>$email),array('status','id'));
        if($newsletter === false){
            $newsletterid   = $this->addrecord(array('email','status','userid'),array($email,0,$userid));
        }
        else{
            if($newsletter['status'] == -1){
                $newsletter['status'] = 0;
                $this->updateNewsletterStatus($newsletter['id'],$newsletter['status']);
            }
        }
        return $newsletterid;
    }
    public function updateNewsletterStatus($id,$status){
        return $this->updaterecord(array('status'=>$status),array('id'=>$id));
    }
    public function removeNewsletter($email){
        return $this->updaterecord(array('status'=>-1),array('email'=>$email));
    }
}


?>