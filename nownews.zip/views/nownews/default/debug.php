<?php 


//echo print_r($pagevar,true);

?>