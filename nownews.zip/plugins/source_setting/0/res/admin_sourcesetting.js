var defaultval  = [];
defaultval[0]   = 'content tag';
defaultval[1]   = 'content tag attribute';
defaultval[2]   = 'content tag attribute value';
var postdata = {};

function blurnownewspluginmessages(){
    setTimeout(function(){
        var edit        = $('#sourcesettingedit').find('.message');
        var newcreate   = $('#sourcesettingaddnew').find('.message');
        
        if($(edit).attr('class').indexOf('active') !== -1){
            $(edit).animate({'opacity':0},'slow',function(){
                $(edit).removeClass('active').css('opacity',1);  
            });   
        }
        
        if($(newcreate).attr('class').indexOf('active') !== -1){
            $(newcreate).animate({'opacity':0},'slow',function(){
                $(newcreate).removeClass('active').css('opacity',1);  
            });   
        }
    },5000);
}

$(document).ready(
    function () {
        var localimageview = new filetool();
        $('.sourceform').delegate('.sourcelogofile','change',function(){
            var files = this.files;
            localimageview.fileuploaderhandle(files,$(this).prev(),localimageview);
            var thisthis = this;
            setTimeout(function(){
                $(thisthis).prev().children().addClass('sourcelogo');
            },300);
        });
        if(typeof($('.menulistitem').attr('class') == 'string')){
            $('body').delegate('.nownewsmenu .menulistitem','click',function(){
                if(this.id == 'deletetab'){
                    var confirmdeletesource = new messagebox();
                    confirmdeletesource.title = 'Confirm deleting source';
                    confirmdeletesource.content = 'Delete source?';
                    confirmdeletesource.action = '<span id="canceldelete">Cancel</span><span id="deletethesource">Delete</span>';
                    
                    confirmdeletesource.display();
                    $('#canceldelete').on('click',function(event){
                        event.stopPropagation();
                        confirmdeletesource.close();
                    });
                    $('#deletethesource').on('click',function(event){
                        confirmdeletesource.updatemessage('sending request...');
                        event.stopPropagation();
                        var sourceiddel = $('#sourcesettingedit').find('#source').val();
                         $.ajax({
                            url:'./',
                            data:{admin:1,d:{plugindata:{plugin:'source_setting',p:'admin',a:'deleteSource',d:{sourceid:sourceiddel}}}},
                            type:'POST'
                        }).done(function(msg){
                            msg = JSON.parse(msg);
                            $('#sourcesettingedit').find('.message').html(msg.message).addClass('active');
                            blurnownewspluginmessages();
                            if(msg.deleted == 1){
                                var options = $('#sourcesettingedit').find('#source').children();
                                for(var oi=0;oi<options.length;oi++){
                                    if($(options[oi]).attr('value') == sourceiddel){
                                        $('#sourcesettingedit').find('#source').children().eq(oi).remove();
                                        resetinputs(true);
                                        break;
                                    }
                                }
                            }
                            confirmdeletesource.close();
                        });
                    });
                }
                else{
                    $('.nownewsmenu .menulistitem').removeClass('active');
                    $(this).addClass('active');
                    if(this.id == 'descriptionstab'){
                        $('.sourcecontent').removeClass('active');
                        $('.descriptionscontent').addClass('active');
                    }
                    else{
                        $('.sourcecontent').removeClass('active');
                        $('.settingscontent').addClass('active');
                    }   
                }
            });
        }
    }
);

$('body').delegate('.sourceform .cycle','change',function(){
    if($(this).val() == 'other'){
        $(this).parent().next().removeClass('hidden');
        $(this).parent().next().next().removeClass('hidden');
    }
    else{
        $(this).parent().next().addClass('hidden');
        $(this).parent().next().next().addClass('hidden');
    }
});

$('body').delegate('.sourceform .sourcelogofile','change',function(){
    if($(this).prev().children().prop('src').indexOf('nownews.source.uploaded.png') === -1){
        $(this).prev().children().prop('src','uploads/nownews/nownews.source.png');
    }
});

$('body').delegate('.sourceform #source','change',function(){
    $('.sourcecontent').addClass('loading');
    var sourceid = $(this).val();
     $.ajax({
          url:'./',
          data:{admin:1,d:{plugindata:{plugin:'source_setting',p:'admin',a:'downloadSetting',d:{sourceid:sourceid,requestsource:true}}}},
          type:'POST'
      }).done(function(msg){
        msg = $.parseJSON(msg);
        resetinputs(false);
        var newexclude = '';
        var newcontent = '';
        var newkeywords = '';
            if(!msg.empty){
                var settings = $.parseJSON(msg.settings);

                if(settings.thecontent && settings.thecontent.length){
                    $.each(settings.thecontent,function(cidx,celem){
                       newcontent += '<div class="inputrow contentinput"><div><input type="text" name="content tag" value="'+celem.contenttag+'"></div><div><input type="text" name="content tag attribute" value="'+celem.contenttagattr+'"></div><div><input type="text" name="content tag attribute value" value="'+celem.contenttagattrvalue+'"></div><div><input type="button" name="addcontent" class="addcontent" value="+"></div><div><input type="button" class="removecontent" value="-"></div></div>'; 
                    });
                    $('#sourcesettingedit').find('#contenttitle').after(newcontent);
                }
                
                
                
                if(settings.exclude && settings.exclude.length){
                    $.each(settings.exclude, function(i,e){                        
                        newexclude +=  '<div class="inputrow excludeinput"><div><input type="text" name="exclude tag" value="'+ e.contenttag +'"></div><div><input type="text" name="exclude tag attribute" value="'+e.contenttagattr+'"></div><div><input type="text" name="exclude tag attribute value" value="'+e.contenttagattrvalue+'"></div><div><input type="button" class="addexclude" value="+"></div><div><input type="button" class="removeexclude" value="-"></div></div>';
                    });
                    $('#sourcesettingedit').find('#excludetitle').after(newexclude);
                }
                
                if(settings.keywords && settings.keywords.length){
                    $.each(settings.keywords, function(i,e){                        
                        newkeywords +=  '<div class="inputrow keywordsinput"><div><input type="text" name="keywords tag" value="'+ e.contenttag +'"></div><div><input type="text" name="keywords tag attribute" value="'+e.contenttagattr+'"></div><div><input type="text" name="keywords tag attribute value" value="'+e.contenttagattrvalue+'"></div></div>';
                    });
                    $('#sourcesettingedit').find('#keywordstitle').after(newkeywords);
                }
            }
            
                if(newcontent === ''){
                    newcontent = '<div class="inputrow contentinput"><div><input type="text" name="content tag" value="content tag"></div><div><input type="text" name="content tag attribute" value="content tag attribute"></div><div><input type="text" name="content tag attribute value" value="content tag attribute value"></div><div><input type="button" name="addcontent" class="addcontent" value="+"></div><div><input type="button" class="removecontent" value="-"></div></div>';
                                    
                    $('#sourcesettingedit').find('#contenttitle').after(newcontent);
                }
                if(newexclude === ''){
                    newexclude = '<div class="inputrow excludeinput"><div><input type="text" name="exclude tag" value="exclude tag"></div><div><input type="text" name="exclude tag attribute" value="exclude tag attribute"></div><div><input type="text" name="exclude tag attribute value" value="exclude tag attribute value"></div><div><input type="button" class="addexclude" value="+"></div><div><input type="button" class="removeexclude" value="-"></div></div>';
                        $('#sourcesettingedit').find('#excludetitle').after(newexclude);
                }
                if(newkeywords === ''){
                    newkeywords = '<div class="inputrow keywordsinput"><div><input type="text" name="keywords tag" value="keywords tag"></div><div><input type="text" name="keywords tag attribute" value="keywords tag attribute"></div><div><input type="text" name="keywords tag attribute value" value="keywords tag attribute value"></div></div>';
                        $('#sourcesettingedit').find('#keywordstitle').after(newkeywords);
                }
                
                var sourcedescriptions = $('#sourcesettingedit').find('.editsource').find('input');
                
                $(sourcedescriptions[0]).val(msg.descriptions.name);
                $(sourcedescriptions[1]).val(msg.descriptions.url);
                
                if(msg.descriptions.cycle == 'daily' || msg.descriptions.cycle == 'weekly' || msg.descriptions.cycle == 'monthly')
                    $('#sourcesettingedit').find('.editsource').find('select').val(msg.descriptions.cycle);
                else{
                    $('#sourcesettingedit').find('.editsource').find('select').val('other');
                    $(sourcedescriptions[2]).parent().removeClass('hidden');
                }
                $('#sourcesettingedit').find('.editsource').find('textarea').val(msg.descriptions.description);
                
                if(msg.descriptions.logo === ''){
                    $('#sourcesettingedit').find('.sourcelogo').prop('src','uploads/nownews/nownews.source.png');
                }
                else{
                    $('#sourcesettingedit').find('.sourcelogo').prop('src',msg.descriptions.logo);
                }
                
                $('#sourcesettingedit').find('.settingscontent').find('select').val(msg.descriptions.status);
                
                $('#sourcesettingedit').find('.sourcecontent').removeClass('loading');
                
                $.each($('#sourcesettingedit').find('.sourceform').find('input[type="text"]'), function(i,e){
                    if($(e).val() != $(e).attr('name')){
                        $(e).addClass('filled');
                    }
                    else{
                        $(e).removeClass('filled');
                    }
                });
      });
});

$('body').delegate('.sourceform','submit',function(){
    $(this).find('.submitform').addClass('loading');
    var submit          = true;
    var contenttag      = [];
    var excludetags     = [];
    var keywordstags    = [];
    
    $.each($(this).find('.contentinput'), function(){
        if($(this).find('input[type="text"]').eq(0).val() !== $(this).find('input[type="text"]').eq(0).attr('name')){
            if($(this).find('input[type="text"]').eq(1).val() !== $(this).find('input[type="text"]').eq(1).attr('name')){
                if($(this).find('input[type="text"]').eq(2).val() !== $(this).find('input[type="text"]').eq(2).attr('name')){
                    var contentidx = contenttag.length;
                    contenttag[contentidx] = [];
                    
                    contenttag[contentidx][0] = $(this).find('input[type="text"]').eq(0).val();
                    contenttag[contentidx][1] = $(this).find('input[type="text"]').eq(1).val();
                    contenttag[contentidx][2] = $(this).find('input[type="text"]').eq(2).val();   
                }
            }
        }
    });
    
    $.each($(this).find('.excludeinput'), function(){
        if($(this).find('input[type="text"]').eq(0).val() !== $(this).find('input[type="text"]').eq(0).attr('name')){     
            var excludeidx              = excludetags.length;
            excludetags[excludeidx]     = [];
            
            excludetags[excludeidx][0] = $(this).find('input[type="text"]').eq(0).val();
            excludetags[excludeidx][1] = $(this).find('input[type="text"]').eq(1).val() == $(this).find('input[type="text"]').eq(1).attr('name') ? '': $(this).find('input[type="text"]').eq(1).val();
            excludetags[excludeidx][2] = $(this).find('input[type="text"]').eq(2).val() == $(this).find('input[type="text"]').eq(2).attr('name') ? '' : $(this).find('input[type="text"]').eq(2).val(); 
        }
    });
    
    $.each($(this).find('.keywordsinput'), function(){
        if($(this).find('input[type="text"]').eq(0).val() !== $(this).find('input[type="text"]').eq(0).attr('name')){
            if($(this).find('input[type="text"]').eq(1).val() !== $(this).find('input[type="text"]').eq(1).attr('name')){
                if($(this).find('input[type="text"]').eq(2).val() !== $(this).find('input[type="text"]').eq(2).attr('name')){
                    var keywordsidx              = keywordstags.length;
                    keywordstags[keywordsidx]     = [];
                    
                    keywordstags[keywordsidx][0] = $(this).find('input[type="text"]').eq(0).val();
                    keywordstags[keywordsidx][1] = $(this).find('input[type="text"]').eq(1).val();
                    keywordstags[keywordsidx][2] = $(this).find('input[type="text"]').eq(2).val();
                }
            }   
        }
    });
    
    $(this).find('#csexc').val(excludetags);
    $(this).find('#cscont').val(contenttag);
    $(this).find('#cskeywords').val(keywordstags);
    
    if(contenttag.length === 0){
        $(this).find('.message').html('please complete the required form').addClass('active');
        blurnownewspluginmessages();
        
        return false;
    }
    else{
        postdata.formmode = $(this).find('.submitform').attr('name') == 'createnew' ? 0 :1;
        postdata.savesource = true;
        postdata.sourceid = postdata.formmode ? this.elements['sourceid'].value : 0;
        postdata.sourcename = this.elements['sourcename'].value;
        postdata.url = this.elements['url'].value;
        postdata.description = this.elements['description'].value;
        postdata.cycle = this.elements['cycle'].value;
        postdata.cycledescription = this.elements['cycledescription'].value;
        postdata.sourcestatus = this.elements['sourcestatus'].value;
        
        postdata.cscont = this.elements['cscont'].value;
        postdata.csexc = this.elements['csexc'].value;
        postdata.cskeywords = this.elements['cskeywords'].value;
        
        var thisform = this;
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,d:{plugindata:{plugin:'source_setting',p:'admin',a:'pageInit',d:postdata}}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            $(thisform).find('.message').html(msg.message).addClass('active');
            blurnownewspluginmessages();
            if(postdata.formmode == 0 && typeof msg.newsourceid !== 'undefined'){
                postdata.sourceid = msg.newsourceid;
                addnewsourcetoselectionopt(postdata);
            }
            
            var resourcefileuploader = new filetool();
            resourcefileuploader.enduploadcallback = function(msg){
                msg = $.parseJSON(msg);
                $(thisform).find('.message').html(msg.message).addClass('active');
                blurnownewspluginmessages();
                $('.submitform').removeClass('loading');
                if(postdata.formmode == 0){
                    resetnewsourceinputs();
                }
            };
            resourcefileuploader.init();
            
            var files = thisform.elements['sourcelogo'].files;
            if(files.length){
                resourcefileuploader.fileuploaderhandle(files,false,resourcefileuploader);
                
                postdata = {};
                postdata.formmode = $(thisform).find('.submitform').attr('name') == 'createnew' ? 0 :1;
                postdata.savesource = true;
                postdata.sourceid = postdata.formmode ? thisform.elements['sourceid'].value : 0;
                postdata.sourcename = thisform.elements['sourcename'].value;
        
                var workerparams = {workeraction:'uploadfiles',app:appname,d:{plugindata:{plugin:'source_setting',p:'admin',a:'pageInit',d:postdata}}};     
                resourcefileuploader.workerparams = workerparams;
                resourcefileuploader.formData.append('app',appname);
                resourcefileuploader.formData.append('d',JSON.stringify(workerparams.d));
                resourcefileuploader.formData.append('files', resourcefileuploader.thefiles);
                resourcefileuploader.startupload();   
            }
            else{
                $(thisform).find('.submitform').removeClass('loading');
                if(postdata.formmode == 0){
                    resetnewsourceinputs();
                }
            }
        });
    }
    
    return false;
});

$('#thepagecontainer').delegate('.addcontent','click',function(){
    var newcontent = '<div class="inputrow contentinput"><div><input type="text" name="content tag" value="content tag"></div><div><input type="text" name="content tag attribute" value="content tag attribute"></div><div><input type="text" name="content tag attribute value" value="content tag attribute value"></div><div><input type="button" name="addcontent" class="addcontent" value="+"></div><div><input type="button" name="removecontent" class="removecontent" value="-"></div></div>';
                    
    $(this).parent().parent().after(newcontent);
});

$('#thepagecontainer').delegate('.addexclude','click',function(){
    var newexclude = '<div class="inputrow excludeinput"><div><input type="text" name="exclude tag" value="exclude tag"></div><div><input type="text" name="exclude tag attribute" value="exclude tag attribute"></div><div><input type="text" name="exclude tag attribute value" value="exclude tag attribute value"></div><div><input type="button" class="addexclude" value="+"></div><div><input type="button" name="removeexclude" class="removeexclude" value="-"></div></div>';
                    
    $(this).parent().parent().after(newexclude);
});
$('#thepagecontainer').delegate('.removeexclude','click',function(){
    if($('.settingscontent').find('.excludeinput').length > 1)
        $(this).parent().parent().remove();
    else{
        var exclinput = $(this).parent().parent().find('input[type="text"]').eq(0);
        $(exclinput).val($(exclinput).attr('name'));
        $(exclinput).removeClass('filled');
        
        exclinput = $(this).parent().parent().find('input[type="text"]').eq(1);
        $(exclinput).val($(exclinput).attr('name'));
        $(exclinput).removeClass('filled');
        
        exclinput = $(this).parent().parent().find('input[type="text"]').eq(2);
        $(exclinput).val($(exclinput).attr('name'));
        $(exclinput).removeClass('filled');
    }
});
$('#thepagecontainer').delegate('.removecontent','click',function(){
    if($('.settingscontent').find('.contentinput').length > 1)
        $(this).parent().parent().remove();
    else{
        var contentinput  =  $(this).parent().parent().find('input[type="text"]').eq(0);
        $(contentinput).val($(contentinput).attr('name'));
        $(contentinput).removeClass('filled');
        
        contentinput = $(this).parent().parent().find('input[type="text"]').eq(1);
        $(contentinput).val($(contentinput).attr('name'));
        $(contentinput).removeClass('filled');
        
        contentinput = $(this).parent().parent().find('input[type="text"]').eq(2);
        $(contentinput).val($(contentinput).attr('name'));
        $(contentinput).removeClass('filled');
    }
});

function resetnewsourceinputs(){
    $.each($('#sourcesettingaddnew').find('input[type="text"],input[type="file"],textarea,select'),function(i,e){
        if($(e)[0].nodeName == 'TEXTAREA'){
           $(e).val('');
        }
        else if($(e)[0].nodeName == 'SELECT'){
            $(e).val($(e).children().eq(0).val());
        }
        else if($(e).attr('type') == 'file'){
            $(e).val('');
        }
        else if(typeof($(e).attr('name')) !== 'undefined') {
            if($(e).attr('name') == 'url' || $(e).attr('name') == 'sourcename'){
                $(e).val('').removeClass('filled');
            }
            else{
                var formarray = $(e).attr('name').indexOf('[');
                if(formarray == -1){
                    formarray = ($(e).attr('name').length);
                }
                
                $(e).val($(e).attr('name').substr(0,formarray));
                $(e).removeClass('filled');   
            }
        }
    });
    $('#sourcesettingaddnew').find('.sourcelogo').prop('src','uploads/nownews/nownews.source.png');
}

function addnewsourcetoselectionopt(postdata){
    var numbering   = $('#sourcesettingedit').find('#source').children().length;
    postdata.sourcestatus = postdata.sourcestatus == 0 ? 'inactive' : 'active';
    var appendto    = '<option class="sourceitemopt" value="'+postdata.sourceid+'">'+numbering+'. '+postdata.sourcename+' - '+postdata.sourcestatus+'</option>';
    $('#sourcesettingedit').find('#source').append(appendto);
}

function resetinputs(all){
    if(all){
        $.each($('#sourcesettingedit').find('input[type="text"],input[type="password"],textarea,select'),function(i,e){
            if($(e)[0].nodeName == 'TEXTAREA'){
               $(e).val('');
            }
            else if($(e)[0].nodeName == 'SELECT'){
                $(e).val($(e).children().eq(0).val());
            }
            else if(typeof($(e).attr('name')) !== 'undefined') {
                if($(e).attr('name') == 'url' || $(e).attr('name') == 'sourcename'){
                    $(e).val('').removeClass('filled');
                }
                else{
                    var formarray = $(e).attr('name').indexOf('[');
                    if(formarray == -1){
                        formarray = ($(e).attr('name').length);
                    }
                    
                    $(e).val($(e).attr('name').substr(0,formarray));
                    $(e).removeClass('filled');   
                }
            }
        });
        $('#sourcesettingedit').find('.sourcelogo').prop('src',$('#nownewsquestionmarkimg').attr('src'));
        return;
    }
    
    $('#sourcesettingedit').find('.excludeinput').remove();
    $('#sourcesettingedit').find('.contentinput').remove();
    $('#sourcesettingedit').find('.keywordsinput').remove();
}

$('body').delegate('.sourceform .errorpagenav','click',function(){
    if($(this).attr('class').indexOf('disabled') === -1){
        if($(this).attr('class').indexOf('next') !== -1){
            var incurrentpage = $('#'+$('#selecterrortype').val()).children().length;
            var lastinpage = $('#'+$('#selecterrortype').val()).children().eq(incurrentpage-1).children('.errorid').html();
            var currentactive = $('#'+$('#selecterrortype').val()).children('.active');
            
            if(typeof($(currentactive).eq(currentactive.length-1).next().attr('class')) == 'string'){
                $(currentactive).removeClass('active');
                var lastinnextpage = $(currentactive).eq(currentactive.length-1).next();
                for(var i=0;i<10;i++){
                    if(typeof($(lastinnextpage).attr('class')) == 'undefined'){
                        break;
                    }
                    $(lastinnextpage).addClass('active');
                    lastinnextpage = $(lastinnextpage).next();
                }
                
                if(typeof($(lastinnextpage).attr('class')) == 'undefined' && $('.errorpagenav.next').attr('class').indexOf($('#selecterrortype').val()+'limit') !== -1){
                    $('.errorpagenav.next').addClass('disabled');
                }
                $('.errorpagenav.previous').removeClass('disabled');
            }
            else{
                $.ajax({
                    url:'./',
                    data:{admin:1,d:{plugindata:{plugin:'source_setting',p:'admin',a:'reportsnav',d:{pagenavof:$('#selecterrortype').val(),lastinpage:lastinpage}}}},
                    type:'POST'
                }).done(function(msg){
                    msg = $.parseJSON(msg);
                    if(msg.limit){
                        $('.errorpagenav.next').addClass($('#selecterrortype').val()+'limit');
                        $('.errorpagenav.next').addClass('disabled');
                        $('.errorpagenav.previous').removeClass('disabled');
                    }
                    else{
                        $('.errorpagenav').removeClass('disabled');
                    }
                    
                    var reports = '';
                    $.each(msg.reports,function(reportidx,report){
                        reports += '<div class="errorline active"><div class="errorid">'+report.id+'</div><div class="rssid">'+report.rssid+'</div><div class="thelog">'+report.log+'</div><div class="thetime">'+report.time+'</div><div class="action"><span class="reportaction">&equiv;</span><span class="reportaction">X</span></div></div>';
                    });
                    $('#'+$('#selecterrortype').val()).children().removeClass('active');
                    $('#'+$('#selecterrortype').val()).append(reports);
                });   
            }
        }
        else{
            var firstinpage = $('#'+$('#selecterrortype').val()).children('.active').eq(0).prev();
            $('#'+$('#selecterrortype').val()).children().removeClass('active');
            
            for(var iv=0;iv<10;iv++){
                if(typeof($(firstinpage).attr('class')) == 'undefined'){
                    break;
                }
                $(firstinpage).addClass('active');
                firstinpage = $(firstinpage).prev();
            }
            if($('#'+$('#selecterrortype').val()).children().eq(0).attr('class').indexOf('active') !== -1 ){
                $('.errorpagenav.previous').addClass('disabled');
            }
            $('.errorpagenav.next').removeClass('disabled');
        }
    }
});

$('body').delegate('.sourceform #selecterrortype','change',function(){
    if($('#'+$('#selecterrortype').val()).children().length !== 0){
        $('.errorcontainer').removeClass('active');
        $('#'+$('#selecterrortype').val()).addClass('active');
        
        if($('#'+$('#selecterrortype').val()).children().eq(0).attr('class').indexOf('active') !== -1 ){
           $('.errorpagenav.previous').addClass('disabled');
        }
        else{
           $('.errorpagenav.previous').removeClass('disabled'); 
        }
        
        if($('#'+$('#selecterrortype').val()).children().eq($('#'+$('#selecterrortype').val()).children().length-1).attr('class').indexOf('active') !== -1 && $('.errorpagenav.next').attr('class').indexOf($('#selecterrortype').val()+'limit') !== -1){
           $('.errorpagenav.next').addClass('disabled');
        }
        else{
           $('.errorpagenav.next').removeClass('disabled'); 
        }
        
        return;
    }
    else if($('#'+$('#selecterrortype').val()).html() == 'empty results'){
        $('.errorcontainer').removeClass('active');
        $('#'+$('#selecterrortype').val()).addClass('active');
        $('.errorpagenav').addClass('disabled');
        return;
    }
    
    $.ajax({
        url:'./',
        data:{admin:1,d:{plugindata:{plugin:'source_setting',p:'admin',a:'reports',d:{request:$('#selecterrortype').val()}}}},
        type:'POST'
    }).done(function(msg){
        msg = $.parseJSON(msg);
        var reports = '';
        if(msg.reports.length === 0){
            reports = 'empty results';
            $('.errorpagenav').addClass('disabled');
        }
        else{
            $.each(msg.reports,function(reportidx,report){
                reports += '<div class="errorline active"><div class="errorid">'+report.id+'</div><div class="rssid">'+report.rssid+'</div><div class="thelog">'+report.log+'</div><div class="thetime">'+report.time+'</div><div class="action"><span class="reportaction">&equiv;</span><span class="reportaction">X</span></div></div>';
            });
            $('#'+$('#selecterrortype').val()).html(reports);
            
            
            
            if(!msg.limit){
                $('.errorpagenav').removeClass('disabled');
                $('.errorpagenav.previous').addClass('disabled');
            }
            else{
                $('.errorpagenav').addClass('disabled');
                $('.errorpagenav.next').addClass($('#selecterrortype').val()+'limit');
            }
        }
        $('.errorcontainer').removeClass('active');
        $('#'+$('#selecterrortype').val()).addClass('active');
    });
});

$('#thepagecontainer').delegate('.errorcontainer .reportaction','click',function(){
    if($(this).html().indexOf('X') !== -1){
        var errorline = $(this).parent().parent();
        var errorid = $(errorline).children('.errorid').html();
        
        $.ajax({
            url:'./',
            data:{admin:1,d:{plugindata:{plugin:'source_setting',p:'admin',a:'deleteReport',d:{errorid:errorid}}}},
            type:'POST'
        }).done(function(msg){
            msg = $.parseJSON(msg);
            if(msg){
                $(errorline).remove();
            }
        });
    }
    else{
        
    }
});