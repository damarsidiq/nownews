<?php
Class Newssource_source_setting extends PluginModel{
    function __construct($pluginid){
        parent::__construct($pluginid,'newssource');
    }
    public function getSettings($sourceid){
        $source = $this->getrecord(array('id'=>$sourceid));
        return json_decode($source['downloadsetting']);
    }
    public function getSources($fields=null){
        return $this->getrecords(null,$fields);
    }
    public function getSource($sourceid){
        $source = $this->getrecord(array('id'=>$sourceid));
        $this->source = $source;
        return $source;
    }
    public function deleteSource($sourceid){
        return $this->deleterecords(array('id'=>$sourceid));
    }
    public function createNew($sourcename){
        return $this->addrecord(array('name','url','description','cycledescription','lastfetched','logo','downloadsetting'),array($sourcename,'','','','1970-01-01 00:00:00',App::getConfig('uploads').'nownews.source.png',''));
    }
    public function updateSource($sourceid,$postdata=false,$logo=false){
        if($postdata !== false){
            $updatedfields = array();
            $updatedfields['name']              = $postdata['sourcename'];
            $updatedfields['url']               = $postdata['url'];
            $updatedfields['description']       = $postdata['description'];
            $updatedfields['cycle']             = $postdata['cycle'];
            $updatedfields['cycledescription']  = $postdata['cycledescription'];
            $updatedfields['status']            = $postdata['sourcestatus'] == -1 ? 0 : $postdata['sourcestatus'];
            $contentsett    = array();
            $excludesett    = array();
            $keywordssett   = array();
            
            $thecontent     = $postdata['cscont'];
            $theexclude     = $postdata['csexc'];
            $thekeywords    = $postdata['cskeywords'];
            
            $thecontentx = explode(',',$thecontent);
            $excludex    = explode(',',$theexclude);
            $keywordsx   = explode(',',$thekeywords);
            
            $i = 0;
            while($i<count($thecontentx)){
                $contentidx = count($contentsett);
                $contentsett[$contentidx]['contenttag'] =$thecontentx[$i];
                $i++;
                $contentsett[$contentidx]['contenttagattr'] =$thecontentx[$i];
                $i++;
                $contentsett[$contentidx]['contenttagattrvalue'] =$thecontentx[$i];
                $i++;
            }
            if(strpos($theexclude,',')!==false){
                $i=0;
                while($i<count($excludex)){
                    $excludeidx = count($excludesett);
                    $excludesett[$excludeidx]['contenttag'] =$excludex[$i];
                    $i++;
                    $excludesett[$excludeidx]['contenttagattr'] =$excludex[$i];
                    $i++;
                    $excludesett[$excludeidx]['contenttagattrvalue'] =$excludex[$i];
                    $i++;
                }
            }
            if(strpos($thekeywords,',')!==false){
                $i=0;
                while($i<count($keywordsx)){
                    $keywordsidx = count($keywordssett);
                    $keywordssett[$keywordsidx]['contenttag'] =$keywordsx[$i];
                    $i++;
                    $keywordssett[$keywordsidx]['contenttagattr'] =$keywordsx[$i];
                    $i++;
                    $keywordssett[$keywordsidx]['contenttagattrvalue'] =$keywordsx[$i];
                    $i++;
                }
            }
     
            
            $updatedfields['downloadsetting'] = array();
            $updatedfields['downloadsetting']['thecontent']    = $contentsett;
            $updatedfields['downloadsetting']['exclude']       = $excludesett;
            $updatedfields['downloadsetting']['keywords']      = $keywordssett;
            
            $updatedfields['downloadsetting'] = json_encode($updatedfields['downloadsetting']);   
        }
        
        if($logo != false){
        	$newfilename 	= $logo['sourcename'].'_nownewssource_'.$sourceid;
		    $imagedir = App::$config['uploads'].App::appById(App::getUser()['currentrole']['appid']).'/sourcelogo/';
			$uploaded = App::uploadimage($logo,$newfilename,$imagedir,true);
            if($uploaded){
                $updatedfields['logo'] = $uploaded;
            }
        }
        return $this->updaterecord($updatedfields,array('id'=>$sourceid));
    }
}


?>